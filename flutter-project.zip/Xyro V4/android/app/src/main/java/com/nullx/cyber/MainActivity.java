package com.nullx.nang;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
