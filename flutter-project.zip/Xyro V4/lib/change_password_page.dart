// change_password_page.dart
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'theme.dart';   // ← SISTEM TEMA

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';
const String baseUrl = "http://digital.mypanelku.web.id:2041";

// ─── PALETTE (alias ke AppColors dinamis) ──────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;

  // Aksen diganti ke AppColors
  static Color get orangeAccent => AppColors.accentMid;
  static Color get orangeLight  => AppColors.accentLight;
  static Color get orangeDark   => AppColors.accentDark;

  static Color get green => AppColors.green;
  static Color get red   => AppColors.red;
  static Color get amber => AppColors.amber;

  static Color get text    => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get textDim => AppColors.textHint;

  static LinearGradient get buttonGrad => AppColors.btnGrad;
  static LinearGradient get glassGrad  => AppColors.glassGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow  => AppColors.softShadow;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ────────────────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage>
    with TickerProviderStateMixin {
  final oldPassCtrl     = TextEditingController();
  final newPassCtrl     = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading       = false;
  bool _obscureOld     = true;
  bool _obscureNew     = true;
  bool _obscureConfirm = true;

  double _strength = 0;
  String _strengthLabel = '';
  Color  _strengthColor = AppColors.textHint;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _iconCtrl;
  late AnimationController _shakeCtrl;

  late Animation<double>  _iconRotate;
  late Animation<double>  _iconScale;
  late Animation<Offset>  _formSlide;
  late Animation<double>  _formFade;
  late Animation<double>  _shake;

  final _oldFocus     = FocusNode();
  final _newFocus     = FocusNode();
  final _confirmFocus = FocusNode();

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    _entranceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _formSlide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic));
    _formFade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);

    _iconCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _iconRotate = Tween<double>(begin: -0.15, end: 0.0)
        .animate(CurvedAnimation(parent: _iconCtrl, curve: Curves.elasticOut));
    _iconScale = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _iconCtrl, curve: Curves.easeOutBack));

    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -10.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10.0, end: 10.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -8.0),  weight: 2),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0),   weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: 0.0),    weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _entranceCtrl.forward();
    _iconCtrl.forward();

    newPassCtrl.addListener(_evalStrength);
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _iconCtrl.dispose();
    _shakeCtrl.dispose();
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    _oldFocus.dispose();
    _newFocus.dispose();
    _confirmFocus.dispose();
    super.dispose();
  }

  void _evalStrength() {
    final p = newPassCtrl.text;
    double s = 0;
    if (p.length >= 8)  s += 0.25;
    if (p.length >= 12) s += 0.15;
    if (RegExp(r'[A-Z]').hasMatch(p)) s += 0.2;
    if (RegExp(r'[0-9]').hasMatch(p)) s += 0.2;
    if (RegExp(r'[!@#\$%^&*]').hasMatch(p)) s += 0.2;

    String label;
    Color color;
    if (p.isEmpty)    { s = 0; label = '';       color = AppColors.textHint; }
    else if (s < 0.4) {        label = 'Lemah';  color = AppColors.red; }
    else if (s < 0.7) {        label = 'Sedang'; color = AppColors.amber; }
    else              {        label = 'Kuat';   color = AppColors.green; }

    setState(() {
      _strength      = s;
      _strengthLabel = label;
      _strengthColor = color;
    });
  }

  // ─── API ──────────────────────────────────────────────────────────────
  Future<void> _changePassword() async {
    final oldPass     = oldPassCtrl.text.trim();
    final newPass     = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _shakeCtrl.forward(from: 0);
      _showResult('Semua field harus diisi.', success: false);
      return;
    }
    if (newPass != confirmPass) {
      _shakeCtrl.forward(from: 0);
      _showResult('Password baru tidak cocok dengan konfirmasi.', success: false);
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username":   widget.username,
          "oldPass":    oldPass,
          "newPass":    newPass,
          "sessionKey": widget.sessionKey,
        },
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _showResult('Password berhasil diubah!', success: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _shakeCtrl.forward(from: 0);
        _showResult(data['message'] ?? 'Gagal mengubah password', success: false);
      }
    } catch (e) {
      _shakeCtrl.forward(from: 0);
      _showResult('Koneksi error.', success: false);
    }
    setState(() => isLoading = false);
  }

  // ─── Result Dialog ────────────────────────────────────────────────────
  void _showResult(String msg, {required bool success}) {
    final isComic = ThemeModeManager.isComic3d;
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 340),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 24),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 24),
                border: Border.all(
                  color: (success ? _C.green : _C.red).withOpacity(0.5),
                  width: isComic ? 3 : 1.5,
                ),
                boxShadow: isComic
                    ? AppColors.glassShadow
                    : [
                        BoxShadow(
                          color: (success ? _C.green : _C.red).withOpacity(0.15),
                          blurRadius: 50,
                        ),
                      ],
              ),
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 56, height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: (success ? _C.green : _C.red).withOpacity(0.1),
                      border: Border.all(
                          color: (success ? _C.green : _C.red).withOpacity(0.3)),
                    ),
                    child: Icon(
                      success ? Icons.check_rounded : Icons.close_rounded,
                      color: success ? _C.green : _C.red,
                      size: 28,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    success ? 'Berhasil' : 'Gagal',
                    style: TextStyle(
                        color: _C.text, fontSize: 18, fontWeight: FontWeight.w800,
                        fontFamily: kFont),
                  ),
                  const SizedBox(height: 8),
                  Text(msg,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub, fontSize: 13, height: 1.5,
                          fontFamily: kFont)),
                  const SizedBox(height: 24),
                  _GradBtn(
                    label: 'OK',
                    fullWidth: true,
                    onTap: () => Navigator.pop(ctx),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── Build ────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    // ⚡ AUTO REBUILD SAAT TEMA GANTI
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          extendBodyBehindAppBar: true,
          appBar: _buildAppBar(),
          body: AppBackground(
            controller: _bgCtrl,
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: FadeTransition(
                opacity: _formFade,
                child: SlideTransition(
                  position: _formSlide,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                    child: Column(
                      children: [
                        const SizedBox(height: 16),
                        _buildHeroIcon(),
                        const SizedBox(height: 28),
                        _buildInfoCard(),
                        const SizedBox(height: 28),
                        AnimatedBuilder(
                          animation: _shake,
                          builder: (_, child) => Transform.translate(
                            offset: Offset(_shake.value, 0),
                            child: child,
                          ),
                          child: _buildForm(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: _AppBarBackBtn(onTap: () => Navigator.pop(context)),
      title: Text(
        'Ganti Password',
        style: TextStyle(
          color: _C.text,
          fontSize: 17,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.3,
          fontFamily: kFont,
        ),
      ),
      centerTitle: true,
    );
  }

  Widget _buildHeroIcon() {
    return AnimatedBuilder(
      animation: _iconCtrl,
      builder: (_, __) => Transform.scale(
        scale: _iconScale.value,
        child: Transform.rotate(
          angle: _iconRotate.value,
          child: _HeroIconWidget(),
        ),
      ),
    );
  }

  Widget _buildInfoCard() {
    final isComic = ThemeModeManager.isComic3d;
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 10,
          sigmaY: isComic ? 0 : 10,
        ),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _C.border,
              width: AppColors.borderWidth,
            ),
            boxShadow: _C.softShadow,
          ),
          child: Row(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: _C.orangeAccent.withOpacity(isComic ? 0.3 : 0.12),
                  borderRadius: BorderRadius.circular(isComic ? 4 : 10),
                  border: Border.all(
                    color: _C.borderLit,
                    width: isComic ? 2 : 1,
                  ),
                ),
                child: Icon(
                  Icons.person_outline_rounded,
                  color: isComic ? const Color(0xFF1A1A1A) : _C.orangeLight,
                  size: 18,
                ),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Akun',
                      style: TextStyle(
                          color: _C.textSub, fontSize: 11,
                          fontFamily: kFont)),
                  Text(
                    widget.username,
                    style: TextStyle(
                        color: _C.text, fontSize: 15, fontWeight: FontWeight.w700,
                        fontFamily: kFont),
                  ),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(isComic ? 4 : 8),
                  border: Border.all(
                    color: _C.green.withOpacity(0.3),
                    width: AppColors.borderWidth,
                  ),
                ),
                child: Text('AKTIF',
                    style: TextStyle(
                        color: _C.green,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8,
                        fontFamily: kFont)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildForm() {
    final isComic = ThemeModeManager.isComic3d;
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 12,
          sigmaY: isComic ? 0 : 12,
        ),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _C.border,
              width: AppColors.borderWidth,
            ),
            boxShadow: isComic
                ? AppColors.glassShadow
                : [
                    BoxShadow(
                        color: _C.orangeAccent.withOpacity(0.06),
                        blurRadius: 30,
                        offset: const Offset(0, 10)),
                  ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(children: [
                Container(
                  width: 4, height: 18,
                  decoration: BoxDecoration(
                    gradient: _C.buttonGrad,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 10),
                Text('Perbarui Keamanan',
                    style: TextStyle(
                        color: _C.text,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        fontFamily: kFont)),
              ]),
              const SizedBox(height: 6),
              Padding(
                padding: const EdgeInsets.only(left: 14),
                child: Text('Masukkan password lama & baru',
                    style: TextStyle(
                        color: _C.textSub, fontSize: 12,
                        fontFamily: kFont)),
              ),

              const SizedBox(height: 24),

              _PasswordField(
                controller: oldPassCtrl,
                focusNode: _oldFocus,
                hint: 'Password Lama',
                icon: Icons.lock_outline_rounded,
                obscure: _obscureOld,
                onToggle: () => setState(() => _obscureOld = !_obscureOld),
                nextFocus: _newFocus,
              ),

              const SizedBox(height: 14),

              _PasswordField(
                controller: newPassCtrl,
                focusNode: _newFocus,
                hint: 'Password Baru',
                icon: Icons.vpn_key_outlined,
                obscure: _obscureNew,
                onToggle: () => setState(() => _obscureNew = !_obscureNew),
                nextFocus: _confirmFocus,
              ),

              if (newPassCtrl.text.isNotEmpty) ...[
                const SizedBox(height: 8),
                _StrengthBar(
                  strength: _strength,
                  label: _strengthLabel,
                  color: _strengthColor,
                ),
              ],

              const SizedBox(height: 14),

              _PasswordField(
                controller: confirmPassCtrl,
                focusNode: _confirmFocus,
                hint: 'Konfirmasi Password',
                icon: Icons.enhanced_encryption_outlined,
                obscure: _obscureConfirm,
                onToggle: () => setState(() => _obscureConfirm = !_obscureConfirm),
                isLast: true,
                onSubmit: _changePassword,
                matchState: confirmPassCtrl.text.isEmpty
                    ? null
                    : confirmPassCtrl.text == newPassCtrl.text,
              ),

              const SizedBox(height: 28),

              _SubmitButton(
                isLoading: isLoading,
                onTap: _changePassword,
              ),

              const SizedBox(height: 16),

              _buildTips(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTips() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.orangeAccent.withOpacity(isComic ? 0.15 : 0.05),
        borderRadius: BorderRadius.circular(isComic ? 4 : 12),
        border: Border.all(
          color: _C.border,
          width: AppColors.borderWidth,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(Icons.shield_outlined, color: _C.textSub, size: 13),
            const SizedBox(width: 6),
            Text('Tips keamanan',
                style: TextStyle(
                    color: _C.textSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: kFont)),
          ]),
          const SizedBox(height: 8),
          ...[
            'Minimal 8 karakter',
            'Kombinasi huruf besar, angka & simbol',
            'Hindari tanggal lahir atau nama',
          ].map((t) => Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Icon(Icons.circle, color: _C.textDim, size: 5),
                    ),
                    const SizedBox(width: 8),
                    Text(t,
                        style: TextStyle(
                            color: _C.textDim, fontSize: 11, height: 1.4,
                            fontFamily: kFont)),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

// ─── Hero Icon ────────────────────────────────────────────────────────
class _HeroIconWidget extends StatefulWidget {
  @override
  State<_HeroIconWidget> createState() => _HeroIconWidgetState();
}

class _HeroIconWidgetState extends State<_HeroIconWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulse;
  late Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.2, end: 0.8)
        .animate(CurvedAnimation(parent: _pulse, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return AnimatedBuilder(
      animation: _glow,
      builder: (_, __) => Column(
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 110, height: 110,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: _C.orangeAccent.withOpacity(
                        isComic ? 1.0 : _glow.value * 0.3),
                    width: isComic ? 3 : 1,
                  ),
                ),
              ),
              Container(
                width: 90, height: 90,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: _C.orangeAccent.withOpacity(
                        isComic ? 1.0 : _glow.value * 0.5),
                    width: isComic ? 2 : 1,
                  ),
                ),
              ),
              Container(
                width: 70, height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [_C.orangeDark, _C.orangeAccent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: isComic
                      ? Border.all(color: AppColors.border, width: 3)
                      : null,
                  boxShadow: isComic
                      ? AppColors.softShadow
                      : [
                          BoxShadow(
                            color: _C.orangeAccent.withOpacity(_glow.value * 0.5),
                            blurRadius: 30,
                            spreadRadius: 0,
                          ),
                        ],
                ),
                child: Icon(
                  Icons.lock_reset_rounded,
                  color: _onAccent(),
                  size: 32,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text('Keamanan Akun',
              style: TextStyle(
                  color: _C.text, fontSize: 20, fontWeight: FontWeight.w800,
                  fontFamily: kFont)),
          const SizedBox(height: 4),
          Text('Perbarui password secara berkala',
              style: TextStyle(color: _C.textSub, fontSize: 13,
                  fontFamily: kFont)),
        ],
      ),
    );
  }
}

// ─── Password Field ───────────────────────────────────────────────────
class _PasswordField extends StatefulWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final String hint;
  final IconData icon;
  final bool obscure;
  final VoidCallback onToggle;
  final FocusNode? nextFocus;
  final bool isLast;
  final VoidCallback? onSubmit;
  final bool? matchState;

  const _PasswordField({
    required this.controller,
    required this.focusNode,
    required this.hint,
    required this.icon,
    required this.obscure,
    required this.onToggle,
    this.nextFocus,
    this.isLast = false,
    this.onSubmit,
    this.matchState,
  });

  @override
  State<_PasswordField> createState() => _PasswordFieldState();
}

class _PasswordFieldState extends State<_PasswordField> {
  bool _focused = false;

  @override
  void initState() {
    super.initState();
    widget.focusNode.addListener(() {
      setState(() => _focused = widget.focusNode.hasFocus);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    Color borderColor;
    if (widget.matchState == true) {
      borderColor = _C.green;
    } else if (widget.matchState == false) {
      borderColor = _C.red;
    } else if (_focused) {
      borderColor = _C.orangeAccent;
    } else {
      borderColor = _C.border;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: isComic ? AppColors.card2 : Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(isComic ? 4 : 16),
        border: Border.all(
          color: borderColor,
          width: _focused ? (isComic ? 3 : 1.5) : AppColors.borderWidth,
        ),
        boxShadow: _focused && !isComic
            ? [
                BoxShadow(
                  color: _C.orangeAccent.withOpacity(0.2),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                )
              ]
            : [],
      ),
      child: TextField(
        controller: widget.controller,
        focusNode: widget.focusNode,
        obscureText: widget.obscure,
        textInputAction:
            widget.isLast ? TextInputAction.done : TextInputAction.next,
        onSubmitted: (_) {
          if (widget.nextFocus != null) {
            FocusScope.of(context).requestFocus(widget.nextFocus);
          } else {
            widget.onSubmit?.call();
          }
        },
        style: TextStyle(
            color: _C.text, fontSize: 15, fontWeight: FontWeight.w500,
            fontFamily: kFont),
        cursorColor: _C.orangeAccent,
        decoration: InputDecoration(
          hintText: widget.hint,
          hintStyle: TextStyle(color: _C.textSub, fontSize: 14,
              fontFamily: kFont),
          prefixIcon: Icon(
            widget.icon,
            color: _focused ? _C.orangeLight : _C.textSub,
            size: 20,
          ),
          suffixIcon: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.matchState != null)
                Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: Icon(
                    widget.matchState!
                        ? Icons.check_circle_rounded
                        : Icons.cancel_rounded,
                    color: widget.matchState! ? _C.green : _C.red,
                    size: 16,
                  ),
                ),
              IconButton(
                icon: Icon(
                  widget.obscure
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: _C.textSub,
                  size: 20,
                ),
                onPressed: widget.onToggle,
                splashRadius: 18,
              ),
            ],
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        ),
      ),
    );
  }
}

// ─── Strength Bar ─────────────────────────────────────────────────────
class _StrengthBar extends StatelessWidget {
  final double strength;
  final String label;
  final Color color;

  const _StrengthBar({
    required this.strength,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return Row(
      children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: Stack(
              children: [
                Container(height: 4, color: _C.border),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  height: 4,
                  width: MediaQuery.of(context).size.width * strength * 0.65,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: isComic
                        ? null
                        : [
                            BoxShadow(
                                color: color.withOpacity(0.4), blurRadius: 6),
                          ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 10),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          child: Text(
            label,
            key: ValueKey(label),
            style: TextStyle(
                color: color, fontSize: 11, fontWeight: FontWeight.w600,
                fontFamily: kFont),
          ),
        ),
      ],
    );
  }
}

// ─── Submit Button ────────────────────────────────────────────────────
class _SubmitButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onTap;

  const _SubmitButton({required this.isLoading, required this.onTap});

  @override
  State<_SubmitButton> createState() => _SubmitButtonState();
}

class _SubmitButtonState extends State<_SubmitButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 54,
          decoration: BoxDecoration(
            gradient: _C.buttonGrad,
            borderRadius: BorderRadius.circular(isComic ? 4 : 16),
            border: isComic
                ? Border.all(color: AppColors.border, width: 3)
                : null,
            boxShadow: _down || widget.isLoading
                ? (isComic ? AppColors.softShadow : [])
                : (isComic
                    ? AppColors.softShadow
                    : [
                        BoxShadow(
                          color: _C.orangeAccent.withOpacity(0.4),
                          blurRadius: 20,
                          offset: const Offset(0, 6),
                        ),
                      ]),
          ),
          child: Center(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: widget.isLoading
                  ? SizedBox(
                      key: const ValueKey('loading'),
                      width: 22, height: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.5, color: _onAccent()),
                    )
                  : Row(
                      key: const ValueKey('label'),
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.lock_reset_rounded,
                            color: _onAccent(), size: 18),
                        const SizedBox(width: 10),
                        Text(
                          'Perbarui Password',
                          style: TextStyle(
                            color: _onAccent(),
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                            letterSpacing: 0.3,
                            fontFamily: kFont,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Gradient Button ─────────────────────────────────────────────────
class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;

  const _GradBtn({
    required this.label,
    required this.onTap,
    this.fullWidth = false,
  });

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: _C.buttonGrad,
            borderRadius: BorderRadius.circular(isComic ? 4 : 13),
            border: isComic
                ? Border.all(color: AppColors.border, width: 2)
                : null,
            boxShadow: _down || isComic
                ? (isComic ? AppColors.softShadow : [])
                : [
                    BoxShadow(
                      color: _C.orangeAccent.withOpacity(0.3),
                      blurRadius: 14,
                      offset: const Offset(0, 4),
                    ),
                  ],
          ),
          child: Center(
            child: Text(widget.label,
                style: TextStyle(
                  color: _onAccent(),
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                  fontFamily: kFont,
                )),
          ),
        ),
      ),
    );
  }
}

// ─── AppBar Back Button ──────────────────────────────────────────────
class _AppBarBackBtn extends StatefulWidget {
  final VoidCallback onTap;
  const _AppBarBackBtn({required this.onTap});

  @override
  State<_AppBarBackBtn> createState() => _AppBarBackBtnState();
}

class _AppBarBackBtnState extends State<_AppBarBackBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.all(8),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) {
          setState(() => _down = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          decoration: BoxDecoration(
            color: _down ? _C.borderLit : AppColors.card,
            borderRadius: BorderRadius.circular(isComic ? 4 : 11),
            border: Border.all(
              color: _C.border,
              width: AppColors.borderWidth,
            ),
          ),
          child: Icon(
            Icons.arrow_back_ios_new_rounded,
            color: _C.textSub,
            size: 16,
          ),
        ),
      ),
    );
  }
}