// buy.dart
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';

const String kFont = 'Pek';
const String baseUrl = 'http://digital.mypanelku.web.id:2041';

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ═══════════════════════════════════════════════════════════════════════
//  MODEL PAKET
// ═══════════════════════════════════════════════════════════════════════
class Paket {
  final String id;
  final String role;
  final String durasi;
  final int harga;
  final String label;

  const Paket({
    required this.id,
    required this.role,
    required this.durasi,
    required this.harga,
    required this.label,
  });
}

const List<Paket> kPaketList = [
  // ── MEMBER ──
  Paket(id: 'member_1h',       role: 'member',   durasi: '1 Hari',    harga: 2000,  label: 'Member 1h'),
  Paket(id: 'member_7h',       role: 'member',   durasi: '7 Hari',    harga: 12000, label: 'Member 7h'),
  Paket(id: 'member_1m',       role: 'member',   durasi: '1 Bulan',   harga: 17000, label: 'Member 1 Bulan'),
  Paket(id: 'member_perm',     role: 'member',   durasi: 'Permanen',  harga: 20000, label: 'Member Permanen'),
  // ── RESELLER ──
  Paket(id: 'reseller_perm',   role: 'reseller', durasi: 'Permanen',  harga: 35000, label: 'Reseller Permanen'),
  // ── VIP ──
  Paket(id: 'vip_perm',        role: 'vip',      durasi: 'Permanen',  harga: 40000, label: 'VIP Permanen'),
  // ── ADMIN ──
  Paket(id: 'admin_perm',      role: 'admin',    durasi: 'Permanen',  harga: 45000, label: 'Admin Permanen'),
  // ── OWNER ──
  Paket(id: 'owner_perm',      role: 'owner',    durasi: 'Permanen',  harga: 60000, label: 'Owner Permanen'),
];

// ═══════════════════════════════════════════════════════════════════════
//  BUY PAGE
// ═══════════════════════════════════════════════════════════════════════
class BuyPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const BuyPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<BuyPage> createState() => _BuyPageState();
}

class _BuyPageState extends State<BuyPage> {
  Paket? _selected;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: AppColors.bg,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildInfoBanner(),
                          const SizedBox(height: 20),
                          _buildPaketGrid(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppColors.accent.withOpacity(0.3),
                  width: AppColors.borderWidth,
                ),
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                color: AppColors.accent,
                size: 16,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('BELI AKUN',
                  style: TextStyle(
                    color: AppColors.text,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFont,
                    letterSpacing: 1.5,
                  )),
              Text('Pembayaran QRIS otomatis',
                  style: TextStyle(
                    color: AppColors.textSub,
                    fontSize: 10.5,
                    fontFamily: kFont,
                  )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBanner() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: isComic ? null : AppColors.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: AppColors.accent.withOpacity(0.3),
          width: AppColors.borderWidth,
        ),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline_rounded,
              color: AppColors.accent, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Pilih paket → isi username & password → scan QRIS → akun dibuat otomatis',
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 11,
                height: 1.5,
                fontFamily: kFont,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaketGrid() {
    // Group by role
    final roles = ['member', 'reseller', 'vip', 'admin', 'owner'];
    final roleLabels = {
      'member': 'MEMBER',
      'reseller': 'RESELLER',
      'vip': 'VIP',
      'admin': 'ADMIN',
      'owner': 'OWNER',
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: roles.map((role) {
        final pakets = kPaketList.where((p) => p.role == role).toList();
        if (pakets.isEmpty) return const SizedBox();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 12, 4, 10),
              child: Row(
                children: [
                  Container(
                    width: 3, height: 14,
                    decoration: BoxDecoration(
                      gradient: AppColors.btnGrad,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(roleLabels[role] ?? role.toUpperCase(),
                      style: TextStyle(
                        color: AppColors.text,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        fontFamily: kFont,
                        letterSpacing: 1.5,
                      )),
                ],
              ),
            ),
            ...pakets.map((p) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _buildPaketCard(p),
                )),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildPaketCard(Paket p) {
    final isComic = ThemeModeManager.isComic3d;

    // Warna per role
    final roleColor = _roleColor(p.role);

    return GestureDetector(
      onTap: () => _onPaketTap(p),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: isComic
              ? null
              : LinearGradient(
                  colors: [
                    roleColor.withOpacity(0.15),
                    roleColor.withOpacity(0.03),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          color: isComic ? AppColors.card : null,
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          border: Border.all(
            color: roleColor.withOpacity(isComic ? 0.6 : 0.4),
            width: AppColors.borderWidth,
          ),
          boxShadow: isComic
              ? AppColors.softShadow
              : [
                  BoxShadow(
                    color: roleColor.withOpacity(0.15),
                    blurRadius: 20,
                    offset: const Offset(0, 6),
                  ),
                ],
        ),
        child: Row(
          children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    roleColor,
                    roleColor.withOpacity(0.7),
                  ],
                ),
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                border: isComic
                    ? Border.all(color: AppColors.border, width: 2)
                    : null,
              ),
              child: Icon(
                _roleIcon(p.role),
                color: isComic
                    ? const Color(0xFF1A1A1A)
                    : Colors.white,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.label,
                      style: TextStyle(
                        color: AppColors.text,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        fontFamily: kFont,
                      )),
                  const SizedBox(height: 3),
                  Text(p.durasi,
                      style: TextStyle(
                        color: AppColors.textSub,
                        fontSize: 11,
                        fontFamily: kFont,
                      )),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('Rp${_formatHarga(p.harga)}',
                    style: TextStyle(
                      color: isComic ? const Color(0xFF1A1A1A) : roleColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      fontFamily: kFont,
                    )),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: roleColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.arrow_forward_rounded,
                          color: isComic
                              ? const Color(0xFF1A1A1A)
                              : roleColor,
                          size: 11),
                      const SizedBox(width: 3),
                      Text('BELI',
                          style: TextStyle(
                            color: isComic
                                ? const Color(0xFF1A1A1A)
                                : roleColor,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            fontFamily: kFont,
                            letterSpacing: 0.8,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _roleColor(String role) {
    switch (role) {
      case 'owner':    return const Color(0xFF6C47FF);
      case 'admin':    return const Color(0xFF8B6BFF);
      case 'vip':      return const Color(0xFFFF6B00);
      case 'reseller': return const Color(0xFFFF2D55);
      default:         return AppColors.accent;
    }
  }

  IconData _roleIcon(String role) {
    switch (role) {
      case 'owner':    return Icons.workspace_premium_rounded;
      case 'admin':    return Icons.admin_panel_settings_rounded;
      case 'vip':      return Icons.star_rounded;
      case 'reseller': return Icons.storefront_rounded;
      default:         return Icons.person_rounded;
    }
  }

  String _formatHarga(int harga) {
    if (harga >= 1000) {
      final k = harga / 1000;
      return k == k.toInt() ? '${k.toInt()}k' : '${k.toStringAsFixed(1)}k';
    }
    return '$harga';
  }

  void _onPaketTap(Paket p) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _BuyFlowSheet(
        paket: p,
        sessionKey: widget.sessionKey,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  BUY FLOW SHEET (input username/password → QRIS → status)
// ═══════════════════════════════════════════════════════════════════════
class _BuyFlowSheet extends StatefulWidget {
  final Paket paket;
  final String sessionKey;

  const _BuyFlowSheet({
    required this.paket,
    required this.sessionKey,
  });

  @override
  State<_BuyFlowSheet> createState() => _BuyFlowSheetState();
}

class _BuyFlowSheetState extends State<_BuyFlowSheet> {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  // Step: 0 = input form, 1 = QRIS, 2 = sukses
  int _step = 0;

  // QRIS data
  String? _depositId;
  String? _qrUrl;
  int _totalPayment = 0;
  int _expiredAt = 0;

  bool _loading = false;
  Timer? _pollTimer;
  int _pollCountdown = 0;

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _pollTimer?.cancel();
    super.dispose();
  }

  // ─── Step 1: Submit form → buat invoice ──────────────────────────
  Future<void> _submitForm() async {
    final user = _userCtrl.text.trim();
    final pass = _passCtrl.text.trim();

    if (user.isEmpty || pass.isEmpty) {
      _toast('Username & password wajib diisi', AppColors.amber);
      return;
    }
    if (user.length < 3 || pass.length < 4) {
      _toast('Username min 3, password min 4', AppColors.amber);
      return;
    }

    setState(() => _loading = true);

    try {
      // Buat invoice di server kita (yang nanti forward ke Pakasir)
      final res = await http.post(
        Uri.parse('$baseUrl/buy/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sessionKey': widget.sessionKey,
          'paketId': widget.paket.id,
          'username': user,
          'password': pass,
        }),
      ).timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);

      if (data['success'] != true) {
        _toast(data['message'] ?? 'Gagal membuat invoice', AppColors.red);
        setState(() => _loading = false);
        return;
      }

      setState(() {
        _depositId = data['depositId'];
        _qrUrl = data['qrUrl'];
        _totalPayment = data['totalPayment'] ?? widget.paket.harga;
        _expiredAt = data['expiredAt'] ?? 0;
        _step = 1;
        _loading = false;
        _pollCountdown = 0;
      });

      _startPolling();
    } catch (e) {
      _toast('Error: $e', AppColors.red);
      setState(() => _loading = false);
    }
  }

  // ─── Step 2: Poll status tiap 5 detik ────────────────────────────
  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted) return;
      if (_depositId == null) return;

      // Cooldown server 30s — kirim tiap 5s dari client, server handle
      try {
        final res = await http.post(
          Uri.parse('$baseUrl/buy/status'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'sessionKey': widget.sessionKey,
            'depositId': _depositId,
          }),
        ).timeout(const Duration(seconds: 15));

        final data = jsonDecode(res.body);
        final status = data['status'];

        if (status == 'success') {
          _pollTimer?.cancel();
          if (mounted) setState(() => _step = 2);
        } else if (status == 'expired') {
          _pollTimer?.cancel();
          if (mounted) {
            _toast('Invoice expired', AppColors.red);
            Navigator.pop(context);
          }
        }
      } catch (_) {}
    });
  }

  // ─── Cancel invoice ──────────────────────────────────────────────
  Future<void> _cancelInvoice() async {
    _pollTimer?.cancel();
    if (_depositId != null) {
      try {
        await http.post(
          Uri.parse('$baseUrl/buy/cancel'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'sessionKey': widget.sessionKey,
            'depositId': _depositId,
          }),
        ).timeout(const Duration(seconds: 10));
      } catch (_) {}
    }
    if (mounted) Navigator.pop(context);
  }

  void _toast(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(
              color: _onAccent(),
              fontWeight: FontWeight.w600,
              fontFamily: kFont)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      decoration: BoxDecoration(
        gradient: ThemeModeManager.isComic3d ? null : AppColors.glassGrad,
        color: ThemeModeManager.isComic3d ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.sheetRadius),
        border: Border.all(
          color: AppColors.border,
          width: AppColors.borderWidth,
        ),
        boxShadow: AppColors.glassShadow,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle
            Container(
              width: 36, height: 4,
              decoration: BoxDecoration(
                color: AppColors.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 18),

            // Step indicator
            _buildStepIndicator(),
            const SizedBox(height: 20),

            if (_step == 0) _buildFormStep(),
            if (_step == 1) _buildQrisStep(),
            if (_step == 2) _buildSuccessStep(),
          ],
        ),
      ),
    );
  }

  Widget _buildStepIndicator() {
    final steps = ['Isi Form', 'Bayar', 'Selesai'];
    return Row(
      children: List.generate(steps.length, (i) {
        final active = i <= _step;
        final current = i == _step;
        return Expanded(
          child: Row(
            children: [
              Container(
                width: 26, height: 26,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: active ? AppColors.btnGrad : null,
                  color: active ? null : AppColors.dark,
                  border: Border.all(
                    color: active ? AppColors.accent : AppColors.border,
                    width: 1.5,
                  ),
                ),
                alignment: Alignment.center,
                child: current && _loading
                    ? SizedBox(
                        width: 12, height: 12,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _onAccent(),
                        ),
                      )
                    : Text('${i + 1}',
                        style: TextStyle(
                          color: active
                              ? _onAccent()
                              : AppColors.textHint,
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          fontFamily: kFont,
                        )),
              ),
              if (i < steps.length - 1)
                Expanded(
                  child: Container(
                    height: 2,
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    color: i < _step
                        ? AppColors.accent
                        : AppColors.border,
                  ),
                ),
            ],
          ),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  STEP 0: FORM INPUT
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildFormStep() {
    final p = widget.paket;
    return Column(
      children: [
        // Paket info
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.accent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: AppColors.accent.withOpacity(0.3),
              width: AppColors.borderWidth,
            ),
          ),
          child: Row(
            children: [
              Icon(Icons.shopping_bag_rounded,
                  color: AppColors.accent, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(p.label,
                        style: TextStyle(
                          color: AppColors.text,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          fontFamily: kFont,
                        )),
                    Text(p.durasi,
                        style: TextStyle(
                          color: AppColors.textSub,
                          fontSize: 11,
                          fontFamily: kFont,
                        )),
                  ],
                ),
              ),
              Text('Rp${p.harga}',
                  style: TextStyle(
                    color: AppColors.accent,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFont,
                  )),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // Input username
        TextField(
          controller: _userCtrl,
          style: TextStyle(
            color: AppColors.text,
            fontSize: 14,
            fontFamily: kFont,
          ),
          cursorColor: AppColors.accent,
          decoration: InputDecoration(
            labelText: 'Username Baru',
            hintText: 'contoh: Iwaktempej',
            prefixIcon: Icon(Icons.person_outline_rounded,
                color: AppColors.textHint),
            filled: true,
            fillColor: AppColors.dark,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        const SizedBox(height: 12),

        // Input password
        TextField(
          controller: _passCtrl,
          obscureText: true,
          style: TextStyle(
            color: AppColors.text,
            fontSize: 14,
            fontFamily: kFont,
          ),
          cursorColor: AppColors.accent,
          decoration: InputDecoration(
            labelText: 'Password Baru',
            hintText: 'contoh: xxxxbro',
            prefixIcon: Icon(Icons.lock_outline_rounded,
                color: AppColors.textHint),
            filled: true,
            fillColor: AppColors.dark,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        const SizedBox(height: 8),

        Text(
          '⚠️ Catat username & password! Tidak bisa diubah nanti.',
          style: TextStyle(
            color: AppColors.amber,
            fontSize: 11,
            fontFamily: kFont,
          ),
        ),
        const SizedBox(height: 20),

        // Tombol lanjut
        GestureDetector(
          onTap: _loading ? null : _submitForm,
          child: Container(
            height: 52,
            decoration: BoxDecoration(
              gradient: _loading ? null : AppColors.btnGrad,
              color: _loading ? AppColors.dark : null,
              borderRadius: BorderRadius.circular(14),
              border: ThemeModeManager.isComic3d
                  ? Border.all(color: AppColors.border, width: 3)
                  : null,
            ),
            alignment: Alignment.center,
            child: _loading
                ? SizedBox(
                    width: 20, height: 20,
                    child: CircularProgressIndicator(
                        color: _onAccent(), strokeWidth: 2),
                  )
                : Text('BUAT INVOICE',
                    style: TextStyle(
                      color: _onAccent(),
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      fontFamily: kFont,
                      letterSpacing: 1.5,
                    )),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  STEP 1: QRIS
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildQrisStep() {
    final sisaWaktu = _expiredAt > 0
        ? ((_expiredAt - DateTime.now().millisecondsSinceEpoch) / 1000)
            .clamp(0, 3600)
            .toInt()
        : 0;

    return Column(
      children: [
        Text('SCAN QRIS UNTUK BAYAR',
            style: TextStyle(
              color: AppColors.text,
              fontSize: 14,
              fontWeight: FontWeight.w800,
              fontFamily: kFont,
              letterSpacing: 1,
            )),
        const SizedBox(height: 6),
        Text('Bayar sesuai nominal, status akan otomatis terdeteksi',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.textSub,
              fontSize: 11,
              fontFamily: kFont,
            )),
        const SizedBox(height: 16),

        // QR Image
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppColors.accent.withOpacity(0.5),
              width: 3,
            ),
          ),
          child: _qrUrl != null
              ? Image.network(
                  _qrUrl!,
                  width: 220, height: 220,
                  fit: BoxFit.contain,
                  loadingBuilder: (_, child, p) => p == null
                      ? child
                      : const SizedBox(
                          width: 220, height: 220,
                          child: Center(
                              child: CircularProgressIndicator()),
                        ),
                  errorBuilder: (_, __, ___) => const SizedBox(
                    width: 220, height: 220,
                    child: Center(
                      child: Icon(Icons.broken_image, size: 60),
                    ),
                  ),
                )
              : const SizedBox(
                  width: 220, height: 220,
                  child: Center(child: CircularProgressIndicator()),
                ),
        ),
        const SizedBox(height: 16),

        // Nominal
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.accent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: AppColors.accent.withOpacity(0.3),
            ),
          ),
          child: Column(
            children: [
              Text('TOTAL BAYAR',
                  style: TextStyle(
                    color: AppColors.textSub,
                    fontSize: 10,
                    fontFamily: kFont,
                    letterSpacing: 1,
                  )),
              const SizedBox(height: 4),
              Text('Rp$_totalPayment',
                  style: TextStyle(
                    color: AppColors.accent,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFont,
                  )),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // Status polling
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 14, height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: AppColors.accent,
              ),
            ),
            const SizedBox(width: 10),
            Text('Menunggu pembayaran...',
                style: TextStyle(
                  color: AppColors.textSub,
                  fontSize: 12,
                  fontFamily: kFont,
                )),
          ],
        ),
        if (sisaWaktu > 0)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text('Kedaluwarsa dalam ${sisaWaktu}s',
                style: TextStyle(
                  color: AppColors.textHint,
                  fontSize: 10,
                  fontFamily: kFont,
                )),
          ),
        const SizedBox(height: 16),

        // Tombol batal
        GestureDetector(
          onTap: _cancelInvoice,
          child: Container(
            height: 46,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppColors.red.withOpacity(0.5),
                width: 1.5,
              ),
            ),
            alignment: Alignment.center,
            child: Text('BATAL',
                style: TextStyle(
                  color: AppColors.red,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  fontFamily: kFont,
                  letterSpacing: 1,
                )),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  STEP 2: SUKSES
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildSuccessStep() {
    return Column(
      children: [
        Container(
          width: 90, height: 90,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [AppColors.green, AppColors.accent],
            ),
            border: ThemeModeManager.isComic3d
                ? Border.all(color: AppColors.border, width: 3)
                : null,
          ),
          child: Icon(Icons.check_rounded,
              color: _onAccent(), size: 48),
        ),
        const SizedBox(height: 20),
        Text('PEMBAYARAN SUKSES',
            style: TextStyle(
              color: AppColors.text,
              fontSize: 16,
              fontWeight: FontWeight.w800,
              fontFamily: kFont,
              letterSpacing: 1,
            )),
        const SizedBox(height: 8),
        Text('Akun sudah otomatis dibuat',
            style: TextStyle(
              color: AppColors.textSub,
              fontSize: 12,
              fontFamily: kFont,
            )),
        const SizedBox(height: 20),

        // Credentials
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.dark,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: AppColors.border,
              width: AppColors.borderWidth,
            ),
          ),
          child: Column(
            children: [
              _infoRow(Icons.person, 'Username', _userCtrl.text.trim()),
              _infoRow(Icons.lock, 'Password', _passCtrl.text.trim()),
              _infoRow(Icons.workspace_premium, 'Paket', widget.paket.label),
              _infoRow(Icons.timer, 'Durasi', widget.paket.durasi),
            ],
          ),
        ),
        const SizedBox(height: 20),

        GestureDetector(
          onTap: () {
            // Copy credential ke clipboard
            Clipboard.setData(ClipboardData(
              text: 'User: ${_userCtrl.text.trim()}\n'
                  'Pass: ${_passCtrl.text.trim()}\n'
                  'Paket: ${widget.paket.label}',
            ));
            _toast('Disalin ke clipboard ✅', AppColors.green);
          },
          child: Container(
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppColors.accent.withOpacity(0.4),
              ),
            ),
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.copy_rounded,
                    color: AppColors.accent, size: 16),
                const SizedBox(width: 8),
                Text('Salin Akun',
                    style: TextStyle(
                      color: AppColors.accent,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      fontFamily: kFont,
                    )),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),

        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              gradient: AppColors.btnGrad,
              borderRadius: BorderRadius.circular(14),
              border: ThemeModeManager.isComic3d
                  ? Border.all(color: AppColors.border, width: 3)
                  : null,
            ),
            alignment: Alignment.center,
            child: Text('SELESAI',
                style: TextStyle(
                  color: _onAccent(),
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  fontFamily: kFont,
                  letterSpacing: 1.5,
                )),
          ),
        ),
      ],
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: AppColors.accent, size: 16),
          const SizedBox(width: 10),
          Text(label,
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 12,
                fontFamily: kFont,
              )),
          const Spacer(),
          Text(value,
              style: TextStyle(
                color: AppColors.text,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: kFont,
              )),
        ],
      ),
    );
  }
}