// login_page.dart
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';

import 'theme.dart';
import 'splash.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';
const String baseUrl = 'http://digital.mypanelku.web.id:2041';

// ─── PALETTE (alias ke AppColors dinamis) ──────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get glassBg   => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static Color get primary      => AppColors.accentMid;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark  => AppColors.accentDark;

  static Color get accent    => AppColors.accentLight;
  static Color get success   => AppColors.green;
  static Color get secondary => AppColors.accent;
  static Color get white     => AppColors.text;
  static Color get whiteDim  => AppColors.textSub;
  static Color get black     => AppColors.bg;
  static Color get text      => AppColors.text;
  static Color get textSub   => AppColors.textSub;
  static Color get textDim   => AppColors.textHint;
  static Color get textDark  => AppColors.textHint;

  static Color get green     => AppColors.green;
  static Color get amber     => AppColors.amber;
  static Color get red       => AppColors.red;
  static Color get grey      => AppColors.accent;
  static Color get greyMid   => AppColors.accentMid;
  static Color get greyLight => AppColors.accentLight;
  static Color get greyDark  => AppColors.accentDark;

  static LinearGradient get glassGrad   => AppColors.glassGrad;
  static List<BoxShadow> get softShadow => AppColors.softShadow;
  static List<BoxShadow> get glowShadow => AppColors.glassShadow;
  static LinearGradient get btnGrad     => AppColors.btnGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ────────────────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  bool _obscurePass = true;
  String? _androidId;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _shakeCtrl;

  late Animation<double> _fade;
  late Animation<Offset> _slide;
  late Animation<double> _btnPulse;
  late Animation<double> _shake;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 18))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600))
      ..repeat(reverse: true);
    _btnPulse = Tween<double>(begin: 1.0, end: 1.03)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -10.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10.0, end: 10.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -7.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -7.0, end: 7.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 7.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _entranceCtrl.forward();
    _initLogin();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _btnCtrl.dispose();
    _shakeCtrl.dispose();
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  Future<void> _initLogin() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      _androidId = info.id;

      final prefs = await SharedPreferences.getInstance();
      final savedUser = prefs.getString('username');
      final savedPass = prefs.getString('password');
      final savedKey = prefs.getString('key');

      if (savedUser != null && savedPass != null && savedKey != null) {
        final res = await http.get(Uri.parse(
            '$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$_androidId&key=$savedKey'));
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => SplashScreen(
              username: savedUser, password: savedPass,
              role: data['role'], sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug: _parseList(data['listBug']),
              listDoos: _parseList(data['listDDoS']),
              news: _parseList(data['news']),
            )),
          );
        }
      }
    } catch (_) {}
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      final res = await http.post(Uri.parse('$baseUrl/validate'), body: {
        'username': username,
        'password': password,
        'androidId': _androidId ?? 'unknown',
      });
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          type: _AlertType.warning,
          showContact: true,
        );
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') ||
            msg.contains('another')) {
          _showAlert(
            title: 'Sesi Aktif',
            message: 'Akun ini sedang login di perangkat lain.',
            type: _AlertType.warning,
          );
        } else {
          _showAlert(
            title: 'Login Gagal',
            message: 'Username atau password salah.',
            type: _AlertType.error,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => SplashScreen(
              username: username, password: password,
              role: data['role'], sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug: _parseList(data['listBug']),
              listDoos: _parseList(data['listDDoS']),
              news: _parseList(data['news']),
            )),
          );
        }
      }
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _showAlert(
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type: _AlertType.error,
      );
    }

    if (mounted) setState(() => _isLoading = false);
  }

  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    final color = switch (type) {
      _AlertType.error => _C.red,
      _AlertType.warning => _C.amber,
      _AlertType.success => _C.green,
    };
    final icon = switch (type) {
      _AlertType.error => Icons.error_rounded,
      _AlertType.warning => Icons.warning_amber_rounded,
      _AlertType.success => Icons.check_circle_rounded,
    };

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                  color: _C.glassBorder,
                  width: isComic ? 3 : 1.5,
                ),
                boxShadow: _C.glassShadow,
              ),
              padding: const EdgeInsets.all(28),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color.withOpacity(0.1),
                    border: Border.all(color: color.withOpacity(0.2)),
                  ),
                  child: Icon(icon, color: color, size: 28),
                ),
                const SizedBox(height: 16),
                Text(title,
                    style: TextStyle(
                        color: _C.text,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        fontFamily: kFont)),
                const SizedBox(height: 8),
                Text(message,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: _C.textSub,
                        fontSize: 13,
                        height: 1.5,
                        fontFamily: kFont)),
                const SizedBox(height: 22),
                if (showContact) ...[
                  _GradBtn(
                    label: 'Hubungi Admin',
                    fullWidth: true,
                    onTap: () async {
                      Navigator.pop(ctx);
                      await launchUrl(Uri.parse('https://t.me/ameluchuu'),
                          mode: LaunchMode.externalApplication);
                    },
                  ),
                  const SizedBox(height: 10),
                ],
                _OutlineBtn(
                  label: showContact ? 'Tutup' : 'OK',
                  fullWidth: true,
                  onTap: () => Navigator.pop(ctx),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ⚡ AUTO REBUILD SAAT TEMA GANTI
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          body: AppBackground(
            controller: _bgCtrl,
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slide,
                  child: Center(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 24),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          AnimatedBuilder(
                            animation: _shake,
                            builder: (_, child) => Transform.translate(
                              offset: Offset(_shake.value, 0),
                              child: child,
                            ),
                            child: _buildFormCard(),
                          ),
                          const SizedBox(height: 20),
                          _buildFooter(),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildFormCard() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      decoration: BoxDecoration(
        gradient: isComic ? null : _C.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: isComic ? AppColors.border : _C.glassBorder,
          width: AppColors.borderWidth,
        ),
        boxShadow: _C.glassShadow,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(AppColors.cardRadius),
              topRight: Radius.circular(AppColors.cardRadius),
            ),
            child: Image.asset(
              'assets/images/1.jpg',
              height: 160,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 160,
                width: double.infinity,
                color: _C.cardAlt,
                child: Center(
                  child: Icon(Icons.image_rounded,
                      color: _C.textDim, size: 40),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  _LoginField(
                    controller: userCtrl,
                    hintText: 'Username',
                    prefixIcon: Icons.person_outline_rounded,
                    validator: (v) => (v == null || v.isEmpty)
                        ? 'Username tidak boleh kosong' : null,
                  ),
                  const SizedBox(height: 14),
                  _LoginField(
                    controller: passCtrl,
                    hintText: 'Password',
                    prefixIcon: Icons.lock_outline_rounded,
                    obscure: _obscurePass,
                    onToggleObscure: () =>
                        setState(() => _obscurePass = !_obscurePass),
                    validator: (v) => (v == null || v.isEmpty)
                        ? 'Password tidak boleh kosong' : null,
                  ),
                  const SizedBox(height: 24),
                  _LoginButton(
                    isLoading: _isLoading,
                    pulseAnim: _btnPulse,
                    onTap: _login,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Center(
      child: Text(
        '© 2026 Copyright By ameluchuu',
        style: TextStyle(
          color: _C.textDim,
          fontSize: 11,
          fontFamily: kFont,
        ),
      ),
    );
  }
}

class _LoginField extends StatefulWidget {
  final TextEditingController controller;
  final String hintText;
  final IconData prefixIcon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _LoginField({
    required this.controller,
    required this.hintText,
    required this.prefixIcon,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_LoginField> createState() => _LoginFieldState();
}

class _LoginFieldState extends State<_LoginField> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: _C.surface.withOpacity(isComic ? 1.0 : 0.7),
        borderRadius: BorderRadius.circular(isComic ? 4 : 12),
        border: Border.all(
          color: _focused ? _C.primaryLight : _C.border,
          width: _focused
              ? (isComic ? 3 : 1.5)
              : AppColors.borderWidth,
        ),
        boxShadow: _focused && !isComic
            ? [
                BoxShadow(
                    color: _C.primary.withOpacity(0.15),
                    blurRadius: 14,
                    offset: const Offset(0, 4))
              ]
            : [],
      ),
      child: TextFormField(
        controller: widget.controller,
        focusNode: _focus,
        obscureText: widget.obscure,
        validator: widget.validator,
        style: TextStyle(
            color: _C.text,
            fontSize: 15,
            fontWeight: FontWeight.w500,
            fontFamily: kFont),
        cursorColor: _C.primaryLight,
        decoration: InputDecoration(
          hintText: widget.hintText,
          hintStyle: TextStyle(
              color: _C.textSub.withOpacity(0.7),
              fontSize: 14,
              fontFamily: kFont),
          prefixIcon: Icon(widget.prefixIcon,
              color: _focused ? _C.primaryLight : _C.textSub, size: 20),
          suffixIcon: widget.onToggleObscure != null
              ? IconButton(
                  icon: Icon(
                    widget.obscure
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: _C.textSub,
                    size: 20,
                  ),
                  onPressed: widget.onToggleObscure,
                )
              : null,
          errorStyle:
              TextStyle(color: _C.red, fontSize: 11, fontFamily: kFont),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }
}

class _LoginButton extends StatefulWidget {
  final bool isLoading;
  final Animation<double> pulseAnim;
  final VoidCallback onTap;

  const _LoginButton({
    required this.isLoading,
    required this.pulseAnim,
    required this.onTap,
  });

  @override
  State<_LoginButton> createState() => _LoginButtonState();
}

class _LoginButtonState extends State<_LoginButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedBuilder(
        animation: widget.pulseAnim,
        builder: (_, __) => Transform.scale(
          scale: widget.isLoading || _down ? 1.0 : widget.pulseAnim.value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            height: 54,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: _C.btnGrad,
              borderRadius: BorderRadius.circular(isComic ? 4 : 12),
              border: isComic
                  ? Border.all(color: AppColors.border, width: 3)
                  : null,
              boxShadow: _down || widget.isLoading
                  ? (isComic ? AppColors.softShadow : [])
                  : (isComic
                      ? AppColors.softShadow
                      : [
                          BoxShadow(
                            color: _C.primary.withOpacity(
                                widget.pulseAnim.value * 0.3),
                            blurRadius: 22,
                            offset: const Offset(0, 6),
                          ),
                        ]),
            ),
            child: Center(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                child: widget.isLoading
                    ? const SizedBox(
                        key: ValueKey('loading'),
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2.5, color: Colors.white),
                      )
                    : Row(
                        key: const ValueKey('idle'),
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.login_rounded,
                              color: _onAccent(), size: 18),
                          const SizedBox(width: 10),
                          Text('Login',
                              style: TextStyle(
                                color: _onAccent(),
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.3,
                                fontFamily: kFont,
                              )),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;

  const _GradBtn({
    required this.label,
    required this.onTap,
    this.fullWidth = false,
  });

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            border: isComic
                ? Border.all(color: AppColors.border, width: 2)
                : null,
            boxShadow: _down || isComic
                ? (isComic ? AppColors.softShadow : [])
                : [
                    BoxShadow(
                        color: _C.primary.withOpacity(0.2),
                        blurRadius: 14,
                        offset: const Offset(0, 4)),
                  ],
          ),
          child: Center(
            child: Text(widget.label,
                style: TextStyle(
                    color: _onAccent(),
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    fontFamily: kFont)),
          ),
        ),
      ),
    );
  }
}

class _OutlineBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;

  const _OutlineBtn({
    required this.label,
    required this.onTap,
    this.fullWidth = false,
  });

  @override
  State<_OutlineBtn> createState() => _OutlineBtnState();
}

class _OutlineBtnState extends State<_OutlineBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        height: 46,
        width: widget.fullWidth ? double.infinity : null,
        decoration: BoxDecoration(
          color: _down ? _C.border.withOpacity(0.3) : Colors.transparent,
          borderRadius: BorderRadius.circular(isComic ? 4 : 12),
          border: Border.all(
            color: isComic ? AppColors.border : _C.glassBorder,
            width: isComic ? 3 : 1,
          ),
        ),
        child: Center(
          child: Text(widget.label,
              style: TextStyle(
                  color: _C.textSub,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  fontFamily: kFont)),
        ),
      ),
    );
  }
}

enum _AlertType { error, warning, success }