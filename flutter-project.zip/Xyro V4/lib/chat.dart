// chat.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';
const String _kBase = 'http://digital.mypanelku.web.id:2041';

// ─── PALETTE ───────────────────────────────────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;

  static Color get primary    => AppColors.accent;
  static Color get primaryMid => AppColors.accentMid;
  static Color get primaryLt  => AppColors.accentLight;
  static Color get primaryDk  => AppColors.accentDark;

  static Color get green => AppColors.green;
  static Color get amber => AppColors.amber;
  static Color get red   => AppColors.red;

  static Color get text    => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get textDim => AppColors.textHint;

  static LinearGradient get btnGrad => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ═══════════════════════════════════════════════════════════════════════
//  MODEL — ChatMessage
// ═══════════════════════════════════════════════════════════════════════
class ChatMessage {
  final String id;
  final String from;
  final String role;
  final String type;    // 'text' | 'image' | 'video'
  final String content; // text atau base64
  final String mime;
  final int timestamp;
  final bool fromMe;

  ChatMessage({
    required this.id,
    required this.from,
    required this.role,
    required this.type,
    required this.content,
    required this.mime,
    required this.timestamp,
    required this.fromMe,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> j, String myUsername) {
    final from = j['from']?.toString() ?? 'unknown';
    return ChatMessage(
      id: j['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      from: from,
      role: j['role']?.toString() ?? 'member',
      type: j['type']?.toString() ?? 'text',
      content: j['content']?.toString() ?? '',
      mime: j['mime']?.toString() ?? '',
      timestamp: j['timestamp'] is int
          ? j['timestamp']
          : (j['timestamp'] is num
              ? (j['timestamp'] as num).toInt()
              : DateTime.now().millisecondsSinceEpoch),
      fromMe: from == myUsername,
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  CHAT PAGE
// ═══════════════════════════════════════════════════════════════════════
class ChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _focusNode = FocusNode();

  final ImagePicker _picker = ImagePicker();

  final List<ChatMessage> _messages = [];
  final Set<String> _onlineUsers = {};
  final Map<String, String> _onlineRoles = {};

  Timer? _pollTimer;
  Timer? _onlineTimer;

  int _lastTs = 0;
  bool _loading = true;
  bool _sending = false;
  bool _uploadingMedia = false;
  bool _showEmoji = false;

  @override
  void initState() {
    super.initState();
    _loadInitial();
    _startPolling();
    _startOnlinePolling();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _onlineTimer?.cancel();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  //  LOAD INITIAL
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _loadInitial() async {
    try {
      final res = await http.get(Uri.parse(
        '$_kBase/chat/messages?key=${Uri.encodeComponent(widget.sessionKey)}&limit=100',
      ));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        final list = (data['messages'] as List?) ?? [];
        setState(() {
          _messages.clear();
          for (final m in list) {
            _messages.add(ChatMessage.fromJson(
              Map<String, dynamic>.from(m),
              widget.username,
            ));
          }
          _lastTs = data['serverTime'] is int
              ? data['serverTime']
              : (data['serverTime'] is num
                  ? (data['serverTime'] as num).toInt()
                  : DateTime.now().millisecondsSinceEpoch);
          _loading = false;
        });
        _scrollToBottom(instant: true);
      } else {
        setState(() => _loading = false);
      }
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  POLLING PESAN BARU
  // ═══════════════════════════════════════════════════════════════════
  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      if (!mounted) return;
      try {
        final res = await http.get(Uri.parse(
          '$_kBase/chat/messages?key=${Uri.encodeComponent(widget.sessionKey)}'
          '&since=$_lastTs&limit=100',
        ));
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          final list = (data['messages'] as List?) ?? [];
          if (list.isNotEmpty) {
            setState(() {
              for (final m in list) {
                final msg = ChatMessage.fromJson(
                  Map<String, dynamic>.from(m),
                  widget.username,
                );
                // Cegah duplikat
                if (!_messages.any((x) => x.id == msg.id)) {
                  _messages.add(msg);
                }
              }
              _lastTs = data['serverTime'] is int
                  ? data['serverTime']
                  : (data['serverTime'] is num
                      ? (data['serverTime'] as num).toInt()
                      : DateTime.now().millisecondsSinceEpoch);
            });
            _scrollToBottom();
          }
        }
      } catch (_) {}
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  //  POLLING USER ONLINE
  // ═══════════════════════════════════════════════════════════════════
  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (_) async {
      if (!mounted) return;
      try {
        final res = await http.get(Uri.parse(
          '$_kBase/chat/online?key=${Uri.encodeComponent(widget.sessionKey)}',
        ));
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          final list = (data['online'] as List?) ?? [];
          setState(() {
            _onlineUsers.clear();
            _onlineRoles.clear();
            for (final u in list) {
              final name = u['username']?.toString();
              final role = u['role']?.toString() ?? 'member';
              if (name != null) {
                _onlineUsers.add(name);
                _onlineRoles[name] = role;
              }
            }
          });
        }
      } catch (_) {}
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  //  KIRIM PESAN TEKS
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _sendText() async {
    final txt = _msgCtrl.text.trim();
    if (txt.isEmpty || _sending) return;

    setState(() => _sending = true);

    // Optimistic UI — langsung tampil
    final optimistic = ChatMessage(
      id: 'local_${DateTime.now().microsecondsSinceEpoch}',
      from: widget.username,
      role: widget.role,
      type: 'text',
      content: txt,
      mime: '',
      timestamp: DateTime.now().millisecondsSinceEpoch,
      fromMe: true,
    );
    setState(() {
      _messages.add(optimistic);
      _msgCtrl.clear();
    });
    _scrollToBottom();

    try {
      final res = await http.get(Uri.parse(
        '$_kBase/chat/send'
        '?key=${Uri.encodeComponent(widget.sessionKey)}'
        '&text=${Uri.encodeComponent(txt)}',
      ));
      final data = jsonDecode(res.body);
      if (data['success'] != true) {
        _snack(data['message']?.toString() ?? 'Gagal kirim');
        // Rollback
        setState(() => _messages.removeWhere((m) => m.id == optimistic.id));
      } else {
        // Ganti id dengan id server
        final serverMsg = data['message'];
        if (serverMsg is Map) {
          final real = ChatMessage.fromJson(
            Map<String, dynamic>.from(serverMsg),
            widget.username,
          );
          setState(() {
            final idx = _messages.indexWhere((m) => m.id == optimistic.id);
            if (idx != -1) _messages[idx] = real;
          });
        }
      }
    } catch (e) {
      _snack('Error: $e');
      setState(() => _messages.removeWhere((m) => m.id == optimistic.id));
    } finally {
      if (mounted) setState(() => _sending = false);
    }

    _focusNode.requestFocus();
  }

  // ═══════════════════════════════════════════════════════════════════
  //  KIRIM MEDIA (IMAGE / VIDEO)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _pickMedia({required bool isVideo}) async {
    if (_uploadingMedia) return;

    try {
      final XFile? file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: isVideo ? 50 : 70,
      );
      if (file == null) return;

      final bytes = await file.readAsBytes();
      final sizeMb = bytes.length / (1024 * 1024);

      if (sizeMb > 4.5) {
        _snack('File terlalu besar (max 4.5MB)');
        return;
      }

      setState(() => _uploadingMedia = true);

      final base64Str = base64Encode(bytes);
      final mime = file.mimeType ??
          (isVideo ? 'video/mp4' : 'image/jpeg');

      final res = await http.post(
        Uri.parse('$_kBase/chat/send-media'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'type': isVideo ? 'video' : 'image',
          'mime': mime,
          'content': base64Str,
        }),
      );

      final data = jsonDecode(res.body);
      if (data['success'] != true) {
        _snack(data['message']?.toString() ?? 'Gagal kirim');
      } else {
        _snack('${isVideo ? "Video" : "Foto"} terkirim');
        // Langsung tambah ke list biar cepet muncul
        final serverMsg = data['message'];
        if (serverMsg is Map) {
          final real = ChatMessage.fromJson(
            Map<String, dynamic>.from(serverMsg),
            widget.username,
          );
          setState(() => _messages.add(real));
          _scrollToBottom();
        }
      }
    } catch (e) {
      _snack('Gagal kirim: $e');
    } finally {
      if (mounted) setState(() => _uploadingMedia = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  HELPER
  // ═══════════════════════════════════════════════════════════════════
  void _scrollToBottom({bool instant = false}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        if (instant) {
          _scrollCtrl.jumpTo(_scrollCtrl.position.maxScrollExtent);
        } else {
          _scrollCtrl.animateTo(
            _scrollCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
          );
        }
      }
    });
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(color: _onAccent(), fontFamily: kFont)),
      backgroundColor: _C.primaryDk,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 2),
    ));
  }

  String _formatTime(int ms) {
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':     return const Color(0xFFFFD700);
      case 'admin':     return const Color(0xFFE53935);
      case 'moderator': return const Color(0xFFFF9800);
      case 'partner':   return const Color(0xFF9C27B0);
      case 'reseller':  return const Color(0xFF00BCD4);
      case 'vip':       return const Color(0xFF4CAF50);
      case 'premium':   return const Color(0xFF3F51B5);
      default:          return const Color(0xFF9E9E9E);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (_, __, ___) {
        return Scaffold(
          backgroundColor: _C.bg,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: Icon(Icons.arrow_back_ios_new_rounded,
                  color: _C.text, size: 18),
            ),
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.green,
                    boxShadow: [
                      BoxShadow(
                        color: _C.green.withOpacity(0.6),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'GLOBAL CHAT',
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFont,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: _C.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${_onlineUsers.length}',
                    style: TextStyle(
                      color: _C.green,
                      fontFamily: kFont,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            centerTitle: true,
            actions: [
              IconButton(
                onPressed: _showOnlineSheet,
                icon: Icon(Icons.people_alt_rounded,
                    color: _C.primaryLt, size: 20),
              ),
            ],
          ),
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  Expanded(
                    child: _loading
                        ? _loadingState()
                        : _messages.isEmpty
                            ? _emptyState()
                            : ListView.builder(
                                controller: _scrollCtrl,
                                padding: const EdgeInsets.fromLTRB(
                                    12, 8, 12, 8),
                                itemCount: _messages.length,
                                itemBuilder: (_, i) {
                                  final m = _messages[i];
                                  final prev =
                                      i > 0 ? _messages[i - 1] : null;
                                  final showHeader = prev == null ||
                                      prev.from != m.from;
                                  return _buildMessage(
                                      m, showHeader, isComic);
                                },
                              ),
                  ),
                  if (_showEmoji) _buildEmojiPicker(),
                  _buildInputBar(isComic),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  STATES
  // ═══════════════════════════════════════════════════════════════════
  Widget _loadingState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 30, height: 30,
            child: CircularProgressIndicator(
              strokeWidth: 2, color: _C.primaryLt,
            ),
          ),
          const SizedBox(height: 12),
          Text('Memuat chat...',
              style: TextStyle(
                color: _C.textSub,
                fontFamily: kFont,
                fontSize: 12,
              )),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.forum_outlined,
              color: _C.primaryLt.withOpacity(0.4), size: 60),
          const SizedBox(height: 12),
          Text('Belum ada pesan',
              style: TextStyle(
                color: _C.textSub,
                fontFamily: kFont,
                fontSize: 13,
              )),
          const SizedBox(height: 4),
          Text('Mulai obrolan global!',
              style: TextStyle(
                color: _C.textDim,
                fontFamily: kFont,
                fontSize: 11,
              )),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  MESSAGE BUBBLE
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildMessage(ChatMessage m, bool showHeader, bool isComic) {
    final fromMe = m.fromMe;
    final roleColor = _roleColor(m.role);

    return Padding(
      padding: EdgeInsets.only(
        top: showHeader ? 10 : 2,
        bottom: 2,
      ),
      child: Row(
        mainAxisAlignment:
            fromMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!fromMe) ...[
            _avatar(m.from, roleColor, 34),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: fromMe
                  ? CrossAxisAlignment.end
                  : CrossAxisAlignment.start,
              children: [
                if (showHeader && !fromMe)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4, left: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          m.from,
                          style: TextStyle(
                            color: _C.text,
                            fontFamily: kFont,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 6),
                        _roleBadge(m.role),
                      ],
                    ),
                  ),
                GestureDetector(
                  onLongPress: () => _showMessageOptions(m),
                  child: Container(
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.7,
                    ),
                    padding: m.type == 'text'
                        ? const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8)
                        : const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      gradient: fromMe ? _C.btnGrad : null,
                      color: fromMe ? null : _C.card,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(isComic ? 4 : 14),
                        topRight: Radius.circular(isComic ? 4 : 14),
                        bottomLeft: Radius.circular(
                            fromMe ? (isComic ? 4 : 14) : 4),
                        bottomRight: Radius.circular(
                            fromMe ? 4 : (isComic ? 4 : 14)),
                      ),
                      border: Border.all(
                        color: fromMe
                            ? Colors.transparent
                            : _C.border,
                        width: AppColors.borderWidth,
                      ),
                    ),
                    child: _bubbleContent(m, fromMe, isComic),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 2, left: 4, right: 4),
                  child: Text(
                    _formatTime(m.timestamp),
                    style: TextStyle(
                      color: _C.textDim,
                      fontFamily: kFont,
                      fontSize: 9,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (fromMe) ...[
            const SizedBox(width: 8),
            _avatar(m.from, roleColor, 34),
          ],
        ],
      ),
    );
  }

  Widget _bubbleContent(ChatMessage m, bool fromMe, bool isComic) {
    switch (m.type) {
      case 'image':
        return ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 4 : 12),
          child: _buildBase64Media(m.content, false),
        );
      case 'video':
        return Stack(
          alignment: Alignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(isComic ? 4 : 12),
              child: _buildBase64Media(m.content, true),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black.withOpacity(0.5),
              ),
              child: const Icon(Icons.play_arrow_rounded,
                  color: Colors.white, size: 28),
            ),
          ],
        );
      default:
        return Text(
          m.content,
          style: TextStyle(
            color: fromMe ? _onAccent() : _C.text,
            fontFamily: kFont,
            fontSize: 13,
            height: 1.4,
          ),
        );
    }
  }

  Widget _buildBase64Media(String base64Str, bool isVideo) {
    try {
      final bytes = base64Decode(base64Str);
      if (isVideo) {
        return Container(
          width: 200, height: 200,
          color: Colors.black26,
          child: const Icon(Icons.videocam_rounded,
              color: Colors.white54, size: 60),
        );
      }
      return Image.memory(
        Uint8List.fromList(bytes),
        width: 200,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          width: 200, height: 100,
          color: _C.cardAlt,
          child: const Icon(Icons.broken_image, color: Colors.white54),
        ),
      );
    } catch (_) {
      return Container(
        padding: const EdgeInsets.all(8),
        color: _C.cardAlt,
        child: Text('[media rusak]',
            style: TextStyle(color: _C.textDim, fontFamily: kFont)),
      );
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  AVATAR + ROLE BADGE
  // ═══════════════════════════════════════════════════════════════════
  Widget _avatar(String username, Color color, double size) {
    final initial = username.isNotEmpty ? username[0].toUpperCase() : '?';
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [color, color.withOpacity(0.6)],
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.4),
            blurRadius: 6,
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Text(
        initial,
        style: TextStyle(
          color: Colors.white,
          fontFamily: kFont,
          fontWeight: FontWeight.bold,
          fontSize: size * 0.45,
        ),
      ),
    );
  }

  Widget _roleBadge(String role) {
    final c = _roleColor(role);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: c.withOpacity(0.2),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: c.withOpacity(0.5), width: 1),
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(
          color: c,
          fontFamily: kFont,
          fontSize: 8,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  INPUT BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInputBar(bool isComic) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        gradient: isComic ? null : _C.glassGrad,
        color: isComic ? _C.card : null,
        border: Border(
          top: BorderSide(
            color: _C.border,
            width: AppColors.borderWidth,
          ),
        ),
      ),
      child: Row(
        children: [
          _iconBtn(
            icon: _showEmoji
                ? Icons.keyboard_rounded
                : Icons.emoji_emotions_outlined,
            color: _C.amber,
            onTap: () {
              setState(() => _showEmoji = !_showEmoji);
              if (!_showEmoji) _focusNode.requestFocus();
            },
          ),
          const SizedBox(width: 6),
          _iconBtn(
            icon: Icons.image_rounded,
            color: _C.primaryLt,
            onTap: _uploadingMedia
                ? null
                : () => _pickMedia(isVideo: false),
          ),
          const SizedBox(width: 6),
          _iconBtn(
            icon: Icons.videocam_rounded,
            color: _C.green,
            onTap: _uploadingMedia
                ? null
                : () => _pickMedia(isVideo: true),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(isComic ? 4 : 20),
                border: Border.all(
                  color: _C.border,
                  width: AppColors.borderWidth,
                ),
              ),
              child: TextField(
                controller: _msgCtrl,
                focusNode: _focusNode,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendText(),
                style: TextStyle(
                  color: _C.text,
                  fontFamily: kFont,
                  fontSize: 13,
                ),
                maxLines: 4,
                minLines: 1,
                decoration: InputDecoration(
                  hintText: 'Ketik pesan...',
                  hintStyle: TextStyle(
                    color: _C.textDim,
                    fontFamily: kFont,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _sending ? null : _sendText,
            child: Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                gradient: _C.btnGrad,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _C.primary.withOpacity(0.4),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: _sending
                  ? Center(
                      child: SizedBox(
                        width: 18, height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: _onAccent()),
                      ),
                    )
                  : Icon(Icons.send_rounded,
                      color: _onAccent(), size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _iconBtn({
    required IconData icon,
    required Color color,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color.withOpacity(0.15),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Icon(icon, color: color, size: 20),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  EMOJI PICKER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildEmojiPicker() {
    const emojis = [
      '😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃',
      '😉','😊','😇','🥰','😍','🤩','😘','😗','😚','😙',
      '🥲','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫',
      '🤔','🤐','🤨','😐','😑','😶','😏','😒','🙄','😬',
      '😮‍💨','🤥','😌','😔','😪','🤤','😴','😷','🤒','🤕',
      '🤢','🤮','🥵','🥶','😵','🤯','🤠','🥳','🥺','😢',
      '😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤',
      '😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👹',
      '❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔',
      '❣️','💕','💞','💓','💗','💖','💘','💝','💟','☮️',
      '👍','👎','👌','✌️','🤞','🤟','🤘','🤙','👈','👉',
      '👆','👇','☝️','✋','🤚','🖐','🖖','👋','🤝','🙏',
      '💪','🦾','🦿','🦵','🦶','👂','🦻','👃','🧠','🦷',
      '🔥','💯','✨','⭐','🌟','💫','⚡','☄️','💥','🌪',
      '🌈','☀️','🌤','⛅','🌥','☁️','🌦','🌧','⛈','🌩',
      '🎉','🎊','🎈','🎁','🎀','🎂','🍰','🧁','🍕','🍔',
      '🍟','🌭','🍿','🥤','🍺','🍻','🥂','🍷','🍸','🍹',
      '⚽','🏀','🏈','⚾','🎾','🏐','🏉','🎱','🏓','🏸',
      '🚗','🚕','🚙','🚌','🚎','🏎','🚓','🚑','🚒','🚐',
    ];

    return Container(
      height: 200,
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
      ),
      child: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 8,
          mainAxisSpacing: 4,
          crossAxisSpacing: 4,
        ),
        itemCount: emojis.length,
        itemBuilder: (_, i) {
          return GestureDetector(
            onTap: () {
              _msgCtrl.text += emojis[i];
              _msgCtrl.selection = TextSelection.fromPosition(
                TextPosition(offset: _msgCtrl.text.length),
              );
            },
            child: Container(
              alignment: Alignment.center,
              child: Text(emojis[i], style: const TextStyle(fontSize: 20)),
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  MESSAGE OPTIONS
  // ═══════════════════════════════════════════════════════════════════
  void _showMessageOptions(ChatMessage m) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40, height: 4,
              margin: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            if (m.type == 'text')
              ListTile(
                leading: Icon(Icons.copy_rounded, color: _C.primaryLt),
                title: Text('Copy teks',
                    style: TextStyle(color: _C.text, fontFamily: kFont)),
                onTap: () {
                  Navigator.pop(context);
                  _snack('Pesan dicopy');
                },
              ),
            if (m.fromMe || widget.role == 'owner')
              ListTile(
                leading: Icon(Icons.delete_rounded, color: _C.red),
                title: Text('Hapus',
                    style: TextStyle(color: _C.text, fontFamily: kFont)),
                onTap: () async {
                  Navigator.pop(context);
                  await _deleteMessage(m);
                },
              ),
            ListTile(
              leading: Icon(Icons.info_outline_rounded, color: _C.textSub),
              title: Text('Info',
                  style: TextStyle(color: _C.text, fontFamily: kFont)),
              onTap: () {
                Navigator.pop(context);
                _snack('Dari: ${m.from} | Role: ${m.role}');
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Future<void> _deleteMessage(ChatMessage m) async {
    try {
      final res = await http.get(Uri.parse(
        '$_kBase/chat/delete?key=${Uri.encodeComponent(widget.sessionKey)}'
        '&messageId=${Uri.encodeComponent(m.id)}',
      ));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        setState(() => _messages.removeWhere((x) => x.id == m.id));
        _snack('Pesan dihapus');
      } else {
        _snack(data['message']?.toString() ?? 'Gagal hapus');
      }
    } catch (e) {
      _snack('Error: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ONLINE USERS SHEET
  // ═══════════════════════════════════════════════════════════════════
  void _showOnlineSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.people_alt_rounded, color: _C.primaryLt),
                const SizedBox(width: 8),
                Text('Online (${_onlineUsers.length})',
                    style: TextStyle(
                      color: _C.text,
                      fontFamily: kFont,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    )),
              ],
            ),
            const SizedBox(height: 12),
            if (_onlineUsers.isEmpty)
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text('Tidak ada user online',
                    style: TextStyle(
                      color: _C.textDim, fontFamily: kFont, fontSize: 12)),
              )
            else
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  children: _onlineUsers.map((u) {
                    final role = _onlineRoles[u] ?? 'member';
                    final c = _roleColor(role);
                    return ListTile(
                      dense: true,
                      leading: _avatar(u, c, 32),
                      title: Text(u,
                          style: TextStyle(
                              color: _C.text,
                              fontFamily: kFont,
                              fontSize: 13,
                              fontWeight: FontWeight.w600)),
                      trailing: _roleBadge(role),
                    );
                  }).toList(),
                ),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}