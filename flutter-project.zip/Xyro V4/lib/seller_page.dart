// buy_reseller.dart
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';
const String _kBase = 'http://digital.mypanelku.web.id:2041';

// ─── PALETTE ───────────────────────────────────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;

  static Color get primary    => AppColors.accent;
  static Color get primaryMid => AppColors.accentMid;
  static Color get primaryLt  => AppColors.accentLight;
  static Color get primaryDk  => AppColors.accentDark;

  static Color get green => AppColors.green;
  static Color get amber => AppColors.amber;
  static Color get red   => AppColors.red;

  static Color get text    => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get textDim => AppColors.textHint;

  static LinearGradient get btnGrad => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow => AppColors.softShadow;
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ═══════════════════════════════════════════════════════════════════════
//  SELLER PAGE  ← (dulu BuyResellerPage)
// ═══════════════════════════════════════════════════════════════════════
class SellerPage extends StatefulWidget {
  final String keyToken;      // ← pakai keyToken (biar cocok sama dashboard & main)
  final String? username;     // ← opsional

  const SellerPage({
    super.key,
    required this.keyToken,
    this.username,
  });

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _dayCtrl = TextEditingController(text: '30');

  bool _isLoading = false;
  bool _isCheckingUsername = false;
  bool? _usernameAvailable;
  String? _usernameMsg;

  Timer? _checkUsernameDebounce;

  // ─── Alias biar gampang ───
  String get sessionKey => widget.keyToken;

  @override
  void initState() {
    super.initState();
    _usernameCtrl.addListener(_onUsernameChanged);
  }

  @override
  void dispose() {
    _checkUsernameDebounce?.cancel();
    _usernameCtrl.removeListener(_onUsernameChanged);
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _dayCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  //  CEK USERNAME (debounce)
  // ═══════════════════════════════════════════════════════════════════
  void _onUsernameChanged() {
    _checkUsernameDebounce?.cancel();
    final u = _usernameCtrl.text.trim();

    if (u.length < 3) {
      setState(() {
        _usernameAvailable = null;
        _usernameMsg = null;
        _isCheckingUsername = false;
      });
      return;
    }

    setState(() => _isCheckingUsername = true);

    _checkUsernameDebounce = Timer(const Duration(milliseconds: 600), () async {
      try {
        final res = await http.get(Uri.parse(
          "$_kBase/reseller/check-username?username=${Uri.encodeComponent(u)}",
        ));
        final data = jsonDecode(res.body);

        if (!mounted) return;
        setState(() {
          _isCheckingUsername = false;
          _usernameAvailable = data['available'] == true;
          _usernameMsg = data['message']?.toString();
        });
      } catch (_) {
        if (!mounted) return;
        setState(() {
          _isCheckingUsername = false;
          _usernameAvailable = null;
          _usernameMsg = null;
        });
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  //  CREATE ACCOUNT
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _createAccount() async {
    final u = _usernameCtrl.text.trim();
    final p = _passwordCtrl.text.trim();
    final d = _dayCtrl.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    if (u.length < 3) {
      _alert("Peringatan", "Username minimal 3 karakter.");
      return;
    }

    if (p.length < 4) {
      _alert("Peringatan", "Password minimal 4 karakter.");
      return;
    }

    final hari = int.tryParse(d) ?? 0;
    if (hari < 1) {
      _alert("Peringatan", "Durasi minimal 1 hari.");
      return;
    }

    if (_usernameAvailable == false) {
      _alert("Peringatan", "Username tidak tersedia.");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final res = await http.get(Uri.parse(
        "$_kBase/reseller/create"
        "?key=${Uri.encodeComponent(sessionKey)}"
        "&username=${Uri.encodeComponent(u)}"
        "&password=${Uri.encodeComponent(p)}"
        "&day=$hari",
      ));

      final data = jsonDecode(res.body);

      if (data['success'] != true) {
        setState(() => _isLoading = false);
        _alert("Gagal", "❌ ${data['message'] ?? 'Gagal membuat akun.'}");
        return;
      }

      // ✅ Mode FREE (durasi < 30 hari)
      if (data['mode'] == 'free') {
        setState(() => _isLoading = false);
        _showSuccessFreeDialog(
          username: u,
          password: p,
          days: hari,
          expiredDate: data['expiredDate']?.toString(),
        );
        _clearForm();
        return;
      }

      // ✅ Mode QRIS (durasi >= 30 hari)
      if (data['mode'] == 'qris') {
        setState(() => _isLoading = false);
        if (!mounted) return;
        _showQrisDialog(
          depositId: data['depositId'],
          qrUrl: data['qrUrl'],
          totalPayment: data['totalPayment'] ?? 2000,
          username: u,
          password: p,
          days: hari,
        );
        return;
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _alert("Error", "❌ Koneksi error: $e");
    }
  }

  void _clearForm() {
    _usernameCtrl.clear();
    _passwordCtrl.clear();
    _dayCtrl.text = '30';
    setState(() {
      _usernameAvailable = null;
      _usernameMsg = null;
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ALERT DIALOG
  // ═══════════════════════════════════════════════════════════════════
  void _alert(String title, String message) {
    final isComic = ThemeModeManager.isComic3d;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                  color: _C.border,
                  width: AppColors.borderWidth,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: _C.primaryLt, size: 40),
                  const SizedBox(height: 12),
                  Text(title,
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 13,
                          height: 1.5)),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text("OK",
                          style: TextStyle(
                              color: _onAccent(),
                              fontFamily: kFont,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  SUCCESS DIALOG (FREE)
  // ═══════════════════════════════════════════════════════════════════
  void _showSuccessFreeDialog({
    required String username,
    required String password,
    required int days,
    String? expiredDate,
  }) {
    final isComic = ThemeModeManager.isComic3d;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                  color: _C.green.withOpacity(0.4),
                  width: AppColors.borderWidth + 1,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 70,
                    height: 70,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [_C.green, _C.primaryLt],
                      ),
                    ),
                    child: Icon(Icons.check_rounded,
                        color: _onAccent(), size: 36),
                  ),
                  const SizedBox(height: 16),
                  Text("AKUN BERHASIL DIBUAT!",
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: _C.green.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _C.green.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.card_giftcard_rounded,
                            color: _C.green, size: 12),
                        const SizedBox(width: 6),
                        Text("GRATIS (durasi < 30 hari)",
                            style: TextStyle(
                                color: _C.green,
                                fontFamily: kFont,
                                fontSize: 10,
                                fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _C.surface,
                      borderRadius: BorderRadius.circular(isComic ? 4 : 10),
                      border: Border.all(color: _C.border),
                    ),
                    child: Column(
                      children: [
                        _row("Username", username),
                        _row("Password", password),
                        _row("Durasi", "$days hari"),
                        if (expiredDate != null)
                          _row("Expired", expiredDate),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _C.green,
                        foregroundColor: _onAccent(),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                        ),
                      ),
                      child: Text('SELESAI',
                          style: TextStyle(
                              fontFamily: kFont,
                              fontWeight: FontWeight.bold,
                              color: _onAccent())),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(label,
              style: TextStyle(
                  color: _C.textSub, fontFamily: kFont, fontSize: 11)),
          const Spacer(),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.right,
                style: TextStyle(
                    color: _C.text,
                    fontFamily: kFont,
                    fontSize: 12,
                    fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  QRIS DIALOG
  // ═══════════════════════════════════════════════════════════════════
  void _showQrisDialog({
    required String depositId,
    required String qrUrl,
    required int totalPayment,
    required String username,
    required String password,
    required int days,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      builder: (ctx) => _QrisResellerSheet(
        sessionKey: sessionKey,
        depositId: depositId,
        qrUrl: qrUrl,
        totalPayment: totalPayment,
        username: username,
        password: password,
        days: days,
        onSuccess: () {
          _clearForm();
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: Icon(Icons.arrow_back_ios_new_rounded,
                  color: _C.text, size: 18),
            ),
            title: Text(
              'BUAT AKUN MEMBER',
              style: TextStyle(
                color: _C.text,
                fontSize: 15,
                fontWeight: FontWeight.w800,
                fontFamily: kFont,
                letterSpacing: 1.5,
              ),
            ),
            centerTitle: true,
          ),
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                child: Column(
                  children: [
                    // ─── Info banner ───
                    Container(
                      padding: const EdgeInsets.all(14),
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: _C.primary.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                        border: Border.all(
                          color: _C.primary.withOpacity(0.2),
                          width: AppColors.borderWidth,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.info_outline_rounded,
                                  color: _C.primaryLt, size: 16),
                              const SizedBox(width: 8),
                              Text("Info",
                                  style: TextStyle(
                                      color: _C.primaryLt,
                                      fontFamily: kFont,
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold)),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "• Durasi < 30 hari → langsung dibuat (GRATIS)\n"
                            "• Durasi ≥ 30 hari → bayar QRIS Rp2.000",
                            style: TextStyle(
                                color: _C.textSub,
                                fontFamily: kFont,
                                fontSize: 11,
                                height: 1.6),
                          ),
                        ],
                      ),
                    ),

                    // ─── Form ───
                    _buildInput(
                      label: "Username Baru",
                      ctrl: _usernameCtrl,
                      icon: Icons.person_outline_rounded,
                      hint: "contoh: budi123",
                      trailing: _buildUsernameStatus(),
                    ),
                    _buildInput(
                      label: "Password",
                      ctrl: _passwordCtrl,
                      icon: Icons.lock_outline_rounded,
                      hint: "contoh: 0101",
                      obscure: true,
                    ),
                    _buildInput(
                      label: "Durasi (Hari)",
                      ctrl: _dayCtrl,
                      icon: Icons.calendar_today_rounded,
                      hint: "<30 gratis • ≥30 bayar Rp2.000",
                      type: TextInputType.number,
                    ),

                    const SizedBox(height: 20),

                    // ─── Tombol Create ───
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: _isLoading ? null : _C.btnGrad,
                          color: _isLoading ? _C.textDim : null,
                          borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                          border: isComic
                              ? Border.all(
                                  color: AppColors.border, width: 3)
                              : null,
                          boxShadow: _isLoading
                              ? null
                              : (isComic
                                  ? AppColors.softShadow
                                  : [
                                      BoxShadow(
                                        color: _C.primary.withOpacity(0.3),
                                        blurRadius: 16,
                                        offset: const Offset(0, 4),
                                      ),
                                    ]),
                        ),
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _createAccount,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(isComic ? 4 : 14),
                            ),
                          ),
                          child: _isLoading
                              ? SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2, color: _onAccent()),
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.rocket_launch_rounded,
                                        color: _onAccent(), size: 18),
                                    const SizedBox(width: 10),
                                    Text('BUAT AKUN',
                                        style: TextStyle(
                                            color: _onAccent(),
                                            fontFamily: kFont,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                            letterSpacing: 1)),
                                  ],
                                ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // ─── Statistik harga ───
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: _C.glassGrad,
                        borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                        border: Border.all(
                          color: _C.border,
                          width: AppColors.borderWidth,
                        ),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: _buildPriceInfo(
                              icon: Icons.card_giftcard_rounded,
                              label: '< 30 Hari',
                              price: 'GRATIS',
                              color: _C.green,
                            ),
                          ),
                          Container(width: 1, height: 40, color: _C.border),
                          Expanded(
                            child: _buildPriceInfo(
                              icon: Icons.qr_code_2_rounded,
                              label: '≥ 30 Hari',
                              price: 'Rp2.000',
                              color: _C.primaryLt,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── Status indicator di samping field username ───
  Widget? _buildUsernameStatus() {
    if (_isCheckingUsername) {
      return const SizedBox(
        width: 16,
        height: 16,
        child: CircularProgressIndicator(strokeWidth: 2),
      );
    }
    if (_usernameAvailable == true) {
      return Icon(Icons.check_circle_rounded, color: _C.green, size: 20);
    }
    if (_usernameAvailable == false) {
      return Tooltip(
        message: _usernameMsg ?? 'Tidak tersedia',
        child: Icon(Icons.cancel_rounded, color: _C.red, size: 20),
      );
    }
    return null;
  }

  Widget _buildPriceInfo({
    required IconData icon,
    required String label,
    required String price,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(height: 6),
        Text(label,
            style: TextStyle(
                color: _C.textSub, fontFamily: kFont, fontSize: 10)),
        const SizedBox(height: 2),
        Text(price,
            style: TextStyle(
                color: color,
                fontFamily: kFont,
                fontSize: 13,
                fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController ctrl,
    required IconData icon,
    String hint = '',
    bool obscure = false,
    TextInputType type = TextInputType.text,
    Widget? trailing,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: ctrl,
        obscureText: obscure,
        keyboardType: type,
        style: TextStyle(color: _C.text, fontFamily: kFont),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: _C.textDim, fontFamily: kFont),
          labelStyle: TextStyle(color: _C.primaryLt, fontFamily: kFont),
          prefixIcon: Icon(icon, color: _C.primaryLt),
          suffixIcon: trailing,
          filled: true,
          fillColor: _C.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide: BorderSide(
                color: _C.border, width: AppColors.borderWidth),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide: BorderSide(
                color: _C.border, width: AppColors.borderWidth),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide: BorderSide(color: _C.primaryLt, width: 2),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  QRIS RESELLER SHEET
// ═══════════════════════════════════════════════════════════════════════
class _QrisResellerSheet extends StatefulWidget {
  final String sessionKey;
  final String depositId;
  final String qrUrl;
  final int totalPayment;
  final String username;
  final String password;
  final int days;
  final VoidCallback onSuccess;

  const _QrisResellerSheet({
    required this.sessionKey,
    required this.depositId,
    required this.qrUrl,
    required this.totalPayment,
    required this.username,
    required this.password,
    required this.days,
    required this.onSuccess,
  });

  @override
  State<_QrisResellerSheet> createState() => _QrisResellerSheetState();
}

class _QrisResellerSheetState extends State<_QrisResellerSheet> {
  Timer? _pollTimer;
  Timer? _countdownTimer;
  bool _success = false;
  bool _expired = false;
  int _sisaWaktu = 900;

  @override
  void initState() {
    super.initState();
    _startPolling();
    _startTimer();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _countdownTimer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || _success || _expired) return;
      if (_sisaWaktu > 0) {
        setState(() => _sisaWaktu--);
      } else {
        _countdownTimer?.cancel();
      }
    });
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted || _success || _expired) return;
      try {
        final res = await http.get(Uri.parse(
          "$_kBase/reseller/status?depositId=${widget.depositId}",
        ));
        final data = jsonDecode(res.body);
        final status = data['status'];

        if (status == 'success') {
          _pollTimer?.cancel();
          _countdownTimer?.cancel();
          if (mounted) {
            setState(() => _success = true);
            widget.onSuccess();
          }
        } else if (status == 'expired' || status == 'canceled') {
          _pollTimer?.cancel();
          _countdownTimer?.cancel();
          if (mounted) {
            setState(() => _expired = true);
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _cancel() async {
    _pollTimer?.cancel();
    _countdownTimer?.cancel();
    try {
      await http.get(Uri.parse(
        "$_kBase/reseller/cancel?depositId=${widget.depositId}",
      ));
    } catch (_) {}
    if (mounted) Navigator.pop(context);
  }

  String _formatTime(int total) {
    final m = total ~/ 60;
    final s = total % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
      decoration: BoxDecoration(
        gradient: isComic ? null : _C.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(isComic ? 6 : 26),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
        boxShadow: _C.glassShadow,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),

            Row(
              children: [
                Icon(
                  _success
                      ? Icons.check_circle_rounded
                      : _expired
                          ? Icons.cancel_rounded
                          : Icons.qr_code_2_rounded,
                  color: _success
                      ? _C.green
                      : _expired
                          ? _C.red
                          : _C.primaryLt,
                  size: 22,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _success
                        ? 'AKUN DIBUAT!'
                        : _expired
                            ? 'INVOICE EXPIRED'
                            : 'BAYAR Rp${widget.totalPayment}',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: kFont,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1),
                  ),
                ),
                if (!_success && !_expired)
                  GestureDetector(
                    onTap: _cancel,
                    child: Icon(Icons.close_rounded,
                        color: _C.textDim, size: 20),
                  ),
              ],
            ),
            const SizedBox(height: 16),

            // ─── Info akun ───
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                border: Border.all(color: _C.border),
              ),
              child: Column(
                children: [
                  _row("Username", widget.username),
                  _row("Password", widget.password),
                  _row("Durasi", "${widget.days} hari"),
                ],
              ),
            ),
            const SizedBox(height: 16),

            if (_success)
              _successView(isComic)
            else if (_expired)
              _expiredView(isComic)
            else
              _qrView(isComic),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(label,
              style: TextStyle(
                  color: _C.textSub, fontFamily: kFont, fontSize: 11)),
          const Spacer(),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.right,
                style: TextStyle(
                    color: _C.text,
                    fontFamily: kFont,
                    fontSize: 12,
                    fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _qrView(bool isComic) {
    return Column(
      children: [
        // ─── Timer ───
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: _C.amber.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.amber.withOpacity(0.3)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.timer_outlined, color: _C.amber, size: 14),
              const SizedBox(width: 6),
              Text(
                'Kedaluwarsa dalam ${_formatTime(_sisaWaktu)}',
                style: TextStyle(
                  color: _C.amber,
                  fontFamily: kFont,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // ─── QR ───
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: _C.primary.withOpacity(0.4), width: 3),
          ),
          child: Image.network(
            widget.qrUrl,
            width: 220,
            height: 220,
            fit: BoxFit.contain,
            loadingBuilder: (_, c, p) => p == null
                ? c
                : const SizedBox(
                    width: 220,
                    height: 220,
                    child: Center(child: CircularProgressIndicator())),
            errorBuilder: (_, __, ___) => const SizedBox(
              width: 220,
              height: 220,
              child: Center(child: Icon(Icons.broken_image, size: 60)),
            ),
          ),
        ),
        const SizedBox(height: 16),

        // ─── Total ───
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _C.primary.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.primary.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Text("TOTAL BAYAR",
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 10,
                      letterSpacing: 1)),
              const SizedBox(height: 4),
              Text("Rp ${widget.totalPayment}",
                  style: TextStyle(
                      color: _C.primaryLt,
                      fontFamily: kFont,
                      fontSize: 24,
                      fontWeight: FontWeight.w900)),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // ─── Polling indicator ───
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: _C.primaryLt),
            ),
            const SizedBox(width: 10),
            Text('Menunggu pembayaran...',
                style: TextStyle(
                    color: _C.textSub,
                    fontFamily: kFont,
                    fontSize: 12)),
          ],
        ),
        const SizedBox(height: 14),

        // ─── Info ───
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _C.primary.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _C.primary.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              Icon(Icons.info_outline_rounded,
                  color: _C.primaryLt, size: 14),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Akun akan otomatis dibuat setelah pembayaran diterima',
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 10,
                      height: 1.4),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // ─── Batal ───
        SizedBox(
          width: double.infinity,
          height: 44,
          child: OutlinedButton(
            onPressed: _cancel,
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _C.red.withOpacity(0.5)),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('BATAL',
                style: TextStyle(
                    color: _C.red,
                    fontFamily: kFont,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    letterSpacing: 1)),
          ),
        ),
      ],
    );
  }

  Widget _successView(bool isComic) {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(colors: [_C.green, _C.primaryLt]),
            border: isComic
                ? Border.all(color: AppColors.border, width: 3)
                : null,
          ),
          child: Icon(Icons.check_rounded, color: _onAccent(), size: 40),
        ),
        const SizedBox(height: 16),
        Text('AKUN BERHASIL DIBUAT!',
            style: TextStyle(
                color: _C.text,
                fontFamily: kFont,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                letterSpacing: 1)),
        const SizedBox(height: 8),
        Text('Pembayaran diterima & akun aktif',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: _C.textSub, fontFamily: kFont, fontSize: 12)),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          height: 46,
          child: ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.green,
              foregroundColor: _onAccent(),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('SELESAI',
                style: TextStyle(
                    fontFamily: kFont,
                    fontWeight: FontWeight.bold,
                    color: _onAccent())),
          ),
        ),
      ],
    );
  }

  Widget _expiredView(bool isComic) {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _C.red.withOpacity(0.15),
            border: Border.all(color: _C.red.withOpacity(0.4), width: 2),
          ),
          child: Icon(Icons.cancel_rounded, color: _C.red, size: 40),
        ),
        const SizedBox(height: 16),
        Text('INVOICE EXPIRED',
            style: TextStyle(
                color: _C.text,
                fontFamily: kFont,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                letterSpacing: 1)),
        const SizedBox(height: 8),
        Text('Waktu pembayaran habis.\nSilakan buat ulang.',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: _C.textSub,
                fontFamily: kFont,
                fontSize: 12,
                height: 1.5)),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          height: 46,
          child: ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.red,
              foregroundColor: _onAccent(),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('TUTUP',
                style: TextStyle(
                    fontFamily: kFont,
                    fontWeight: FontWeight.bold,
                    color: _onAccent())),
          ),
        ),
      ],
    );
  }
}