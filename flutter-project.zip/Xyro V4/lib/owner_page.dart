// owner_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'theme.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';
const String _kBase = 'http://digital.mypanelku.web.id:2041';

// ─── PALETTE ───────────────────────────────────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;

  static Color get primary    => AppColors.accent;
  static Color get primaryMid => AppColors.accentMid;
  static Color get primaryLt  => AppColors.accentLight;
  static Color get primaryDk  => AppColors.accentDark;

  static Color get green => AppColors.green;
  static Color get amber => AppColors.amber;
  static Color get red   => AppColors.red;

  static Color get text    => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get textDim => AppColors.textHint;

  static LinearGradient get btnGrad => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow => AppColors.softShadow;
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  int _navIndex = 0;
  late String sessionKey;

  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['owner', 'admin', 'vip', 'reseller', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  //  FETCH USERS
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBase/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  // ═══════════════════════════════════════════════════════════════════
  //  DELETE USER
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBase/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  CREATE ACCOUNT — Bypass jika durasi < 30 hari
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    final hari = int.tryParse(d) ?? 0;
    if (hari < 1) {
      _alert("Error", "Durasi minimal 1 hari.");
      return;
    }

    if (u.length < 3) {
      _alert("Error", "Username minimal 3 karakter.");
      return;
    }

    if (p.length < 4) {
      _alert("Error", "Password minimal 4 karakter.");
      return;
    }

    // ✅ ATURAN BARU:
    // - Durasi < 30 hari → langsung create (tanpa QRIS)
    // - Durasi >= 30 hari → muncul QRIS Rp2.000
    if (hari < 30) {
      // Langsung create
      await _createAccountDirect(u, p, hari);
    } else {
      // Buka dialog QRIS
      if (!mounted) return;
      _showQrisDialog(
        username: u,
        password: p,
        days: hari,
        role: newUserRole,
      );
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  CREATE DIRECT (tanpa QRIS, durasi < 30 hari)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _createAccountDirect(String u, String p, int d) async {
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$_kBase/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses",
            "Akun '${u}' (${d} hari) berhasil dibuat tanpa QRIS.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() => newUserRole = 'member');
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  SHOW QRIS DIALOG (durasi >= 30 hari)
  // ═══════════════════════════════════════════════════════════════════
  void _showQrisDialog({
    required String username,
    required String password,
    required int days,
    required String role,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      isDismissible: true,
      builder: (ctx) => _QrisDialogContent(
        sessionKey: sessionKey,
        username: username,
        password: password,
        days: days,
        role: role,
        onSuccess: () {
          createUsernameController.clear();
          createPasswordController.clear();
          createDayController.clear();
          setState(() => newUserRole = 'member');
          _fetchUsers();
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  EDIT USER
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$_kBase/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ALERT DIALOG
  // ═══════════════════════════════════════════════════════════════════
  void _alert(String title, String message) {
    final isComic = ThemeModeManager.isComic3d;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                  color: _C.border,
                  width: AppColors.borderWidth,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: _C.primaryLt, size: 40),
                  const SizedBox(height: 12),
                  Text(title,
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 13,
                          height: 1.5)),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text("OK",
                          style: TextStyle(
                              color: _onAccent(),
                              fontFamily: kFont,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  INPUT WIDGET
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String hint = "",
    bool obscure = false,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        obscureText: obscure,
        style: TextStyle(color: _C.text, fontFamily: kFont),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: _C.textDim, fontFamily: kFont),
          labelStyle: TextStyle(color: _C.primaryLt, fontFamily: kFont),
          prefixIcon: Icon(icon, color: _C.primaryLt),
          filled: true,
          fillColor: _C.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide:
                BorderSide(color: _C.border, width: AppColors.borderWidth),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide:
                BorderSide(color: _C.border, width: AppColors.borderWidth),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide: BorderSide(color: _C.primaryLt, width: 2),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  GLASS CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 10,
          sigmaY: isComic ? 0 : 10,
        ),
        child: Container(
          margin: const EdgeInsets.only(bottom: 20),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _C.border,
              width: AppColors.borderWidth,
            ),
            boxShadow: _C.glassShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _C.primary.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(isComic ? 4 : 10),
                      border:
                          Border.all(color: _C.primary.withOpacity(0.3)),
                    ),
                    child: Icon(icon, color: _C.primaryLt, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: kFont,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ...children,
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ROLE DROPDOWN
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildRoleDropdown({
    required String value,
    required Function(String) onChanged,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(isComic ? 4 : 12),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          dropdownColor: AppColors.card,
          style: TextStyle(color: _C.text, fontFamily: kFont),
          icon: Icon(Icons.arrow_drop_down_rounded, color: _C.primaryLt),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Text(role.toUpperCase(),
                  style: TextStyle(fontFamily: kFont, color: _C.text)),
            );
          }).toList(),
          onChanged: (val) {
            if (val != null) onChanged(val);
          },
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  USER LIST ITEM
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildUserItem(Map user) {
    final isComic = ThemeModeManager.isComic3d;
    return ClipRRect(
      borderRadius: BorderRadius.circular(isComic ? 4 : 14),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 8,
          sigmaY: isComic ? 0 : 8,
        ),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(isComic ? 4 : 14),
            border:
                Border.all(color: _C.border, width: AppColors.borderWidth),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.primary.withOpacity(0.3)),
                ),
                child: Icon(Icons.person_rounded,
                    color: _C.primaryLt, size: 18),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(user['username'] ?? '-',
                        style: TextStyle(
                            color: _C.text,
                            fontFamily: kFont,
                            fontWeight: FontWeight.bold,
                            fontSize: 14)),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: _C.primary.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                              (user['role'] ?? 'member')
                                  .toString()
                                  .toUpperCase(),
                              style: TextStyle(
                                  color: _C.primaryLt,
                                  fontFamily: kFont,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold)),
                        ),
                        const SizedBox(width: 8),
                        Icon(Icons.calendar_today_rounded,
                            color: _C.textDim, size: 10),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(user['expiredDate'] ?? '-',
                              style: TextStyle(
                                  color: _C.textSub,
                                  fontFamily: kFont,
                                  fontSize: 11),
                              overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () async {
                  final confirm = await _confirmDialog("Hapus User?",
                      "Yakin ingin menghapus '${user['username']}'?");
                  if (confirm) {
                    deleteController.text = user['username'];
                    _deleteUser();
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _C.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.primary.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.delete_outline_rounded,
                      color: _C.primaryLt, size: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _confirmDialog(String title, String message) async {
    final isComic = ThemeModeManager.isComic3d;
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                    color: _C.border, width: AppColors.borderWidth),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.warning_amber_rounded,
                      color: _C.amber, size: 40),
                  const SizedBox(height: 12),
                  Text(title,
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 13,
                          height: 1.5)),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(context, false),
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: _C.border),
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(isComic ? 4 : 12)),
                            padding:
                                const EdgeInsets.symmetric(vertical: 12),
                          ),
                          child: Text("Batal",
                              style: TextStyle(
                                  color: _C.textSub, fontFamily: kFont)),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: _C.btnGrad,
                            borderRadius:
                                BorderRadius.circular(isComic ? 4 : 12),
                          ),
                          child: TextButton(
                            onPressed: () => Navigator.pop(context, true),
                            style: TextButton.styleFrom(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 12),
                            ),
                            child: Text("Hapus",
                                style: TextStyle(
                                    color: _onAccent(),
                                    fontFamily: kFont,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    return result ?? false;
  }

  // ═══════════════════════════════════════════════════════════════════
  //  PAGINATION
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(top: 15),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        alignment: WrapAlignment.center,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: isActive ? _C.btnGrad : null,
                color: isActive ? null : _C.surface,
                borderRadius: BorderRadius.circular(isComic ? 4 : 8),
                border: Border.all(
                  color: isActive ? _C.primary : _C.border,
                  width: AppColors.borderWidth,
                ),
              ),
              child: Text("$page",
                  style: TextStyle(
                      color: isActive ? _onAccent() : _C.textSub,
                      fontFamily: kFont,
                      fontSize: 12,
                      fontWeight: FontWeight.bold)),
            ),
          );
        }),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ACTION BUTTON
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    bool isLoading = false,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      height: 52,
      decoration: BoxDecoration(
        gradient: _C.btnGrad,
        borderRadius: BorderRadius.circular(isComic ? 4 : 14),
        border: isComic ? Border.all(color: AppColors.border, width: 3) : null,
        boxShadow: isComic
            ? AppColors.softShadow
            : [
                BoxShadow(
                    color: _C.primary.withOpacity(0.3),
                    blurRadius: 16,
                    offset: const Offset(0, 4))
              ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(isComic ? 4 : 14)),
        ),
        child: isLoading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white))
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: _onAccent(), size: 18),
                  const SizedBox(width: 10),
                  Text(label,
                      style: TextStyle(
                          color: _onAccent(),
                          fontFamily: kFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 1)),
                ],
              ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  PAGES
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildCreatePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "CREATE ACCOUNT",
        icon: FontAwesomeIcons.userPlus,
        children: [
          // Info box
          Container(
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: _C.primary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.primary.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.info_outline_rounded,
                        color: _C.primaryLt, size: 16),
                    const SizedBox(width: 8),
                    Text("Info",
                        style: TextStyle(
                            color: _C.primaryLt,
                            fontFamily: kFont,
                            fontSize: 11,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  "• Durasi < 30 hari → langsung dibuat\n"
                  "• Durasi ≥ 30 hari → bayar QRIS Rp2.000",
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 11,
                      height: 1.6),
                ),
              ],
            ),
          ),

          _buildInput(
            label: "Username",
            controller: createUsernameController,
            icon: FontAwesomeIcons.user,
            hint: "contoh: test1",
          ),
          _buildInput(
            label: "Password",
            controller: createPasswordController,
            icon: FontAwesomeIcons.lock,
            hint: "contoh: 0101",
          ),
          _buildInput(
            label: "Durasi (Hari)",
            controller: createDayController,
            icon: FontAwesomeIcons.calendarDay,
            type: TextInputType.number,
            hint: "contoh: 30",
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 8),
                  child: Text("PILIH ROLE",
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 11,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.bold)),
                ),
                _buildRoleDropdown(
                  value: newUserRole,
                  onChanged: (val) => setState(() => newUserRole = val),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),
          _buildActionButton(
            label: "BUAT AKUN",
            icon: FontAwesomeIcons.userPlus,
            onTap: _createAccount,
            isLoading: isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildListPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "USER LIST",
        icon: FontAwesomeIcons.users,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildRoleDropdown(
              value: selectedRole,
              onChanged: (val) {
                selectedRole = val;
                _filterAndPaginate();
              },
            ),
          ),
          if (isLoading)
            Padding(
              padding: const EdgeInsets.all(30),
              child: Center(
                  child: CircularProgressIndicator(color: _C.primaryLt)),
            )
          else if (filteredList.isEmpty)
            Padding(
              padding: const EdgeInsets.all(30),
              child: Column(
                children: [
                  Icon(Icons.inbox_rounded, color: _C.textDim, size: 40),
                  const SizedBox(height: 10),
                  Text("Tidak ada user dengan role ini",
                      style: TextStyle(
                          color: _C.textSub, fontFamily: kFont)),
                ],
              ),
            )
          else ...[
            ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
            _buildPagination(),
          ],
        ],
      ),
    );
  }

  Widget _buildDeletePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "DELETE USER",
        icon: FontAwesomeIcons.userSlash,
        children: [
          Text(
            "Masukkan username yang ingin dihapus. Aksi ini tidak bisa dibatalkan.",
            style: TextStyle(
                color: _C.textSub,
                fontFamily: kFont,
                fontSize: 12,
                height: 1.5),
          ),
          const SizedBox(height: 16),
          _buildInput(
            label: "Username Target",
            controller: deleteController,
            icon: FontAwesomeIcons.userEdit,
            hint: "Username yang ingin dihapus",
          ),
          const SizedBox(height: 10),
          _buildActionButton(
            label: "HAPUS USER",
            icon: FontAwesomeIcons.trash,
            onTap: _deleteUser,
            isLoading: isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildAddDurationPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "EXTEND DURATION",
        icon: FontAwesomeIcons.clock,
        children: [
          _buildInput(
            label: "Username Target",
            controller: editUsernameController,
            icon: FontAwesomeIcons.userEdit,
            hint: "Username yang ingin diperpanjang",
          ),
          _buildInput(
            label: "Tambah Hari",
            controller: editDayController,
            icon: FontAwesomeIcons.calendarPlus,
            type: TextInputType.number,
          ),
          const SizedBox(height: 10),
          _buildActionButton(
            label: "ADD DAYS",
            icon: FontAwesomeIcons.calendarPlus,
            onTap: _editUser,
            isLoading: isLoading,
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BOTTOM NAV
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBottomNav() {
    final isComic = ThemeModeManager.isComic3d;
    final items = [
      {'icon': Icons.add_circle_rounded, 'label': 'Create'},
      {'icon': Icons.list_alt_rounded, 'label': 'List'},
      {'icon': Icons.delete_rounded, 'label': 'Delete'},
      {'icon': Icons.calendar_month_rounded, 'label': 'Duration'},
    ];

    return Container(
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: isComic ? null : _C.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
        boxShadow: _C.glassShadow,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: isComic ? 0 : 15,
            sigmaY: isComic ? 0 : 15,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(items.length, (i) {
                final isActive = _navIndex == i;
                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() => _navIndex = i);
                      if (i == 1) _fetchUsers();
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        gradient: isActive ? _C.btnGrad : null,
                        borderRadius:
                            BorderRadius.circular(isComic ? 4 : 12),
                        border: isComic && isActive
                            ? Border.all(
                                color: AppColors.border, width: 2)
                            : null,
                        boxShadow: isActive && !isComic
                            ? [
                                BoxShadow(
                                    color: _C.primary.withOpacity(0.3),
                                    blurRadius: 10)
                              ]
                            : [],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            items[i]['icon'] as IconData,
                            color:
                                isActive ? _onAccent() : _C.textDim,
                            size: 20,
                          ),
                          const SizedBox(height: 3),
                          Text(
                            items[i]['label'] as String,
                            style: TextStyle(
                              color:
                                  isActive ? _onAccent() : _C.textDim,
                              fontFamily: kFont,
                              fontSize: 9,
                              fontWeight: isActive
                                  ? FontWeight.bold
                                  : FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          extendBody: true,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  // HEADER
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            gradient: _C.btnGrad,
                            borderRadius: BorderRadius.circular(
                                ThemeModeManager.isComic3d ? 4 : 12),
                            border: ThemeModeManager.isComic3d
                                ? Border.all(
                                    color: AppColors.border, width: 2)
                                : null,
                          ),
                          child: Icon(Icons.workspace_premium_rounded,
                              color: _onAccent(), size: 18),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("OWNER PANEL",
                                style: TextStyle(
                                    color: _C.text,
                                    fontFamily: kFont,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2)),
                            Text(widget.username,
                                style: TextStyle(
                                    color: _C.textSub,
                                    fontFamily: kFont,
                                    fontSize: 11)),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // PAGE CONTENT
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: KeyedSubtree(
                        key: ValueKey(_navIndex),
                        child: _navIndex == 0
                            ? _buildCreatePage()
                            : _navIndex == 1
                                ? _buildListPage()
                                : _navIndex == 2
                                    ? _buildDeletePage()
                                    : _buildAddDurationPage(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _buildBottomNav(),
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  QRIS DIALOG (untuk durasi >= 30 hari)
// ═══════════════════════════════════════════════════════════════════════
class _QrisDialogContent extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String password;
  final int days;
  final String role;
  final VoidCallback onSuccess;

  const _QrisDialogContent({
    required this.sessionKey,
    required this.username,
    required this.password,
    required this.days,
    required this.role,
    required this.onSuccess,
  });

  @override
  State<_QrisDialogContent> createState() => _QrisDialogContentState();
}

class _QrisDialogContentState extends State<_QrisDialogContent> {
  bool _loading = true;
  String? _depositId;
  String? _qrUrl;
  int _totalPayment = 2000;
  int _expiredAt = 0;
  Timer? _pollTimer;
  bool _success = false;
  int _sisaWaktu = 900;

  @override
  void initState() {
    super.initState();
    _createInvoice();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _createInvoice() async {
    setState(() => _loading = true);
    try {
      final res = await http.post(
        Uri.parse('$_kBase/buy/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sessionKey': widget.sessionKey,
          'paketId': 'owner_create',
          'username': widget.username,
          'password': widget.password,
          'role': widget.role,
          'days': widget.days,
        }),
      );
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        setState(() {
          _depositId = data['depositId'];
          _qrUrl = data['qrUrl'];
          _totalPayment = data['totalPayment'] ?? 2000;
          _expiredAt = data['expiredAt'] ?? 0;
          _loading = false;
        });
        _startPolling();
        _startTimer();
      } else {
        setState(() => _loading = false);
        _showErr(data['message'] ?? 'Gagal buat invoice');
      }
    } catch (e) {
      setState(() => _loading = false);
      _showErr('Error: $e');
    }
  }

  void _startTimer() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted || _success) return false;
      if (_sisaWaktu > 0) {
        setState(() => _sisaWaktu--);
      }
      return _sisaWaktu > 0;
    });
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted || _depositId == null) return;

      try {
        final res = await http.post(
          Uri.parse('$_kBase/buy/status'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'sessionKey': widget.sessionKey,
            'depositId': _depositId,
          }),
        );
        final data = jsonDecode(res.body);

        if (data['status'] == 'success') {
          _pollTimer?.cancel();
          if (mounted) {
            setState(() => _success = true);
            widget.onSuccess();
          }
        } else if (data['status'] == 'expired') {
          _pollTimer?.cancel();
          if (mounted) {
            Navigator.pop(context);
            _showErr('Invoice expired. Silakan buat ulang.');
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _cancelInvoice() async {
    _pollTimer?.cancel();
    if (_depositId != null) {
      try {
        await http.post(
          Uri.parse('$_kBase/buy/cancel'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'sessionKey': widget.sessionKey,
            'depositId': _depositId,
          }),
        );
      } catch (_) {}
    }
    if (mounted) Navigator.pop(context);
  }

  void _showErr(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(
              color: _onAccent(),
              fontFamily: kFont,
              fontWeight: FontWeight.w600)),
      backgroundColor: _C.red,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
    ));
  }

  String _formatTime(int totalSeconds) {
    final m = totalSeconds ~/ 60;
    final s = totalSeconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    return Container(
      margin: const EdgeInsets.all(16),
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 24),
      decoration: BoxDecoration(
        gradient: isComic ? null : _C.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(isComic ? 6 : 26),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
        boxShadow: _C.glassShadow,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36, height: 4,
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Icon(
                  _success
                      ? Icons.check_circle_rounded
                      : Icons.qr_code_2_rounded,
                  color: _success ? _C.green : _C.primaryLt,
                  size: 22,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _success ? 'AKUN DIBUAT!' : 'BAYAR Rp2.000',
                    style: TextStyle(
                        color: _C.text,
                        fontFamily: kFont,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1),
                  ),
                ),
                if (!_success)
                  GestureDetector(
                    onTap: _cancelInvoice,
                    child: Icon(Icons.close_rounded,
                        color: _C.textDim, size: 20),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                border: Border.all(color: _C.border),
              ),
              child: Column(
                children: [
                  _row("Username", widget.username),
                  _row("Password", widget.password),
                  _row("Role", widget.role.toUpperCase()),
                  _row("Durasi", "${widget.days} hari"),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (_loading)
              Padding(
                padding: const EdgeInsets.all(30),
                child: Center(
                  child: Column(
                    children: [
                      CircularProgressIndicator(color: _C.primaryLt),
                      const SizedBox(height: 12),
                      Text('Membuat invoice...',
                          style: TextStyle(
                              color: _C.textSub,
                              fontFamily: kFont,
                              fontSize: 12)),
                    ],
                  ),
                ),
              )
            else if (_success)
              _successView(isComic)
            else if (_qrUrl != null)
              _qrView(isComic),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(label,
              style: TextStyle(
                  color: _C.textSub,
                  fontFamily: kFont,
                  fontSize: 11)),
          const Spacer(),
          Text(value,
              style: TextStyle(
                  color: _C.text,
                  fontFamily: kFont,
                  fontSize: 12,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _qrView(bool isComic) {
    return Column(
      children: [
        // Timer
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: _C.amber.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.amber.withOpacity(0.3)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.timer_outlined, color: _C.amber, size: 14),
              const SizedBox(width: 6),
              Text(
                'Kedaluwarsa dalam ${_formatTime(_sisaWaktu)}',
                style: TextStyle(
                  color: _C.amber,
                  fontFamily: kFont,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // QR
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: _C.primary.withOpacity(0.4), width: 3),
          ),
          child: Image.network(
            _qrUrl!,
            width: 220, height: 220,
            fit: BoxFit.contain,
            loadingBuilder: (_, c, p) => p == null
                ? c
                : const SizedBox(
                    width: 220, height: 220,
                    child: Center(child: CircularProgressIndicator())),
            errorBuilder: (_, __, ___) => const SizedBox(
              width: 220, height: 220,
              child: Center(child: Icon(Icons.broken_image, size: 60)),
            ),
          ),
        ),
        const SizedBox(height: 16),

        // Total
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _C.primary.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.primary.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Text("TOTAL BAYAR",
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 10,
                      letterSpacing: 1)),
              const SizedBox(height: 4),
              Text("Rp $_totalPayment",
                  style: TextStyle(
                      color: _C.primaryLt,
                      fontFamily: kFont,
                      fontSize: 24,
                      fontWeight: FontWeight.w900)),
            ],
          ),
        ),
        const SizedBox(height: 12),

        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 14, height: 14,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: _C.primaryLt),
            ),
            const SizedBox(width: 10),
            Text('Menunggu pembayaran...',
                style: TextStyle(
                    color: _C.textSub,
                    fontFamily: kFont,
                    fontSize: 12)),
          ],
        ),
        const SizedBox(height: 16),

        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _C.primary.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _C.primary.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              Icon(Icons.info_outline_rounded,
                  color: _C.primaryLt, size: 14),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Akun akan otomatis dibuat setelah pembayaran diterima',
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 10,
                      height: 1.4),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        SizedBox(
          width: double.infinity,
          height: 44,
          child: OutlinedButton(
            onPressed: _cancelInvoice,
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _C.red.withOpacity(0.5)),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('BATAL',
                style: TextStyle(
                    color: _C.red,
                    fontFamily: kFont,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    letterSpacing: 1)),
          ),
        ),
      ],
    );
  }

  Widget _successView(bool isComic) {
    return Column(
      children: [
        Container(
          width: 80, height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(colors: [_C.green, _C.primaryLt]),
            border: isComic
                ? Border.all(color: AppColors.border, width: 3)
                : null,
          ),
          child: Icon(Icons.check_rounded, color: _onAccent(), size: 40),
        ),
        const SizedBox(height: 16),
        Text('AKUN BERHASIL DIBUAT!',
            style: TextStyle(
                color: _C.text,
                fontFamily: kFont,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                letterSpacing: 1)),
        const SizedBox(height: 8),
        Text('Pembayaran diterima & akun sudah aktif',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: _C.textSub,
                fontFamily: kFont,
                fontSize: 12)),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          height: 46,
          child: ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.green,
              foregroundColor: _onAccent(),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('SELESAI',
                style: TextStyle(
                    fontFamily: kFont,
                    fontWeight: FontWeight.bold,
                    color: _onAccent())),
          ),
        ),
      ],
    );
  }
}