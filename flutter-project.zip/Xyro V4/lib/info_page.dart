// info_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';   // ← SISTEM TEMA

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> {
  Map<String, dynamic>? serverInfo;
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  int? _expandedIndex;

  // ─── PALETTE (alias ke AppColors) ──────────────────────────────────
  Color get bgDark       => AppColors.bg;
  Color get primaryNeon  => AppColors.accent;
  Color get accentNeon   => AppColors.accentLight;
  Color get dimNeon      => AppColors.accentDark;
  Color get primaryWhite => AppColors.text;
  Color get textGrey     => AppColors.textSub;
  Color get cardGlass    => AppColors.card;
  Color get borderGlass  => AppColors.glassBorder;
  Color get glassBg      => AppColors.glassGrad.colors.first;
  Color get glassBorder  => AppColors.glassBorder;

  Color get _successColor => AppColors.green;
  Color get _warningColor => AppColors.amber;
  Color get _errorColor   => AppColors.red;

  @override
  void initState() {
    super.initState();
    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(
        Uri.parse('http://digital.mypanelku.web.id:2041/getServerInfo?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        setState(() {
          serverInfo = jsonDecode(res.body);
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse('http://digital.mypanelku.web.id:2041/ping?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 3));

      final end = DateTime.now();
      final duration = end.difference(start).inMilliseconds;

      if (res.statusCode == 200) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = _successColor;
          } else if (duration < 500) {
            apiStatusColor = _warningColor;
          } else {
            apiStatusColor = const Color(0xFFFF6D00);
          }
          apiStatusText = "SYS.ONLINE :: ${duration}ms";
        });
      } else {
        throw Exception("Failed");
      }
    } catch (e) {
      setState(() {
        isApiOnline = false;
        apiPingMs = 0;
        apiStatusColor = _errorColor;
        apiStatusText = "SYS.OFFLINE";
      });
    }
  }

  // ─── GLASS 3D CARD (ikut tema) ────────────────────────────────────
  BoxDecoration _glassCard3D({Color? borderColor, bool active = false}) {
    final isComic = ThemeModeManager.isComic3d;
    if (isComic) {
      return BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: borderColor ?? AppColors.border,
          width: 3,
        ),
        boxShadow: AppColors.glassShadow,
      );
    }
    return BoxDecoration(
      color: glassBg,
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      border: Border.all(
        color: active
            ? (borderColor ?? primaryNeon.withOpacity(0.3))
            : glassBorder,
        width: active ? 1.5 : 0.8,
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 30,
          offset: const Offset(0, 10),
        ),
        BoxShadow(
          color: Colors.white.withOpacity(0.02),
          blurRadius: 60,
          offset: const Offset(0, -4),
        ),
      ],
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(0.06),
          Colors.white.withOpacity(0.01),
          Colors.white.withOpacity(0.03),
        ],
      ),
    );
  }

  Widget _buildGlassContainer({
    required Widget child,
    bool active = false,
    Color? borderColor,
    EdgeInsets padding = const EdgeInsets.all(16),
    double? radius,
  }) {
    final r = radius ?? AppColors.cardRadius;
    final isComic = ThemeModeManager.isComic3d;
    return ClipRRect(
      borderRadius: BorderRadius.circular(r),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 10,
          sigmaY: isComic ? 0 : 10,
        ),
        child: Container(
          padding: padding,
          decoration: _glassCard3D(borderColor: borderColor, active: active),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ⚡ AUTO REBUILD SAAT TEMA GANTI
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        if (isLoading) {
          return Scaffold(
            backgroundColor: bgDark,
            body: AppBackground(
              imagePath: 'assets/images/mmk.jpg',
              child: SafeArea(
                child: Column(
                  children: [
                    _buildAppBar(),
                    Expanded(
                      child: Center(
                        child: CircularProgressIndicator(color: primaryNeon),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        final List<Map<String, dynamic>> rulesList = [
          {
            "icon": Icons.swap_horiz_outlined,
            "code": "001",
            "title": "NO ACCOUNT BARTERING",
            "desc": "Akun eksklusif DarkVerse tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau.",
            "penalty": "Akun akan DIHAPUS permanen tanpa kompensasi. Aktivitas barter tercatat di log sistem dan dapat dilaporkan.",
          },
          {
            "icon": Icons.person_off_outlined,
            "code": "002",
            "title": "STRICTLY PERSONAL USE",
            "desc": "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).",
            "penalty": "Deteksi multi-device akan memicu suspend otomatis. Akun dibekukan dan tidak dapat dipulihkan.",
          },
          {
            "icon": Icons.money_off_outlined,
            "code": "003",
            "title": "RESELLING PROHIBITED",
            "desc": "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller).",
            "penalty": "Hak akses dicabut sepenuhnya. Akun penjual dan pembeli akan dihapus dari sistem.",
          },
          {
            "icon": Icons.timer_off_outlined,
            "code": "004",
            "title": "ILLEGAL DURATION SALES",
            "desc": "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi.",
            "penalty": "Akun langsung di-terminate. Tidak ada pemulihan atau refund untuk pelanggaran jenis ini.",
          },
          {
            "icon": Icons.trending_down_outlined,
            "code": "005",
            "title": "PRICE DUMPING BAN",
            "desc": "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami.",
            "penalty": "Sanksi berupa pembekuan akun reseller dan penghapusan hak distribusi secara permanen.",
          },
        ];

        return Scaffold(
          backgroundColor: bgDark,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildCompactApiStatus(),
                          const SizedBox(height: 24),

                          // Section header
                          Row(
                            children: [
                              Container(
                                width: 3,
                                height: 20,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [primaryNeon, accentNeon],
                                  ),
                                  borderRadius: BorderRadius.circular(2),
                                  boxShadow: ThemeModeManager.isComic3d
                                      ? null
                                      : [
                                          BoxShadow(
                                            color: primaryNeon.withOpacity(0.4),
                                            blurRadius: 6,
                                          ),
                                        ],
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                "USER PROTOCOLS",
                                style: TextStyle(
                                  color: primaryNeon,
                                  fontSize: 13,
                                  fontFamily: kFont,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 3,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),

                          // Rules list
                          ...rulesList.asMap().entries.map((entry) {
                            final int index = entry.key;
                            final Map<String, dynamic> rule = entry.value;
                            final bool isExpanded = _expandedIndex == index;
                            final isComic = ThemeModeManager.isComic3d;

                            return Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _expandedIndex = isExpanded ? null : index;
                                  });
                                },
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(
                                      AppColors.cardRadius),
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(
                                      sigmaX: isComic ? 0 : 10,
                                      sigmaY: isComic ? 0 : 10,
                                    ),
                                    child: AnimatedContainer(
                                      duration: const Duration(milliseconds: 250),
                                      curve: Curves.easeInOut,
                                      decoration: _glassCard3D(
                                        active: isExpanded,
                                        borderColor: primaryNeon.withOpacity(0.4),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          // Rule header row
                                          Padding(
                                            padding: const EdgeInsets.all(14),
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                // Icon box
                                                Container(
                                                  width: 44, height: 44,
                                                  decoration: BoxDecoration(
                                                    gradient: isComic
                                                        ? LinearGradient(
                                                            colors: [
                                                              primaryNeon,
                                                              primaryNeon.withOpacity(0.7),
                                                            ],
                                                            begin: Alignment.topLeft,
                                                            end: Alignment.bottomRight,
                                                          )
                                                        : LinearGradient(
                                                            colors: [
                                                              primaryNeon.withOpacity(0.15),
                                                              primaryNeon.withOpacity(0.05),
                                                            ],
                                                            begin: Alignment.topLeft,
                                                            end: Alignment.bottomRight,
                                                          ),
                                                    borderRadius: BorderRadius.circular(
                                                        isComic ? 4 : 12),
                                                    border: Border.all(
                                                      color: primaryNeon.withOpacity(0.3),
                                                      width: isComic ? 2 : 1,
                                                    ),
                                                  ),
                                                  child: Icon(
                                                    rule['icon'] as IconData,
                                                    color: isComic
                                                        ? const Color(0xFF1A1A1A)
                                                        : primaryNeon,
                                                    size: 22,
                                                  ),
                                                ),
                                                const SizedBox(width: 12),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Row(
                                                        children: [
                                                          Text(
                                                            rule['code'] as String,
                                                            style: TextStyle(
                                                              color: dimNeon,
                                                              fontSize: 11,
                                                              fontFamily: kFont,
                                                              letterSpacing: 1,
                                                            ),
                                                          ),
                                                          const Spacer(),
                                                          AnimatedRotation(
                                                            turns: isExpanded ? 0.5 : 0,
                                                            duration: const Duration(milliseconds: 250),
                                                            child: Icon(
                                                              Icons.keyboard_arrow_down,
                                                              color: dimNeon,
                                                              size: 18,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      const SizedBox(height: 4),
                                                      Text(
                                                        rule['title'] as String,
                                                        style: TextStyle(
                                                          color: primaryWhite,
                                                          fontFamily: kFont,
                                                          fontWeight: FontWeight.bold,
                                                          fontSize: 13,
                                                          letterSpacing: 1,
                                                        ),
                                                      ),
                                                      const SizedBox(height: 6),
                                                      Text(
                                                        rule['desc'] as String,
                                                        style: TextStyle(
                                                          color: textGrey,
                                                          fontSize: 12,
                                                          height: 1.5,
                                                          fontFamily: kFont,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),

                                          // Expandable penalty section
                                          AnimatedCrossFade(
                                            duration: const Duration(milliseconds: 250),
                                            crossFadeState: isExpanded
                                                ? CrossFadeState.showSecond
                                                : CrossFadeState.showFirst,
                                            firstChild: const SizedBox.shrink(),
                                            secondChild: Column(
                                              children: [
                                                Container(
                                                  height: 1,
                                                  margin: const EdgeInsets.symmetric(horizontal: 14),
                                                  color: primaryNeon.withOpacity(0.15),
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Icon(
                                                        Icons.warning_amber_rounded,
                                                        color: _warningColor,
                                                        size: 16,
                                                      ),
                                                      const SizedBox(width: 8),
                                                      Expanded(
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              "SANKSI",
                                                              style: TextStyle(
                                                                color: primaryNeon,
                                                                fontFamily: kFont,
                                                                fontSize: 11,
                                                                fontWeight: FontWeight.bold,
                                                                letterSpacing: 2,
                                                              ),
                                                            ),
                                                            const SizedBox(height: 4),
                                                            Text(
                                                              rule['penalty'] as String,
                                                              style: TextStyle(
                                                                color: textGrey,
                                                                fontSize: 12,
                                                                height: 1.5,
                                                                fontFamily: kFont,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),

                          const SizedBox(height: 8),

                          // Footer disclaimer
                          Center(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 20),
                              child: Column(
                                children: [
                                  Icon(Icons.shield_outlined,
                                      color: dimNeon, size: 24),
                                  const SizedBox(height: 10),
                                  Text(
                                    "Dengan menggunakan aplikasi ini, pengguna dianggap telah menyetujui seluruh peraturan di atas.",
                                    style: TextStyle(
                                      color: textGrey,
                                      fontSize: 11,
                                      fontStyle: FontStyle.italic,
                                      height: 1.6,
                                      fontFamily: kFont,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 12),
                                  Container(
                                    height: 2,
                                    width: 80,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [primaryNeon, accentNeon],
                                      ),
                                      borderRadius: BorderRadius.circular(2),
                                      boxShadow: ThemeModeManager.isComic3d
                                          ? null
                                          : [
                                              BoxShadow(
                                                color: primaryNeon.withOpacity(0.2),
                                                blurRadius: 6,
                                              ),
                                            ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ✅ APPBAR CUSTOM
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 10, height: 10,
            decoration: BoxDecoration(
              color: primaryNeon,
              shape: BoxShape.circle,
              boxShadow: ThemeModeManager.isComic3d
                  ? null
                  : [
                      BoxShadow(
                        color: primaryNeon.withOpacity(0.4),
                        blurRadius: 8,
                        spreadRadius: 2,
                      ),
                    ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            "XENCODE & SYSTEM INFO",
            style: TextStyle(
              color: primaryWhite,
              fontFamily: kFont,
              fontWeight: FontWeight.bold,
              fontSize: 16,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactApiStatus() {
    return _buildGlassContainer(
      active: true,
      borderColor: primaryNeon.withOpacity(0.15),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 8, height: 8,
            decoration: BoxDecoration(
              color: apiStatusColor,
              shape: BoxShape.circle,
              boxShadow: ThemeModeManager.isComic3d
                  ? null
                  : [
                      BoxShadow(
                        color: apiStatusColor.withOpacity(0.4),
                        blurRadius: 6,
                        spreadRadius: 1,
                      ),
                    ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            apiStatusText.toUpperCase(),
            style: TextStyle(
              color: primaryWhite,
              fontSize: 12,
              fontFamily: kFont,
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          Icon(Icons.settings_outlined, color: dimNeon, size: 18),
        ],
      ),
    );
  }
}