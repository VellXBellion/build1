import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── Palette Merah Glass ───────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A0A0F);
  static const surface   = Color(0x1AFFFFFF);
  static const card      = Color(0x0DFFFFFF);
  static const border    = Color(0x1AFFFFFF);
  static const borderLit = Color(0x33FFFFFF);

  static const primary   = Color(0xFFFF1744);
  static const primaryMid = Color(0xFFFF5252);
  static const primaryLt  = Color(0xFFFF8A80);
  static const primaryDk  = Color(0xFFB71C1C);

  static const success   = Color(0xFF00E676);
  static const amber     = Color(0xFFFFB300);
  static const red       = Color(0xFFFF1744);

  static const text      = Color(0xFFF5EEEE);
  static const textSub   = Color(0xFFE0AAAA);
  static const textDim   = Color(0xFF994444);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.06),
      Colors.white.withOpacity(0.02),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class SpamOtpPage extends StatefulWidget {
  final String sessionKey;

  const SpamOtpPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<SpamOtpPage> createState() => _SpamOtpPageState();
}

class _SpamOtpPageState extends State<SpamOtpPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          // ✅ BACKGROUND FOTO mmk.jpg
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _C.bg),
            ),
          ),

          // ✅ Overlay gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.bg.withOpacity(0.78),
                    _C.bg.withOpacity(0.88),
                    _C.bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _pulseAnimation,
                      builder: (context, child) {
                        return Transform.scale(
                          scale: 1.0 + (_pulseAnimation.value * 0.03),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(24),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                              child: Container(
                                padding: const EdgeInsets.all(40),
                                decoration: BoxDecoration(
                                  gradient: _C.glassGrad,
                                  borderRadius: BorderRadius.circular(24),
                                  border: Border.all(
                                    color: _C.primary.withOpacity(0.2),
                                  ),
                                ),
                                child: Column(
                                  children: [
                                    // Icon bulat gradient merah
                                    Container(
                                      padding: const EdgeInsets.all(24),
                                      decoration: BoxDecoration(
                                        gradient: _C.btnGrad,
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: _C.primary.withOpacity(0.3),
                                            blurRadius: 30,
                                            spreadRadius: 5,
                                          ),
                                        ],
                                      ),
                                      child: Icon(
                                        Icons.construction_rounded,
                                        color: _C.text,
                                        size: 48,
                                      ),
                                    ),
                                    const SizedBox(height: 32),

                                    // COMING SOON
                                    Text(
                                      'COMING SOON',
                                      style: TextStyle(
                                        color: _C.primaryLt,
                                        fontSize: 24,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 4,
                                        fontFamily: kFont,
                                        shadows: [
                                          Shadow(
                                            color: _C.primary.withOpacity(0.3),
                                            blurRadius: 15,
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(height: 12),

                                    // Subtitle chip
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 24, vertical: 8),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            _C.primary.withOpacity(0.1),
                                            _C.primary.withOpacity(0.05),
                                          ],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                          color: _C.primary.withOpacity(0.2),
                                        ),
                                      ),
                                      child: Text(
                                        'Spam OTP WhatsApp',
                                        style: TextStyle(
                                          color: _C.textSub,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: kFont,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 16),

                                    // Description
                                    Text(
                                      'Fitur ini sedang dalam pengembangan',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: _C.textDim,
                                        fontSize: 13,
                                        fontFamily: kFont,
                                      ),
                                    ),
                                    const SizedBox(height: 8),

                                    // "Segera hadir" chip
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 16, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: _C.amber.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(
                                          color: _C.amber.withOpacity(0.2),
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            Icons.schedule_rounded,
                                            color: _C.amber,
                                            size: 14,
                                          ),
                                          const SizedBox(width: 6),
                                          Text(
                                            'Segera hadir',
                                            style: TextStyle(
                                              color: _C.amber,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w600,
                                              fontFamily: kFont,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(height: 32),

                                    // Info box bawah
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20, vertical: 10),
                                      decoration: BoxDecoration(
                                        color: _C.surface,
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(color: _C.border),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            Icons.info_outline_rounded,
                                            color: _C.textDim,
                                            size: 16,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            'Update akan segera rilis',
                                            style: TextStyle(
                                              color: _C.textDim,
                                              fontSize: 12,
                                              fontFamily: kFont,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: Padding(
        padding: const EdgeInsets.all(8),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: _C.border),
            ),
            child: Icon(
              Icons.arrow_back_ios_new_rounded,
              color: _C.textSub,
              size: 16,
            ),
          ),
        ),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.primary,
              boxShadow: [
                BoxShadow(
                  color: _C.primary.withOpacity(0.6),
                  blurRadius: 8,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'SPAM OTP',
            style: TextStyle(
              color: _C.text,
              fontWeight: FontWeight.w800,
              fontSize: 16,
              letterSpacing: 2,
              fontFamily: kFont,
              shadows: [
                Shadow(
                  color: _C.primary.withOpacity(0.3),
                  blurRadius: 10,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}