// splash.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'theme.dart';
import 'dashboard_page.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE (LENGKAP) ─────────────────────────────────────────────────
class _C {
  // ── BACKGROUND ──
  static Color get bg          => AppColors.bg;
  static Color get surface     => AppColors.dark;
  static Color get card        => AppColors.card;
  static Color get cardAlt     => AppColors.card2;
  static Color get card2       => AppColors.card2;
  static Color get border      => AppColors.border;
  static Color get borderLit   => AppColors.borderLit;
  static Color get glassBg     => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  // ── PRIMARY (WAJIB LENGKAP BIAR GA ERROR) ──
  static Color get primary      => AppColors.accent;
  static Color get primaryMid   => AppColors.accentMid;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark  => AppColors.accentDark;
  static Color get primaryGlow  => AppColors.accentMid;

  // ── SECONDARY / ACCENT ──
  static Color get secondary => AppColors.accentLight;
  static Color get accent    => AppColors.accentLight;

  // ── STATUS ──
  static Color get success => AppColors.green;
  static Color get warning => AppColors.amber;
  static Color get error   => AppColors.red;

  // ── COLORS ──
  static Color get red    => AppColors.red;
  static Color get green  => AppColors.green;
  static Color get amber  => AppColors.amber;
  static Color get gold   => AppColors.gold;
  static Color get pink   => AppColors.pink;
  static Color get purple => AppColors.purple;
  static Color get teal   => AppColors.teal;

  // ── GREY / LEGACY ──
  static Color get grey      => AppColors.accent;
  static Color get greyMid   => AppColors.accentMid;
  static Color get greyLight => AppColors.accentLight;
  static Color get greyDark  => AppColors.accentDark;
  static Color get greyGlow  => AppColors.accentMid;

  static Color get neonBlueDark   => greyDark;
  static Color get neonBlueMid    => greyMid;
  static Color get neonBlueLight  => greyLight;
  static Color get neonBlueAccent => grey;
  static Color get neonGreenDark  => greyDark;
  static Color get neonGreenMid   => greyMid;
  static Color get neonGreenLight => greyLight;
  static Color get neonGreenAccent=> grey;

  // ── TEXT ──
  static Color get text     => AppColors.text;
  static Color get textSub  => AppColors.textSub;
  static Color get textHint => AppColors.textHint;
  static Color get textDim  => AppColors.textHint;

  // ── WHITE / BLACK ──
  static Color get white => AppColors.text;
  static Color get black => AppColors.bg;

  // ── GRADIENT ──
  static LinearGradient get btnGrad   => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;

  // ── SHADOW ──
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow  => AppColors.softShadow;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ────────────────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;
  bool _fadeOutStarted = false;

  late AnimationController _fadeOutCtrl;
  late AnimationController _uiCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _progressCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _skipBtnCtrl;

  late Animation<double> _uiFade;
  late Animation<Offset> _uiSlide;
  late Animation<double> _glowAnim;
  late Animation<double> _fadeOut;
  late Animation<double> _skipScale;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initVideo();

    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: AppColors.bg,
      statusBarIconBrightness:
          ThemeModeManager.isComic3d ? Brightness.dark : Brightness.light,
      statusBarBrightness:
          ThemeModeManager.isComic3d ? Brightness.light : Brightness.dark,
    ));
  }

  void _initAnimations() {
    _fadeOutCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _fadeOut = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _fadeOutCtrl, curve: Curves.easeIn));

    _uiCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    _uiFade = CurvedAnimation(parent: _uiCtrl, curve: Curves.easeOut);
    _uiSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _uiCtrl, curve: Curves.easeOutCubic));

    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.2, end: 0.6)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _progressCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 17));

    _particleCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat();

    _skipBtnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
    _skipScale = Tween<double>(begin: 1.0, end: 1.05)
        .animate(CurvedAnimation(parent: _skipBtnCtrl, curve: Curves.easeInOut));
  }

  void _initVideo() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _videoReady = true);
        _videoCtrl.setLooping(true);
        _videoCtrl.play();

        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) {
            _uiCtrl.forward();
            _progressCtrl.forward();

            _progressCtrl.addStatusListener((status) {
              if (status == AnimationStatus.completed && mounted) {
                _navigate();
              }
            });
          }
        });
      }).catchError((_) {
        if (mounted) {
          setState(() => _videoReady = false);
          _uiCtrl.forward();
          _progressCtrl.forward();
          Future.delayed(const Duration(seconds: 17), _navigate);
        }
      });
  }

  void _navigate() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
        transitionDuration: const Duration(milliseconds: 600),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
          child: child,
        ),
      ),
    );
  }

  void _skipIntro() {
    if (_fadeOutStarted) return;
    _fadeOutStarted = true;
    _fadeOutCtrl.forward();
    Future.delayed(const Duration(milliseconds: 800), _navigate);
  }

  @override
  void dispose() {
    _videoCtrl.dispose();
    _fadeOutCtrl.dispose();
    _uiCtrl.dispose();
    _glowCtrl.dispose();
    _progressCtrl.dispose();
    _particleCtrl.dispose();
    _skipBtnCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        final isComic = ThemeModeManager.isComic3d;
        final size = MediaQuery.of(context).size;
        final topPadding = MediaQuery.of(context).padding.top;

        return Scaffold(
          backgroundColor: _C.bg,
          body: Stack(
            fit: StackFit.expand,
            children: [
              // Particle + grid layer
              if (!isComic)
                AnimatedBuilder(
                  animation: _particleCtrl,
                  builder: (_, __) => CustomPaint(
                    painter: _ParticlePainter(_particleCtrl.value),
                    size: size,
                  ),
                ),

              // VIDEO BACKGROUND
              if (_videoReady)
                Positioned.fill(
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoCtrl.value.size.width,
                      height: _videoCtrl.value.size.height,
                      child: VideoPlayer(_videoCtrl),
                    ),
                  ),
                ),

              // Overlay gradient gelap
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(_videoReady ? 0.2 : 0.0),
                        Colors.black.withOpacity(_videoReady ? 0.7 : 0.0),
                      ],
                    ),
                  ),
                ),
              ),

              // SKIP BUTTON
              Positioned(
                top: topPadding + 8,
                right: 16,
                child: FadeTransition(
                  opacity: _uiFade,
                  child: AnimatedBuilder(
                    animation: _skipBtnCtrl,
                    builder: (_, __) => GestureDetector(
                      onTap: _skipIntro,
                      child: Transform.scale(
                        scale: _skipScale.value,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            gradient: isComic ? null : _C.glassGrad,
                            color: isComic ? AppColors.card : null,
                            borderRadius: BorderRadius.circular(
                                isComic ? 4 : 12),
                            border: Border.all(
                              color: isComic
                                  ? AppColors.border
                                  : _C.glassBorder,
                              width: AppColors.borderWidth,
                            ),
                            boxShadow: _C.glassShadow,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.skip_next_rounded,
                                color: isComic
                                    ? AppColors.accentDark
                                    : _C.greyLight,
                                size: 18,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'Skip',
                                style: TextStyle(
                                  color: _C.text,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.3,
                                  fontFamily: kFont,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // TITLE + SUBTITLE
              Positioned.fill(
                child: FadeTransition(
                  opacity: _uiFade,
                  child: SlideTransition(
                    position: _uiSlide,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildTitle(),
                        const SizedBox(height: 10),
                        _buildSubtitle(),
                      ],
                    ),
                  ),
                ),
              ),

              // BOTTOM BAR
              Positioned(
                bottom: 0, left: 0, right: 0,
                child: FadeTransition(
                  opacity: _uiFade,
                  child: _buildBottomBar(),
                ),
              ),

              // FADE OUT OVERLAY
              if (_fadeOutStarted)
                FadeTransition(
                  opacity: _fadeOut,
                  child: Container(color: _C.bg),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTitle() {
    final isComic = ThemeModeManager.isComic3d;
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (_, __) {
        if (isComic) {
          return Text(
            'XENCODE V3',
            style: TextStyle(
              fontSize: 48,
              fontWeight: FontWeight.w900,
              color: _C.primary,
              letterSpacing: 2,
              fontFamily: kFont,
            ),
          );
        }
        return ShaderMask(
          shaderCallback: (b) => LinearGradient(
            colors: [
              _C.greyMid,
              _C.greyLight.withOpacity(0.8 + _glowAnim.value * 0.15),
              _C.grey,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(b),
          child: Text(
            'XENCODE V3',
            style: TextStyle(
              fontSize: 48,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 2,
              fontFamily: kFont,
              shadows: [
                Shadow(
                  color: _C.greyMid.withOpacity(_glowAnim.value * 0.5),
                  blurRadius: 30,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSubtitle() {
    final isComic = ThemeModeManager.isComic3d;
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (_, __) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        decoration: BoxDecoration(
          gradient: isComic ? null : _C.glassGrad,
          color: isComic ? AppColors.card : null,
          borderRadius: BorderRadius.circular(isComic ? 4 : 12),
          border: Border.all(
            color: isComic ? AppColors.border : _C.glassBorder,
            width: AppColors.borderWidth,
          ),
        ),
        child: Text(
          'Project by @ameluchuu',
          style: TextStyle(
            color: isComic
                ? _C.textSub
                : _C.textSub.withOpacity(0.6 + _glowAnim.value * 0.3),
            fontSize: 14,
            letterSpacing: 0.5,
            fontFamily: kFont,
          ),
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.fromLTRB(32, 0, 32, 52),
      child: Column(
        children: [
          _LoadingDots(),
          const SizedBox(height: 18),
          AnimatedBuilder(
            animation: _progressCtrl,
            builder: (_, __) => Column(children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(isComic ? 2 : 4),
                child: Stack(children: [
                  Container(
                    height: 3,
                    width: double.infinity,
                    color: _C.border.withOpacity(0.5),
                  ),
                  Container(
                    height: 3,
                    width: (MediaQuery.of(context).size.width - 64) *
                        _progressCtrl.value,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_C.greyDark, _C.greyMid, _C.greyLight],
                      ),
                      borderRadius: BorderRadius.circular(isComic ? 2 : 4),
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                color: _C.greyMid.withOpacity(0.3),
                                blurRadius: 6,
                              ),
                            ],
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              Text(
                '${(_progressCtrl.value * 100).toInt()}%  Memuat...',
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 11,
                  letterSpacing: 0.5,
                  fontFamily: kFont,
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

class _LoadingDots extends StatefulWidget {
  @override
  State<_LoadingDots> createState() => _LoadingDotsState();
}

class _LoadingDotsState extends State<_LoadingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final t = ((_c.value - i / 3) % 1.0).clamp(0.0, 1.0);
          final s = math.sin(t * math.pi);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Transform.scale(
              scale: 0.4 + s * 0.6,
              child: Container(
                width: 7, height: 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.greyMid.withOpacity(0.3 + s * 0.6),
                  boxShadow: isComic
                      ? null
                      : [
                          BoxShadow(
                            color: _C.greyMid.withOpacity(s * 0.25),
                            blurRadius: 6,
                          ),
                        ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _ParticlePainter extends CustomPainter {
  final double t;
  _ParticlePainter(this.t);

  static final _rand = math.Random(42);
  static final _particles = List.generate(
      28,
      (i) => _Particle(
            x: _rand.nextDouble(),
            y: _rand.nextDouble(),
            size: 1.0 + _rand.nextDouble() * 2.0,
            speed: 0.04 + _rand.nextDouble() * 0.1,
            phase: _rand.nextDouble(),
            opacity: 0.1 + _rand.nextDouble() * 0.25,
          ));

  @override
  void paint(Canvas canvas, Size size) {
    if (ThemeModeManager.isComic3d) return;

    final grid = Paint()
      ..color = AppColors.border.withOpacity(0.15)
      ..strokeWidth = 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final center = Offset(size.width / 2, size.height * 0.38);
    final glow = Paint()
      ..shader = RadialGradient(
        colors: [
          AppColors.accentDark
              .withOpacity(0.12 + math.sin(t * math.pi * 2) * 0.04),
          Colors.transparent,
        ],
        radius: 0.6,
      ).createShader(
          Rect.fromCircle(center: center, radius: size.width * 0.7));
    canvas.drawCircle(center, size.width * 0.7, glow);

    for (final p in _particles) {
      final px = p.x * size.width;
      final rawY = p.y + (t * p.speed) % 1.0;
      final py = (rawY % 1.0) * size.height;
      final drift = math.sin((t + p.phase) * math.pi * 2) * 8;
      final osc = math.sin((t * 2 + p.phase) * math.pi);
      final opacity = p.opacity * (0.5 + osc * 0.5);

      canvas.drawCircle(
        Offset(px + drift, py),
        p.size,
        Paint()..color = AppColors.accentLight.withOpacity(opacity),
      );
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => old.t != t;
}

class _Particle {
  final double x, y, size, speed, phase, opacity;
  const _Particle({
    required this.x,
    required this.y,
    required this.size,
    required this.speed,
    required this.phase,
    required this.opacity,
  });
}