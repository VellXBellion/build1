// tools_page.dart
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';

// ─── DEPENDENSI ────────────────────────────────────────────────
import 'theme.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'check_banned_page.dart';
import 'spam_otp_page.dart';
import 'device_dashboard.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────
const String kFont = 'Pek';

// ─── ALIAS _C → AppColors (biar kode lama tetap jalan) ────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get glassBg   => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static Color get grey      => AppColors.accent;
  static Color get greyMid   => AppColors.accentMid;
  static Color get greyLight => AppColors.accentLight;
  static Color get greyDark  => AppColors.accentDark;
  static Color get greyGlow  => AppColors.accentMid;

  static Color get text      => AppColors.text;
  static Color get textSub   => AppColors.textSub;
  static Color get textDim   => AppColors.textHint;
  static Color get textDark  => AppColors.textHint;

  static Color get amber     => AppColors.amber;
  static Color get gold      => AppColors.gold;
  static Color get purple    => AppColors.purple;
  static Color get pink      => AppColors.pink;
  static Color get teal      => AppColors.teal;
  static Color get green     => AppColors.green;
  static Color get red       => AppColors.red;

  static Color get neonBlue      => grey;
  static Color get neonBlueMid   => greyMid;
  static Color get neonBlueLight => greyLight;
  static Color get neonBlueDark  => greyDark;
  static Color get neonBlueGlow  => greyGlow;
  static Color get neonGreen     => grey;
  static Color get neonGreenMid  => greyMid;
  static Color get neonGreenLight=> greyLight;
  static Color get neonGreenDark => greyDark;
  static Color get neonGreenGlow => greyGlow;

  static LinearGradient get btnGrad     => AppColors.btnGrad;
  static LinearGradient get glassGrad   => AppColors.glassGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow  => AppColors.softShadow;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ───────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ═══════════════════════════════════════════════════════════════
//  KATEGORI
// ═══════════════════════════════════════════════════════════════
class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final String count;

  const _ToolCategory({
    required this.id, required this.title, required this.subtitle,
    required this.icon, required this.accent, required this.count,
  });
}

List<_ToolCategory> get _categories => [
  _ToolCategory(id: 'ddos',       title: 'DDoS Tools',  subtitle: 'Attack & Server',   icon: Icons.bolt_rounded,               accent: _C.grey,     count: '2'),
  _ToolCategory(id: 'network',    title: 'Network',      subtitle: 'WiFi & Spam',       icon: Icons.wifi_tethering_rounded,     accent: _C.amber,    count: '3'),
  _ToolCategory(id: 'osint',      title: 'OSINT',        subtitle: 'Investigation',     icon: Icons.travel_explore_rounded,     accent: _C.purple,   count: '4'),
  _ToolCategory(id: 'downloader', title: 'Downloader',   subtitle: 'Social Media',      icon: Icons.cloud_download_rounded,     accent: _C.pink,     count: '2'),
  _ToolCategory(id: 'utilities',  title: 'Utilities',    subtitle: 'Extra Tools',       icon: Icons.construction_rounded,       accent: _C.teal,     count: '3'),
  _ToolCategory(id: 'whatsapp',   title: 'WhatsApp',     subtitle: 'WA Tools',          icon: Icons.chat_rounded,               accent: _C.green,    count: '3'),
  _ToolCategory(id: 'rat',        title: 'RAT Control',  subtitle: 'Remote Access',     icon: Icons.phone_android_rounded,      accent: _C.red,      count: '1'),
  // ✅ THEME di bawah RAT
  _ToolCategory(id: 'theme',      title: 'Theme',        subtitle: 'Tampilan App',      icon: Icons.palette_rounded,            accent: _C.greyLight, count: '3'),
  _ToolCategory(id: 'quick',      title: 'Quick Access', subtitle: 'Favorites',         icon: Icons.rocket_launch_rounded,      accent: _C.gold,     count: '—'),
];

// ═══════════════════════════════════════════════════════════════
//  TOOLS PAGE
// ═══════════════════════════════════════════════════════════════
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;
  final String username;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
    required this.username,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _headerCtrl;
  late AnimationController _bannerCtrl;

  late Animation<double> _headerFade;
  late Animation<Offset>  _headerSlide;
  late Animation<double> _bannerFade;
  late Animation<Offset>  _bannerSlide;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 16))
      ..repeat();

    _headerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _headerFade  = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide = Tween<Offset>(begin: const Offset(0, -0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOutCubic));

    _bannerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _bannerFade  = CurvedAnimation(parent: _bannerCtrl, curve: Curves.easeOut);
    _bannerSlide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _bannerCtrl, curve: Curves.easeOutCubic));

    _headerCtrl.forward();
    Future.delayed(const Duration(milliseconds: 150), () {
      if (mounted) _bannerCtrl.forward();
    });
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _headerCtrl.dispose();
    _bannerCtrl.dispose();
    super.dispose();
  }

  void _push(Widget page) => Navigator.push(context, _slideRoute(page));

  void _comingSoon() {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Row(children: [
        Icon(Icons.hourglass_top_rounded, color: Colors.white, size: 16),
        SizedBox(width: 8),
        Text('Coming Soon!', style: TextStyle(
            color: Colors.white, fontWeight: FontWeight.w600, fontFamily: kFont)),
      ]),
      backgroundColor: _C.grey,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
    ));
  }

  void _onCategoryTap(String id) {
    switch (id) {
      case 'ddos':       _showSheet(_ddosItems()); break;
      case 'network':    _showSheet(_networkItems()); break;
      case 'osint':      _showSheet(_osintItems()); break;
      case 'downloader': _showSheet(_downloaderItems()); break;
      case 'utilities':  _showSheet(_utilityItems()); break;
      case 'whatsapp':   _showSheet(_whatsappItems()); break;
      case 'rat':        _showSheet(_ratItems()); break;
      case 'theme':      _showThemePicker(); break;   // ✅ THEME
      case 'quick':      _comingSoon(); break;
    }
  }

  List<_ToolItem> _ddosItems() => [
    _ToolItem(icon: Icons.bolt_rounded,     label: 'Attack Panel',  accent: _C.grey,
        onTap: () => _push(AttackPanel(sessionKey: widget.sessionKey, listDoos: widget.listDoos))),
    _ToolItem(icon: Icons.dns_rounded,      label: 'Manage Server', accent: _C.amber,
        onTap: () => _push(ManageServerPage(keyToken: widget.sessionKey))),
  ];

  List<_ToolItem> _networkItems() => [
    _ToolItem(icon: Icons.newspaper_outlined,  label: 'Spam NGL',              accent: _C.purple,
        onTap: () => _push(NglPage())),
    _ToolItem(icon: Icons.wifi_off_rounded,    label: 'WiFi Killer (Internal)', accent: _C.amber,
        onTap: () => _push(WifiKillerPage())),
    if (widget.userRole == 'vip' || widget.userRole == 'owner')
      _ToolItem(icon: Icons.router_rounded,    label: 'WiFi Killer (External)', accent: _C.grey,
          onTap: () => _push(WifiInternalPage(sessionKey: widget.sessionKey))),
  ];

  List<_ToolItem> _osintItems() => [
    _ToolItem(icon: Icons.badge_outlined,      label: 'NIK Detail',    accent: _C.purple,
        onTap: () => _push(const NikCheckerPage())),
    _ToolItem(icon: Icons.travel_explore_rounded, label: 'Domain OSINT', accent: _C.greyLight,
        onTap: () => _push(const DomainOsintPage())),
    _ToolItem(icon: Icons.person_search_rounded, label: 'Phone Lookup', accent: _C.teal,
        onTap: _comingSoon, comingSoon: true),
    _ToolItem(icon: Icons.alternate_email_rounded, label: 'Email OSINT', accent: _C.pink,
        onTap: _comingSoon, comingSoon: true),
  ];

  List<_ToolItem> _downloaderItems() => [
    _ToolItem(icon: Icons.video_library_rounded, label: 'TikTok Downloader',    accent: _C.pink,
        onTap: () => _push(const TiktokDownloaderPage())),
    _ToolItem(icon: Icons.camera_alt_rounded,    label: 'Instagram Downloader', accent: _C.purple,
        onTap: () => _push(const InstagramDownloaderPage())),
  ];

  List<_ToolItem> _utilityItems() => [
    _ToolItem(icon: Icons.qr_code_2_rounded,      label: 'QR Generator', accent: _C.teal,
        onTap: () => _push(const QrGeneratorPage())),
    _ToolItem(icon: Icons.security_rounded,        label: 'IP Scanner',   accent: _C.amber,
        onTap: _comingSoon, comingSoon: true),
    _ToolItem(icon: Icons.network_check_rounded,   label: 'Port Scanner', accent: _C.grey,
        onTap: _comingSoon, comingSoon: true),
  ];

  List<_ToolItem> _ratItems() => [
    _ToolItem(
      icon: Icons.phone_android_rounded,
      label: 'Device Dashboard',
      accent: _C.red,
      onTap: () => _push(DeviceDashboardPage(
        username: widget.username,
        role: widget.userRole,
        sessionKey: widget.sessionKey,
      )),
    ),
  ];

  List<_ToolItem> _whatsappItems() => [
    _ToolItem(
      icon: Icons.shield_outlined,
      label: 'Cek Banned',
      accent: _C.green,
      onTap: () => _push(CheckBannedPage(sessionKey: widget.sessionKey)),
    ),
    _ToolItem(
      icon: Icons.send_time_extension_rounded,
      label: 'Spam OTP',
      accent: _C.purple,
      onTap: () => _push(SpamOtpPage(sessionKey: widget.sessionKey)),
    ),
    _ToolItem(
      icon: Icons.check_circle_outline,
      label: 'Cek Status',
      accent: _C.amber,
      onTap: _comingSoon,
      comingSoon: true,
    ),
  ];

  // ═══════════════════════════════════════════════════════════
  //  THEME PICKER
  // ═══════════════════════════════════════════════════════════
  void _showThemePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const _ThemeModeSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          body: AppBackground(
            controller: _bgCtrl,
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  FadeTransition(
                    opacity: _headerFade,
                    child: SlideTransition(
                      position: _headerSlide,
                      child: _buildHeader(),
                    ),
                  ),
                  FadeTransition(
                    opacity: _bannerFade,
                    child: SlideTransition(
                      position: _bannerSlide,
                      child: _buildBanner(),
                    ),
                  ),
                  Expanded(
                    child: GridView.builder(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 1.05,
                      ),
                      itemCount: _categories.length,
                      itemBuilder: (_, i) => _StaggerItem(
                        index: i,
                        child: _CategoryCard(
                          category: _categories[i],
                          onTap: () => _onCategoryTap(_categories[i].id),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: isComic ? 0 : 10, sigmaY: isComic ? 0 : 10),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            decoration: BoxDecoration(
              gradient: _C.glassGrad,
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(
                color: _C.glassBorder,
                width: AppColors.borderWidth,
              ),
              boxShadow: _C.glassShadow,
            ),
            child: Row(children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  gradient: _C.btnGrad,
                  borderRadius: BorderRadius.circular(
                      isComic ? 4 : 12),
                  border: isComic
                      ? Border.all(color: _C.border, width: 2)
                      : null,
                  boxShadow: isComic
                      ? null
                      : [BoxShadow(color: _C.grey.withOpacity(0.2), blurRadius: 12)],
                ),
                child: Icon(Icons.tune_rounded, color: _onAccent(), size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  isComic
                      ? Text('Tools Dashboard',
                          style: TextStyle(color: _C.text, fontSize: 17,
                              fontWeight: FontWeight.w800, letterSpacing: -0.3,
                              fontFamily: kFont))
                      : ShaderMask(
                          shaderCallback: (b) => _C.btnGrad.createShader(b),
                          child: Text('Tools Dashboard',
                              style: const TextStyle(color: Colors.white, fontSize: 17,
                                  fontWeight: FontWeight.w800, letterSpacing: -0.3,
                                  fontFamily: kFont)),
                        ),
                  Text('Security & OSINT Suite',
                      style: TextStyle(color: _C.textSub, fontSize: 11,
                          fontFamily: kFont)),
                ]),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: AppColors.card2,
                  borderRadius: BorderRadius.circular(isComic ? 4 : 8),
                  border: Border.all(
                    color: _C.border,
                    width: isComic ? 2 : 1,
                  ),
                ),
                child: Text('${_categories.length} tools',
                    style: TextStyle(color: _C.textSub, fontSize: 11,
                        fontWeight: FontWeight.w600, fontFamily: kFont)),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildBanner() {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _C.glassBorder,
              width: AppColors.borderWidth,
            ),
            boxShadow: _C.glassShadow,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            child: Image.asset(
              'assets/images/woi.jpg',
              height: 150,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 150,
                color: AppColors.card2,
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.image_rounded, color: _C.textDim, size: 32),
                      const SizedBox(height: 6),
                      Text('woi.jpg not found',
                          style: TextStyle(
                            color: _C.textDim,
                            fontSize: 11,
                            fontFamily: kFont,
                          )),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _ToolSheet(items: items),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  CATEGORY CARD
// ═══════════════════════════════════════════════════════════════
class _CategoryCard extends StatefulWidget {
  final _ToolCategory category;
  final VoidCallback onTap;

  const _CategoryCard({required this.category, required this.onTap});

  @override
  State<_CategoryCard> createState() => _CategoryCardState();
}

class _CategoryCardState extends State<_CategoryCard>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;
  late AnimationController _glowCtrl;
  late Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600))
      ..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.2, end: 0.5)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _glowCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.94 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: Transform.rotate(
          angle: isComic && !_pressed ? 0.015 : 0,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            child: BackdropFilter(
              filter: ImageFilter.blur(
                  sigmaX: isComic ? 0 : 8,
                  sigmaY: isComic ? 0 : 8),
              child: AnimatedBuilder(
                animation: _glow,
                builder: (_, __) => Container(
                  decoration: BoxDecoration(
                    gradient: _pressed
                        ? LinearGradient(
                            colors: [cat.accent.withOpacity(0.08), Colors.transparent],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : _C.glassGrad,
                    borderRadius: BorderRadius.circular(AppColors.cardRadius),
                    border: Border.all(
                      color: _pressed
                          ? cat.accent.withOpacity(0.5)
                          : (isComic ? _C.border : _C.glassBorder),
                      width: isComic ? 3 : (_pressed ? 1.5 : 1),
                    ),
                    boxShadow: isComic
                        ? [
                            BoxShadow(
                              color: _C.border,
                              offset: Offset(_pressed ? 2 : 4, _pressed ? 2 : 4),
                              blurRadius: 0,
                            ),
                          ]
                        : [
                            BoxShadow(
                              color: cat.accent.withOpacity(
                                  _pressed ? 0.1 : _glow.value * 0.05),
                              blurRadius: _pressed ? 16 : 12,
                              offset: const Offset(0, 4),
                            ),
                            ..._C.glassShadow,
                          ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 44, height: 44,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  cat.accent.withOpacity(isComic ? 1.0 : 0.1),
                                  cat.accent.withOpacity(isComic ? 0.7 : 0.02),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(
                                  isComic ? 4 : 12),
                              border: Border.all(
                                color: cat.accent.withOpacity(
                                    _pressed ? 0.5 : (isComic ? 1.0 : 0.15)),
                                width: isComic ? 2 : 1,
                              ),
                            ),
                            child: Icon(cat.icon,
                                color: isComic ? const Color(0xFF1A1A1A) : cat.accent,
                                size: 20),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 7, vertical: 3),
                            decoration: BoxDecoration(
                              color: cat.accent.withOpacity(isComic ? 0.3 : 0.1),
                              borderRadius: BorderRadius.circular(isComic ? 3 : 8),
                              border: Border.all(
                                  color: cat.accent.withOpacity(0.4),
                                  width: isComic ? 2 : 1),
                            ),
                            child: Text(cat.count,
                                style: TextStyle(
                                  color: isComic ? const Color(0xFF1A1A1A) : cat.accent,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: kFont,
                                )),
                          ),
                        ]),
                        const Spacer(),
                        Text(cat.title,
                            style: TextStyle(
                                color: _C.text, fontSize: 14,
                                fontWeight: FontWeight.w700, height: 1.1,
                                fontFamily: kFont)),
                        const SizedBox(height: 3),
                        Text(cat.subtitle,
                            style: TextStyle(
                                color: _C.textSub, fontSize: 11,
                                fontFamily: kFont)),
                        const SizedBox(height: 10),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          height: isComic ? 3 : 2,
                          width: _pressed ? 44 : 24,
                          decoration: BoxDecoration(
                            color: cat.accent.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  TOOL SHEET (bottom sheet untuk item kategori)
// ═══════════════════════════════════════════════════════════════
class _ToolSheet extends StatelessWidget {
  final List<_ToolItem> items;
  const _ToolSheet({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.72,
      ),
      decoration: BoxDecoration(
        gradient: _C.glassGrad,
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppColors.sheetRadius),
        ),
        border: Border(
          top:   BorderSide(color: _C.glassBorder, width: AppColors.borderWidth),
          left:  BorderSide(color: _C.glassBorder, width: AppColors.borderWidth),
          right: BorderSide(color: _C.glassBorder, width: AppColors.borderWidth),
        ),
        boxShadow: _C.glassShadow,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12, bottom: 8),
            width: 36, height: 4,
            decoration: BoxDecoration(
              color: _C.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, _C.greyMid, Colors.transparent],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Flexible(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (ctx, i) => _StaggerItem(
                index: i,
                child: _ToolRow(
                  item: items[i],
                  onTap: () {
                    Navigator.pop(ctx);
                    items[i].onTap();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;

  const _ToolRow({required this.item, required this.onTap});

  @override
  State<_ToolRow> createState() => _ToolRowState();
}

class _ToolRowState extends State<_ToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          gradient: _pressed
              ? LinearGradient(
                  colors: [item.accent.withOpacity(0.08), Colors.transparent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : _C.glassGrad,
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          border: Border.all(
            color: _pressed
                ? item.accent.withOpacity(0.5)
                : (isComic ? _C.border : _C.glassBorder),
            width: isComic ? 3 : 1,
          ),
          boxShadow: isComic
              ? [
                  BoxShadow(
                    color: _C.border,
                    offset: Offset(_pressed ? 2 : 3, _pressed ? 2 : 3),
                    blurRadius: 0,
                  ),
                ]
              : (_pressed
                  ? [
                      BoxShadow(
                        color: item.accent.withOpacity(0.08),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                      ..._C.softShadow,
                    ]
                  : _C.softShadow),
        ),
        child: Row(children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            width: 42, height: 42,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  item.accent.withOpacity(isComic ? 1.0 : 0.1),
                  item.accent.withOpacity(isComic ? 0.7 : 0.02),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(isComic ? 4 : 12),
              border: Border.all(
                  color: item.accent.withOpacity(
                      _pressed ? 0.5 : (isComic ? 1.0 : 0.15)),
                  width: isComic ? 2 : 1),
            ),
            child: Icon(item.icon,
                color: isComic ? const Color(0xFF1A1A1A) : item.accent,
                size: 19),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item.label,
                  style: TextStyle(color: _C.text, fontSize: 14,
                      fontWeight: FontWeight.w700, fontFamily: kFont)),
              if (item.comingSoon)
                Text('Coming Soon',
                    style: TextStyle(color: _C.textSub, fontSize: 10,
                        fontWeight: FontWeight.w500, fontFamily: kFont)),
            ],
          )),
          item.comingSoon
              ? Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _C.amber.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _C.amber.withOpacity(0.3)),
                  ),
                  child: Text('SOON',
                      style: TextStyle(color: _C.amber, fontSize: 9,
                          fontWeight: FontWeight.w800, letterSpacing: 0.5,
                          fontFamily: kFont)),
                )
              : Icon(Icons.arrow_forward_ios_rounded,
                  color: _pressed ? item.accent : _C.textDim, size: 13),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  THEME MODE SHEET
// ═══════════════════════════════════════════════════════════════
class _ThemeModeSheet extends StatelessWidget {
  const _ThemeModeSheet();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, current, _) {
        return Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.65,
          ),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(AppColors.sheetRadius),
            ),
            border: Border(
              top:   BorderSide(color: _C.glassBorder, width: AppColors.borderWidth),
              left:  BorderSide(color: _C.glassBorder, width: AppColors.borderWidth),
              right: BorderSide(color: _C.glassBorder, width: AppColors.borderWidth),
            ),
            boxShadow: _C.glassShadow,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                width: 36, height: 4,
                decoration: BoxDecoration(
                  color: _C.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Container(
                height: 1,
                margin: const EdgeInsets.symmetric(horizontal: 24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, _C.greyMid, Colors.transparent],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      gradient: _C.btnGrad,
                      borderRadius: BorderRadius.circular(
                          ThemeModeManager.isComic3d ? 4 : 10),
                      border: ThemeModeManager.isComic3d
                          ? Border.all(color: _C.border, width: 2)
                          : null,
                    ),
                    child: Icon(Icons.palette_rounded,
                        color: _onAccent(), size: 18),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Pilih Tema',
                            style: TextStyle(
                              color: _C.text, fontSize: 15,
                              fontWeight: FontWeight.w800,
                              fontFamily: kFont,
                            )),
                        Text('3 mode tampilan tersedia',
                            style: TextStyle(
                              color: _C.textSub, fontSize: 11,
                              fontFamily: kFont,
                            )),
                      ],
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              Flexible(
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  itemCount: kThemeModes.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, i) => _StaggerItem(
                    index: i,
                    child: _ThemeModeRow(
                      info: kThemeModes[i],
                      selected: kThemeModes[i].mode == current,
                      onTap: () {
                        ThemeModeManager.setMode(kThemeModes[i].mode);
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('Tema: ${kThemeModes[i].name}',
                              style: TextStyle(
                                  color: _C.text,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: kFont)),
                          backgroundColor: AppColors.card,
                          behavior: SnackBarBehavior.floating,
                          margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          duration: const Duration(milliseconds: 1400),
                        ));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ThemeModeRow extends StatefulWidget {
  final AppThemeModeInfo info;
  final bool selected;
  final VoidCallback onTap;

  const _ThemeModeRow({
    required this.info,
    required this.selected,
    required this.onTap,
  });

  @override
  State<_ThemeModeRow> createState() => _ThemeModeRowState();
}

class _ThemeModeRowState extends State<_ThemeModeRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final sel = widget.selected;
    final info = widget.info;
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            gradient: sel
                ? LinearGradient(
                    colors: [
                      _C.grey.withOpacity(isComic ? 0.5 : 0.15),
                      _C.greyMid.withOpacity(isComic ? 0.3 : 0.05),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : _C.glassGrad,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: sel ? _C.grey : _C.glassBorder,
              width: sel ? AppColors.borderWidth + 1 : AppColors.borderWidth,
            ),
            boxShadow: isComic
                ? [
                    BoxShadow(
                      color: _C.border,
                      offset: Offset(_pressed ? 2 : 3, _pressed ? 2 : 3),
                      blurRadius: 0,
                    ),
                  ]
                : (sel
                    ? [
                        BoxShadow(
                          color: _C.grey.withOpacity(0.25),
                          blurRadius: 16,
                          offset: const Offset(0, 4),
                        ),
                        ..._C.softShadow,
                      ]
                    : _C.softShadow),
          ),
          child: Row(children: [
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                gradient: sel ? _C.btnGrad : _C.glassGrad,
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                border: Border.all(
                  color: sel ? _C.grey : _C.glassBorder,
                  width: AppColors.borderWidth,
                ),
              ),
              child: Icon(
                info.icon,
                color: sel ? _onAccent() : _C.textDim,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Text(info.name,
                        style: TextStyle(
                          color: sel ? _C.grey : _C.text,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          fontFamily: kFont,
                        )),
                    if (sel) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _C.grey,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text('AKTIF',
                            style: TextStyle(
                              color: _onAccent(),
                              fontSize: 8,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.5,
                              fontFamily: kFont,
                            )),
                      ),
                    ],
                  ]),
                  const SizedBox(height: 2),
                  Text(info.subtitle,
                      style: TextStyle(
                        color: _C.textSub,
                        fontSize: 11,
                        fontFamily: kFont,
                      )),
                ],
              ),
            ),
            Icon(
              sel ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
              color: sel ? _C.grey : _C.textDim,
              size: 22,
            ),
          ]),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  STAGGER ANIMATION
// ═══════════════════════════════════════════════════════════════
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index * 70).clamp(0, 450)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 18 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  TOOL ITEM MODEL
// ═══════════════════════════════════════════════════════════════
class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  final bool comingSoon;

  const _ToolItem({
    required this.icon, required this.label, required this.accent,
    required this.onTap, this.comingSoon = false,
  });
}

// ═══════════════════════════════════════════════════════════════
//  PAGE ROUTE
// ═══════════════════════════════════════════════════════════════
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(
      begin: const Offset(1, 0), end: Offset.zero,
    ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);