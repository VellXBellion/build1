// theme.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ═════════════════════════════════════════════════════════════════════
//  THEME MODE (3 pilihan)
// ═════════════════════════════════════════════════════════════════════
enum AppThemeMode { normal, comic3d, monochrome }

class AppThemeModeInfo {
  final AppThemeMode mode;
  final String name;
  final String subtitle;
  final IconData icon;

  const AppThemeModeInfo({
    required this.mode,
    required this.name,
    required this.subtitle,
    required this.icon,
  });
}

const List<AppThemeModeInfo> kThemeModes = [
  AppThemeModeInfo(
    mode: AppThemeMode.normal,
    name: 'Normal',
    subtitle: 'Red 3D Glass',
    icon: Icons.auto_awesome_rounded,
  ),
  AppThemeModeInfo(
    mode: AppThemeMode.comic3d,
    name: 'Komik 3D Kertas',
    subtitle: 'Comic Paper Style',
    icon: Icons.auto_stories_rounded,
  ),
  AppThemeModeInfo(
    mode: AppThemeMode.monochrome,
    name: 'Hitam Putih',
    subtitle: 'Monochrome',
    icon: Icons.contrast_rounded,
  ),
];

// ═════════════════════════════════════════════════════════════════════
//  THEME MANAGER (dengan persistensi SharedPreferences)
// ═════════════════════════════════════════════════════════════════════
class ThemeModeManager {
  static const _prefsKey = 'app_theme_mode';

  static final ValueNotifier<AppThemeMode> current =
      ValueNotifier<AppThemeMode>(AppThemeMode.normal);

  static AppThemeMode get mode => current.value;

  // ── Set + auto save ke HP ──
  static Future<void> setMode(AppThemeMode m) async {
    current.value = m;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, m.name);
  }

  // ── Load saat app dibuka ──
  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_prefsKey);
    if (saved != null) {
      final found = AppThemeMode.values.firstWhere(
        (e) => e.name == saved,
        orElse: () => AppThemeMode.normal,
      );
      current.value = found;
    }
  }

  // ── Reset ke default ──
  static Future<void> reset() async {
    current.value = AppThemeMode.normal;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefsKey);
  }

  static bool get isNormal     => mode == AppThemeMode.normal;
  static bool get isComic3d    => mode == AppThemeMode.comic3d;
  static bool get isMonochrome => mode == AppThemeMode.monochrome;
}

// ═════════════════════════════════════════════════════════════════════
//  APP COLORS (dinamis — auto update per mode)
// ═════════════════════════════════════════════════════════════════════
class AppColors {
  // ── BACKGROUND ──
  static Color get bg {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFFF8E7);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF000000);
    return const Color(0xFF0A0A0F);
  }

  static Color get card {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFFFFFF);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF0F0F0F);
    return const Color(0xFF1A1A28);
  }

  static Color get card2 {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFFF3C4);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF1A1A1A);
    return const Color(0xFF222230);
  }

  static Color get border {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF1A1A1A);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF2A2A2A);
    return const Color(0xFF2A2A40);
  }

  static Color get borderLit {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF1A1A1A);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF444444);
    return const Color(0xFF3A3A55);
  }

  // ── TEXT ──
  static Color get text {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF1A1A1A);
    if (ThemeModeManager.isMonochrome) return const Color(0xFFFFFFFF);
    return const Color(0xFFF5EEEE);
  }

  static Color get textSub {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF4A4A4A);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF888888);
    return const Color(0xFFE0AAAA);
  }

  static Color get textHint {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF888888);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF555555);
    return const Color(0xFF994444);
  }

  // ── ACCENT ──
  static Color get accent {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFFD93D);
    if (ThemeModeManager.isMonochrome) return const Color(0xFFFFFFFF);
    return const Color(0xFFFF5252);
  }

  static Color get accentMid {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFF9F1C);
    if (ThemeModeManager.isMonochrome) return const Color(0xFFDDDDDD);
    return const Color(0xFFFF1744);
  }

  static Color get accentLight {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFFEAA7);
    if (ThemeModeManager.isMonochrome) return const Color(0xFFAAAAAA);
    return const Color(0xFFFF8A80);
  }

  static Color get accentDark {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFC44536);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF555555);
    return const Color(0xFFB71C1C);
  }

  static Color get dark {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF1A1A1A);
    return const Color(0xFF12121A);
  }

  // ── OVERLAY ──
  static Color get overlay40 {
    if (ThemeModeManager.isComic3d)    return const Color(0x33FFFFFF);
    return const Color(0x66000000);
  }

  static Color get overlay60 {
    if (ThemeModeManager.isComic3d)    return const Color(0x55FFFFFF);
    return const Color(0x99000000);
  }

  static Color get overlay80 {
    if (ThemeModeManager.isComic3d)    return const Color(0x88FFFFFF);
    return const Color(0xCC000000);
  }

  // ── STATUS ──
  static Color get online {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF06D6A0);
    if (ThemeModeManager.isMonochrome) return const Color(0xFFBBBBBB);
    return const Color(0xFF00E676);
  }

  static Color get batteryLow {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFEF476F);
    return const Color(0xFF666666);
  }

  static Color get batteryMid {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFF9F1C);
    return const Color(0xFFAAAAAA);
  }

  static Color get batteryHigh {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF06D6A0);
    return const Color(0xFFFFFFFF);
  }

  // ── CHAT BUBBLE ──
  static Color get bubbleMine {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFFEAA7);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF2A2A2A);
    return const Color(0x26FF1744);
  }

  static Color get bubbleOther {
    if (ThemeModeManager.isComic3d)    return const Color(0xFFFFFFFF);
    if (ThemeModeManager.isMonochrome) return const Color(0xFF1A1A1A);
    return const Color(0xFF1A1A28);
  }

  // ── GRADIENT ──
  static LinearGradient get btnGrad {
    if (ThemeModeManager.isComic3d) {
      return const LinearGradient(
        colors: [Color(0xFFFFD93D), Color(0xFFFF9F1C)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    if (ThemeModeManager.isMonochrome) {
      return const LinearGradient(
        colors: [Color(0xFFFFFFFF), Color(0xFF888888)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    return const LinearGradient(
      colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  static LinearGradient get glassGrad {
    if (ThemeModeManager.isComic3d) {
      return const LinearGradient(
        colors: [Color(0xFFFFFFFF), Color(0xFFFFF8E7)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    return LinearGradient(
      colors: [
        Colors.white.withOpacity(0.06),
        Colors.white.withOpacity(0.02),
      ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  static Color get glassBorder {
    if (ThemeModeManager.isComic3d) return const Color(0xFF1A1A1A);
    return const Color(0x1AFFFFFF);
  }

  // ── SHADOW ──
  static List<BoxShadow> get glassShadow {
    if (ThemeModeManager.isComic3d) {
      return const [
        BoxShadow(
          color: Color(0xFF1A1A1A),
          offset: Offset(4, 4),
          blurRadius: 0,
        ),
      ];
    }
    if (ThemeModeManager.isMonochrome) {
      return [
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 20,
          offset: const Offset(0, 6),
        ),
      ];
    }
    return [
      BoxShadow(
        color: Colors.black.withOpacity(0.3),
        blurRadius: 30,
        offset: const Offset(0, 8),
      ),
    ];
  }

  static List<BoxShadow> get softShadow {
    if (ThemeModeManager.isComic3d) {
      return const [
        BoxShadow(
          color: Color(0xFF1A1A1A),
          offset: Offset(2, 2),
          blurRadius: 0,
        ),
      ];
    }
    return [
      BoxShadow(
        color: Colors.black.withOpacity(0.15),
        blurRadius: 16,
        offset: const Offset(0, 4),
      ),
    ];
  }

  // ── GEOMETRY ──
  static double get cardRadius {
    if (ThemeModeManager.isComic3d) return 4;
    return 16;
  }

  static double get sheetRadius {
    if (ThemeModeManager.isComic3d) return 6;
    return 20;
  }

  static double get borderWidth {
    if (ThemeModeManager.isComic3d) return 3;
    return 1;
  }

  // ── EXTRA ACCENTS ──
  static Color get amber  => const Color(0xFFFFB300);
  static Color get gold   => const Color(0xFFFFD700);
  static Color get purple => ThemeModeManager.isMonochrome
      ? const Color(0xFFBBBBBB) : const Color(0xFFB388FF);
  static Color get pink   => ThemeModeManager.isMonochrome
      ? const Color(0xFFAAAAAA) : const Color(0xFFFF2D55);
  static Color get teal   => ThemeModeManager.isMonochrome
      ? const Color(0xFFDDDDDD) : const Color(0xFF00D4FF);
  static Color get green  => ThemeModeManager.isMonochrome
      ? const Color(0xFFEEEEEE) : const Color(0xFF00E676);
  static Color get red    => ThemeModeManager.isMonochrome
      ? const Color(0xFFFFFFFF) : const Color(0xFFFF1744);
}

// ═════════════════════════════════════════════════════════════════════
//  THEME SCOPE (auto-rebuild seluruh app saat tema berubah)
// ═════════════════════════════════════════════════════════════════════
class ThemeScope extends StatelessWidget {
  final Widget child;
  const ThemeScope({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) => child,
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  COMIC PAPER BACKGROUND
// ═════════════════════════════════════════════════════════════════════
class ComicPaperBackground extends StatelessWidget {
  const ComicPaperBackground({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _ComicPaperPainter(),
      child: const SizedBox.expand(),
    );
  }
}

class _ComicPaperPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = const Color(0xFFFFF8E7),
    );
    final dot = Paint()..color = const Color(0xFFE0D0A0);
    const step = 22.0;
    for (double x = 0; x < size.width; x += step) {
      for (double y = 0; y < size.height; y += step) {
        canvas.drawCircle(Offset(x, y), 1, dot);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═════════════════════════════════════════════════════════════════════
//  ANIMATED GRID BACKGROUND (untuk mode Normal)
// ═════════════════════════════════════════════════════════════════════
class AnimatedGridBackground extends StatelessWidget {
  final AnimationController controller;
  const AnimatedGridBackground({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(
        painter: _GridPainter(controller.value),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final double t;
  _GridPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = AppColors.border.withOpacity(0.06)
      ..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.t != t;
}

// ═════════════════════════════════════════════════════════════════════
//  APP BACKGROUND (dipakai semua halaman)
// ═════════════════════════════════════════════════════════════════════
class AppBackground extends StatelessWidget {
  final AnimationController? controller;
  final String? imagePath;
  final Widget child;

  const AppBackground({
    super.key,
    this.controller,
    this.imagePath,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(child: _buildBaseBg()),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: ThemeModeManager.isComic3d
                    ? [AppColors.overlay40, AppColors.overlay60]
                    : [
                        AppColors.bg.withOpacity(0.75),
                        AppColors.bg.withOpacity(0.85),
                        AppColors.bg.withOpacity(0.95),
                      ],
              ),
            ),
          ),
        ),
        Positioned.fill(child: child),
      ],
    );
  }

  Widget _buildBaseBg() {
    if (ThemeModeManager.isNormal) {
      if (imagePath != null) {
        return Image.asset(
          imagePath!,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => controller != null
              ? AnimatedGridBackground(controller: controller!)
              : ColoredBox(color: AppColors.bg),
        );
      }
      if (controller != null) {
        return AnimatedGridBackground(controller: controller!);
      }
      return ColoredBox(color: AppColors.bg);
    }
    if (ThemeModeManager.isComic3d) {
      return const ComicPaperBackground();
    }
    return ColoredBox(color: AppColors.bg);
  }
}