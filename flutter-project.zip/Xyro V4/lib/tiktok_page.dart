import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── Palette Merah Glass ───────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A0A0F);
  static const surface   = Color(0x1AFFFFFF);
  static const card      = Color(0x0DFFFFFF);
  static const border    = Color(0x1AFFFFFF);
  static const borderLit = Color(0x33FFFFFF);

  static const primary   = Color(0xFFFF1744);
  static const primaryMid = Color(0xFFFF5252);
  static const primaryLt  = Color(0xFFFF8A80);
  static const primaryDk  = Color(0xFFB71C1C);

  static const success   = Color(0xFF00E676);
  static const amber     = Color(0xFFFFB300);
  static const red       = Color(0xFFFF1744);

  static const text      = Color(0xFFF5EEEE);
  static const textSub   = Color(0xFFE0AAAA);
  static const textDim   = Color(0xFF994444);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.06),
      Colors.white.withOpacity(0.02),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> get softShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.15),
      blurRadius: 16,
      offset: const Offset(0, 4),
    ),
  ];
}

class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _videoData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  // ─── EXTRACT URL ─────────────────────────────────────────────────────
  /// Ambil URL dari short link TikTok (vt.tiktok.com → redirect)
  Future<String> _resolveUrl(String input) async {
    // Kalau sudah full URL, langsung return
    if (input.contains('tiktok.com/@') && input.contains('/video/')) {
      return input;
    }

    // Kalau short link, resolve redirect
    try {
      final client = http.Client();
      final request = http.Request('GET', Uri.parse(input))
        ..followRedirects = false;
      final response = await client.send(request).timeout(
        const Duration(seconds: 10),
      );
      client.close();

      final location = response.headers['location'];
      if (location != null) return location;
    } catch (_) {}

    return input;
  }

  // ─── FETCH VIDEO ─────────────────────────────────────────────────────
  Future<void> _downloadTiktok() async {
    final input = _urlController.text.trim();
    if (input.isEmpty) {
      setState(() {
        _errorMessage = "URL TikTok tidak boleh kosong.";
        _videoData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });

    try {
      // Resolve short link → full URL
      final fullUrl = await _resolveUrl(input);

      // ── Coba API 1: tikwm.com (paling stabil) ──────────────────
      final apiUrl = Uri.parse(
          'https://www.tikwm.com/api/?url=${Uri.encodeComponent(fullUrl)}&hd=1');

      final response = await http.get(apiUrl, headers: {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      }).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);

        if (json['code'] == 0 && json['data'] != null) {
          final data = json['data'];

          // Ambil URL video (HD kalau ada, fallback ke no watermark)
          String? videoUrl;
          if (data['hdplay'] != null && data['hdplay'].toString().isNotEmpty) {
            videoUrl = data['hdplay'];
          } else if (data['play'] != null) {
            videoUrl = data['play'];
          } else if (data['wmplay'] != null) {
            videoUrl = data['wmplay'];
          }

          if (videoUrl != null) {
            // Kalau URL relative, prepend base
            if (!videoUrl.startsWith('http')) {
              videoUrl = 'https://www.tikwm.com$videoUrl';
            }

            setState(() {
              _videoData = {
                'video_url': videoUrl,
                'title': data['title'] ?? 'TikTok Video',
                'author': data['author'] != null
                    ? (data['author']['unique_id'] ?? 'Unknown')
                    : 'Unknown',
                'author_nickname': data['author'] != null
                    ? (data['author']['nickname'] ?? '')
                    : '',
                'music': data['music_info'] != null
                    ? (data['music_info']['title'] ?? '')
                    : '',
                'cover': data['cover'] ?? '',
                'duration': data['duration'] ?? 0,
                'play_count': data['play_count'] ?? 0,
                'digg_count': data['digg_count'] ?? 0,
                'comment_count': data['comment_count'] ?? 0,
                'download_count': data['download_count'] ?? 0,
              };
            });
            _initializeVideoPlayer();
          } else {
            setState(() {
              _errorMessage = "URL video tidak ditemukan dalam respons API.";
            });
          }
        } else {
          setState(() {
            _errorMessage =
                "Gagal mengambil data: ${json['msg'] ?? 'Unknown error'}";
          });
        }
      } else {
        setState(() {
          _errorMessage = "Gagal terhubung ke server (${response.statusCode}).";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Terjadi kesalahan: ${e.toString().split(':').last.trim()}";
      });
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _initializeVideoPlayer() {
    final videoUrl = _videoData?['video_url'];
    if (videoUrl == null || videoUrl.isEmpty) return;

    _videoController = VideoPlayerController.networkUrl(
      Uri.parse(videoUrl),
      httpHeaders: {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'Referer': 'https://www.tiktok.com/',
      },
    )..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _chewieController = ChewieController(
            videoPlayerController: _videoController!,
            autoPlay: true,
            looping: false,
            showControls: true,
            aspectRatio: _videoController!.value.aspectRatio,
            materialProgressColors: ChewieProgressColors(
              playedColor: _C.primary,
              handleColor: _C.primaryLt,
              backgroundColor: _C.textDim.withOpacity(0.3),
              bufferedColor: _C.textDim.withOpacity(0.2),
            ),
          );
        });
      }).catchError((e) {
        if (!mounted) return;
        setState(() {
          _errorMessage = "Gagal memuat video: ${e.toString().split(':').last.trim()}";
        });
      });
  }

  // ─── DOWNLOAD & SAVE ─────────────────────────────────────────────────
  Future<void> _downloadVideo() async {
    final videoUrl = _videoData?['video_url'];
    if (videoUrl == null || videoUrl.isEmpty) return;

    // Request permission untuk Android 10 ke bawah
    if (Platform.isAndroid) {
      final status = await Permission.storage.request();
      if (!status.isGranted && !await Permission.manageExternalStorage.isGranted) {
        _showSnackbar('Izin storage diperlukan untuk menyimpan video', _C.red);
        return;
      }
    }

    _showSnackbar('Downloading...', _C.primary);

    try {
      final response = await http.get(
        Uri.parse(videoUrl),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        },
      );

      if (response.statusCode != 200) {
        _showSnackbar('Gagal download (${response.statusCode})', _C.red);
        return;
      }

      // Simpan ke folder Download
      Directory? saveDir;
      if (Platform.isAndroid) {
        saveDir = Directory('/storage/emulated/0/Download');
        if (!await saveDir.exists()) {
          saveDir = await getExternalStorageDirectory();
        }
      } else {
        saveDir = await getApplicationDocumentsDirectory();
      }

      final fileName =
          'tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final file = File('${saveDir!.path}/$fileName');
      await file.writeAsBytes(response.bodyBytes);

      _showSnackbar('✅ Video tersimpan: ${file.path}', _C.success);
    } catch (e) {
      _showSnackbar('Error download: ${e.toString().split(':').last.trim()}', _C.red);
    }
  }

  // ─── SHARE ───────────────────────────────────────────────────────────
  Future<void> _shareVideo() async {
    final videoUrl = _videoData?['video_url'];
    if (videoUrl == null || videoUrl.isEmpty) return;

    try {
      final response = await http.get(
        Uri.parse(videoUrl),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        },
      );
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Video TikTok dari: ${_videoData!['author'] ?? 'Unknown'}',
      );
    } catch (e) {
      _showSnackbar('Error sharing: ${e.toString().split(':').last.trim()}', _C.red);
    }
  }

  void _showSnackbar(String message, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message,
            style: TextStyle(color: _C.text, fontFamily: kFont)),
        backgroundColor: color.withOpacity(0.85),
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  // ─── BUILD ───────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          // ✅ BACKGROUND FOTO mmk.jpg
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _C.bg),
            ),
          ),

          // ✅ Overlay gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.bg.withOpacity(0.78),
                    _C.bg.withOpacity(0.88),
                    _C.bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _buildInputCard(),
                  const SizedBox(height: 20),
                  if (_errorMessage != null) _buildErrorBanner(),
                  if (_errorMessage != null) const SizedBox(height: 20),
                  if (_videoData != null)
                    Expanded(child: _buildVideoPreview())
                  else if (!_isLoading && _errorMessage == null)
                    Expanded(child: _buildEmptyState()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: Padding(
        padding: const EdgeInsets.all(8),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: _C.border),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _C.textSub, size: 16),
          ),
        ),
      ),
      title: Text(
        'TIKTOK DOWNLOADER',
        style: TextStyle(
          fontFamily: kFont,
          fontWeight: FontWeight.bold,
          color: _C.text,
          letterSpacing: 1.5,
          fontSize: 15,
          shadows: [
            Shadow(color: _C.primary.withOpacity(0.3), blurRadius: 10),
          ],
        ),
      ),
    );
  }

  Widget _buildInputCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
            boxShadow: _C.softShadow,
          ),
          child: Column(
            children: [
              TextField(
                controller: _urlController,
                style: TextStyle(
                    color: _C.text, fontFamily: kFont, fontSize: 14),
                cursorColor: _C.primaryLt,
                decoration: InputDecoration(
                  labelText: 'URL TikTok',
                  labelStyle: TextStyle(
                      color: _C.primaryLt, fontFamily: kFont, fontSize: 13),
                  hintText: 'https://vt.tiktok.com/xxx/',
                  hintStyle: TextStyle(
                      color: _C.textDim, fontFamily: kFont, fontSize: 12),
                  prefixIcon: Icon(Icons.link, color: _C.primaryLt, size: 20),
                  suffixIcon: _isLoading
                      ? Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              color: _C.primaryLt,
                              strokeWidth: 2,
                            ),
                          ),
                        )
                      : null,
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _C.border),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: _C.primaryLt, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: _C.surface,
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: Container(
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: _C.btnGrad,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                          color: _C.primary.withOpacity(0.3),
                          blurRadius: 12,
                          offset: const Offset(0, 4))
                    ],
                  ),
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _downloadTiktok,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                            _isLoading
                                ? Icons.hourglass_top
                                : Icons.download_rounded,
                            size: 20,
                            color: _C.text),
                        const SizedBox(width: 8),
                        Text(
                          _isLoading ? 'PROSES...' : 'DOWNLOAD',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: kFont,
                              letterSpacing: 1,
                              color: _C.text),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _C.red.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.red.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              Icon(Icons.error_outline, color: _C.red, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _errorMessage!,
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 13,
                      height: 1.4),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVideoPreview() {
    final title = _videoData?['title'] ?? 'No Title';
    final author = _videoData?['author'] ?? 'Unknown';
    final nickname = _videoData?['author_nickname'] ?? '';
    final music = _videoData?['music'] ?? '';
    final duration = _videoData?['duration'] ?? 0;
    final playCount = _videoData?['play_count'] ?? 0;
    final diggCount = _videoData?['digg_count'] ?? 0;

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: _C.glassGrad,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _C.border),
            ),
            child: Column(
              children: [
                // Preview header
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: _C.btnGrad,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.videocam, color: Colors.white, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        "VIDEO PREVIEW",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          fontFamily: kFont,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Video player
                if (_chewieController != null)
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.primary.withOpacity(0.5)),
                      boxShadow: [
                        BoxShadow(
                            color: _C.primary.withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 4)),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: AspectRatio(
                        aspectRatio: _videoController!.value.aspectRatio,
                        child: Chewie(controller: _chewieController!),
                      ),
                    ),
                  )
                else
                  Container(
                    height: 200,
                    decoration: BoxDecoration(
                      color: _C.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.border),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(color: _C.primaryLt),
                          const SizedBox(height: 16),
                          Text(
                            'Loading video...',
                            style: TextStyle(
                                color: _C.primaryLt,
                                fontFamily: kFont,
                                fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  ),

                const SizedBox(height: 16),

                // Metadata
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: _C.text,
                          fontSize: 14,
                          fontFamily: kFont,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      _buildMetaRow(Icons.person, '@$author${nickname.isNotEmpty ? " ($nickname)" : ""}'),
                      if (music.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        _buildMetaRow(Icons.music_note, music),
                      ],
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          _buildStatChip(Icons.play_arrow, '$playCount'),
                          const SizedBox(width: 8),
                          _buildStatChip(Icons.favorite, '$diggCount'),
                          const SizedBox(width: 8),
                          _buildStatChip(
                              Icons.timer, '${duration}s'),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Action buttons
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: _C.btnGrad,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                                color: _C.primary.withOpacity(0.3),
                                blurRadius: 10,
                                offset: const Offset(0, 4)),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: _downloadVideo,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.save_alt,
                                  size: 18, color: Colors.white),
                              const SizedBox(width: 8),
                              Text(
                                'SAVE',
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: kFont,
                                    letterSpacing: 1,
                                    color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Container(
                        height: 48,
                        decoration: BoxDecoration(
                          color: _C.primaryLt,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                                color: _C.primaryLt.withOpacity(0.3),
                                blurRadius: 10,
                                offset: const Offset(0, 4)),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: _shareVideo,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.share,
                                  size: 18, color: Colors.white),
                              const SizedBox(width: 8),
                              Text(
                                'SHARE',
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: kFont,
                                    letterSpacing: 1,
                                    color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMetaRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: _C.primaryLt, size: 14),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
                color: _C.textSub, fontFamily: kFont, fontSize: 12),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildStatChip(IconData icon, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: _C.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _C.primary.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _C.primaryLt, size: 12),
          const SizedBox(width: 4),
          Text(
            value,
            style: TextStyle(
                color: _C.primaryLt,
                fontFamily: kFont,
                fontSize: 10,
                fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.video_library,
            size: 80,
            color: _C.primary.withOpacity(0.3),
          ),
          const SizedBox(height: 16),
          Text(
            'TikTok Downloader',
            style: TextStyle(
              color: _C.textSub,
              fontSize: 18,
              fontFamily: kFont,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Masukkan URL TikTok untuk mendownload video',
              style: TextStyle(
                  color: _C.textDim,
                  fontFamily: kFont,
                  fontSize: 13),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}