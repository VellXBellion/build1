import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ✅ BASE URL SAMA KAYAK HOME
const String baseUrl = "http://digital.mypanelku.web.id:2041";

// ─── Palette Merah Glass ───────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A0A0F);
  static const surface   = Color(0x1AFFFFFF);
  static const card      = Color(0x0DFFFFFF);
  static const border    = Color(0x1AFFFFFF);
  static const borderLit = Color(0x33FFFFFF);

  static const primary   = Color(0xFFFF1744);
  static const primaryMid = Color(0xFFFF5252);
  static const primaryLt  = Color(0xFFFF8A80);
  static const primaryDk  = Color(0xFFB71C1C);

  static const success   = Color(0xFF00E676);
  static const amber     = Color(0xFFFFB300);
  static const red       = Color(0xFFFF1744);

  static const text      = Color(0xFFF5EEEE);
  static const textSub   = Color(0xFFE0AAAA);
  static const textDim   = Color(0xFF994444);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.06),
      Colors.white.withOpacity(0.02),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> get softShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.15),
      blurRadius: 16,
      offset: const Offset(0, 4),
    ),
  ];
}

class NikCheckerPage extends StatefulWidget {
  final String sessionKey;

  const NikCheckerPage({
    super.key,
    this.sessionKey = '',
  });

  @override
  State<NikCheckerPage> createState() => _NikCheckerPageState();
}

class _NikCheckerPageState extends State<NikCheckerPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _nikController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _data;
  String? _errorMessage;

  late final AnimationController _animController;
  late final Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnimation =
        CurvedAnimation(parent: _animController, curve: Curves.easeIn);
  }

  @override
  void dispose() {
    _nikController.dispose();
    _animController.dispose();
    super.dispose();
  }

  // ─── API ────────────────────────────────────────────────────────────
  // ✅ PAKAI BASE URL SAMA KAYAK HOME
  Future<void> _checkNik() async {
    final nik = _nikController.text.trim();
    if (nik.isEmpty) {
      setState(() {
        _errorMessage = "NIK tidak boleh kosong.";
        _data = null;
      });
      return;
    }

    // Validasi NIK 16 digit
    if (nik.length != 16 || int.tryParse(nik) == null) {
      setState(() {
        _errorMessage = "NIK harus 16 digit angka.";
        _data = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _data = null;
    });

    // ✅ Endpoint pakai baseUrl
    final url = Uri.parse(
        "$baseUrl/nik-check?nik=$nik&key=${widget.sessionKey}");

    try {
      final response = await http.get(url).timeout(
        const Duration(seconds: 15),
      );

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);

        // Support berbagai format response
        // Format 1: {status: true, data: {...}}
        // Format 2: {valid: true, data: {...}}
        // Format 3: {data: {...}}
        final bool isSuccess = json['status'] == true ||
            json['valid'] == true ||
            (json['data'] != null && json['error'] == null);

        if (isSuccess && json['data'] != null) {
          setState(() {
            _data = json['data'];
            _errorMessage = null;
          });
          _animController.forward(from: 0);
        } else {
          setState(() {
            _errorMessage = json['message']?.toString() ??
                "Data tidak ditemukan atau NIK tidak valid.";
          });
        }
      } else {
        setState(() {
          _errorMessage = "Gagal mengambil data (${response.statusCode}).";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Koneksi gagal. Periksa jaringan Anda.";
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ─── COPY ───────────────────────────────────────────────────────────
  void _copyToClipboard(String text, String label) {
    HapticFeedback.lightImpact();
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '$label disalin ke clipboard',
          style: TextStyle(
            color: _C.text,
            fontFamily: kFont,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: _C.primary.withOpacity(0.85),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ─── INFO ROW ───────────────────────────────────────────────────────
  Widget _buildInteractiveInfoRow({
    required String label,
    required String? value,
    IconData? copyIcon = Icons.copy_rounded,
    VoidCallback? onCopy,
  }) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: _C.textDim,
                    fontFamily: kFont,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: _C.text,
                    fontFamily: kFont,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          if (onCopy != null)
            GestureDetector(
              onTap: onCopy,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.primary.withOpacity(0.3)),
                ),
                child: Icon(copyIcon, color: _C.primaryLt, size: 14),
              ),
            ),
        ],
      ),
    );
  }

  // ─── CATEGORY CARD ──────────────────────────────────────────────────
  Widget _buildCategoryCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
            boxShadow: _C.softShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.primary.withOpacity(0.2),
                      _C.primaryDk.withOpacity(0.05),
                    ],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                  border: Border(
                    bottom: BorderSide(color: _C.border),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: _C.primary.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border:
                            Border.all(color: _C.primary.withOpacity(0.3)),
                      ),
                      child: Icon(icon, color: _C.primaryLt, size: 16),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      title,
                      style: TextStyle(
                        color: _C.text,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: kFont,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(14),
                child: Column(children: children),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _C.bg),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.bg.withOpacity(0.78),
                    _C.bg.withOpacity(0.88),
                    _C.bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _buildInputCard(),
                  const SizedBox(height: 16),
                  if (_errorMessage != null) _buildErrorBanner(),
                  if (_errorMessage != null) const SizedBox(height: 16),
                  if (_data != null)
                    Expanded(child: _buildResultView())
                  else if (!_isLoading && _errorMessage == null)
                    Expanded(child: _buildEmptyState()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: Padding(
        padding: const EdgeInsets.all(8),
        child: GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.pop(context);
          },
          child: Container(
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: _C.border),
            ),
            child: Icon(Icons.arrow_back_ios_new_rounded,
                color: _C.textSub, size: 16),
          ),
        ),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.primary,
              boxShadow: [
                BoxShadow(
                    color: _C.primary.withOpacity(0.6), blurRadius: 8)
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'NIK Check',
            style: TextStyle(
              fontFamily: kFont,
              fontWeight: FontWeight.bold,
              color: _C.text,
              letterSpacing: 1.5,
              fontSize: 16,
              shadows: [
                Shadow(
                    color: _C.primary.withOpacity(0.3), blurRadius: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
            boxShadow: _C.softShadow,
          ),
          child: Column(
            children: [
              TextField(
                controller: _nikController,
                keyboardType: TextInputType.number,
                maxLength: 16,
                style: TextStyle(
                    color: _C.text, fontFamily: kFont, fontSize: 14),
                cursorColor: _C.primaryLt,
                decoration: InputDecoration(
                  labelText: 'NIK',
                  counterText: '',
                  labelStyle: TextStyle(
                      color: _C.primaryLt, fontFamily: kFont, fontSize: 13),
                  hintText: '16 digit NIK',
                  hintStyle: TextStyle(
                      color: _C.textDim, fontFamily: kFont, fontSize: 12),
                  prefixIcon: Icon(Icons.badge_rounded,
                      color: _C.primaryLt, size: 20),
                  suffixIcon: _isLoading
                      ? Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              color: _C.primaryLt,
                              strokeWidth: 2,
                            ),
                          ),
                        )
                      : null,
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _C.border),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: _C.primaryLt, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: _C.surface,
                ),
                onSubmitted: (_) => _checkNik(),
              ),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: _isLoading
                    ? null
                    : () {
                        HapticFeedback.lightImpact();
                        _checkNik();
                      },
                child: Container(
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: _C.btnGrad,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                          color: _C.primary.withOpacity(0.3),
                          blurRadius: 12,
                          offset: const Offset(0, 4))
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                          _isLoading
                              ? Icons.hourglass_top
                              : Icons.search_rounded,
                          size: 20,
                          color: _C.text),
                      const SizedBox(width: 8),
                      Text(
                        _isLoading ? 'MEMPROSES...' : 'CEK DATA NIK',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: kFont,
                          letterSpacing: 1,
                          color: _C.text,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _C.red.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.red.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              Icon(Icons.error_outline_rounded,
                  color: _C.primaryLt, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _errorMessage!,
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 13),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultView() {
    // ✅ Support berbagai struktur response
    final dataMap = _data!["data"] ?? _data!;
    
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          children: [
            _buildCategoryCard(
              title: "IDENTITAS DIRI",
              icon: Icons.person_rounded,
              children: [
                _buildInteractiveInfoRow(
                  label: "NIK",
                  value: (_data!["nik"] ?? dataMap["nik"])?.toString(),
                  onCopy: () => _copyToClipboard(
                      (_data!["nik"] ?? dataMap["nik"])?.toString() ?? "", "NIK"),
                ),
                _buildInteractiveInfoRow(
                  label: "Nama Lengkap",
                  value: dataMap["nama"]?.toString(),
                  onCopy: () => _copyToClipboard(
                      dataMap["nama"]?.toString() ?? "", "Nama"),
                ),
                _buildInteractiveInfoRow(
                  label: "Jenis Kelamin",
                  value: dataMap["kelamin"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Tempat Lahir",
                  value: dataMap["tempat_lahir"]?.toString(),
                  onCopy: () => _copyToClipboard(
                      dataMap["tempat_lahir"]?.toString() ?? "",
                      "Tempat Lahir"),
                ),
                _buildInteractiveInfoRow(
                  label: "Tanggal Lahir",
                  value: dataMap["tanggal_lahir"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Usia",
                  value: dataMap["usia"]?.toString(),
                ),
              ],
            ),
            _buildCategoryCard(
              title: "DATA DOMISILI",
              icon: Icons.location_on_rounded,
              children: [
                _buildInteractiveInfoRow(
                  label: "Provinsi",
                  value: dataMap["provinsi"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Kabupaten/Kota",
                  value: dataMap["kabupaten"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Kecamatan",
                  value: dataMap["kecamatan"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Kelurahan/Desa",
                  value: dataMap["kelurahan"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Alamat Lengkap",
                  value: dataMap["alamat"]?.toString(),
                  onCopy: () => _copyToClipboard(
                      dataMap["alamat"]?.toString() ?? "", "Alamat"),
                ),
                _buildInteractiveInfoRow(
                  label: "Kode Pos",
                  value: dataMap["kode_pos"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "TPS",
                  value: dataMap["tps"]?.toString(),
                ),
              ],
            ),
            _buildCategoryCard(
              title: "INFORMASI TAMBAHAN",
              icon: Icons.info_rounded,
              children: [
                _buildInteractiveInfoRow(
                  label: "Zodiak",
                  value: dataMap["zodiak"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Ultah Mendatang",
                  value: dataMap["ultah_mendatang"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Pasaran",
                  value: dataMap["pasaran"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Agama",
                  value: dataMap["agama"]?.toString(),
                ),
                _buildInteractiveInfoRow(
                  label: "Status Kawin",
                  value: dataMap["status_kawin"]?.toString(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.badge_outlined,
            size: 80,
            color: _C.primary.withOpacity(0.3),
          ),
          const SizedBox(height: 16),
          Text(
            'NIK Checker',
            style: TextStyle(
              color: _C.textSub,
              fontSize: 18,
              fontFamily: kFont,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Masukkan NIK 16 digit untuk melihat informasi data',
              style: TextStyle(
                  color: _C.textDim, fontFamily: kFont, fontSize: 13),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}