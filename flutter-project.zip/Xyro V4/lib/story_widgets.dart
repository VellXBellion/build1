// story_widgets.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import 'theme.dart';

const String kFont = 'Pek';
const String baseUrl = 'http://digital.mypanelku.web.id:2041';

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ═══════════════════════════════════════════════════════════════════════
//  MODEL
// ═══════════════════════════════════════════════════════════════════════
class StoryData {
  final String id;
  final String username;
  final String type;    // image / video / text
  final String content;
  final String? bgColor;
  int likes;
  int viewers;
  bool likedByMe;

  StoryData({
    required this.id,
    required this.username,
    required this.type,
    required this.content,
    this.bgColor,
    this.likes = 0,
    this.viewers = 0,
    this.likedByMe = false,
  });

  factory StoryData.fromJson(Map<String, dynamic> j) => StoryData(
        id: j['id']?.toString() ?? '',
        username: j['username']?.toString() ?? '',
        type: j['type']?.toString() ?? 'text',
        content: j['content']?.toString() ?? '',
        bgColor: j['bgColor']?.toString(),
        likes: (j['likes'] is int)
            ? j['likes']
            : int.tryParse(j['likes']?.toString() ?? '0') ?? 0,
        viewers: (j['viewers'] is int)
            ? j['viewers']
            : int.tryParse(j['viewers']?.toString() ?? '0') ?? 0,
        likedByMe: j['likedByMe'] == true,
      );

  String get fullUrl =>
      content.startsWith('http') ? content : '$baseUrl$content';
}

// ═══════════════════════════════════════════════════════════════════════
//  STORY BAR
// ═══════════════════════════════════════════════════════════════════════
class StoryBar extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StoryBar({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StoryBar> createState() => _StoryBarState();
}

class _StoryBarState extends State<StoryBar> {
  List<StoryData> _myStories = [];
  List<StoryData> _otherStories = [];
  String? _myImage;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _myImage = prefs.getString('profile_image_${widget.username}');

    try {
      final res = await http.get(
        Uri.parse('$baseUrl/story/list?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        final allStories = (data['stories'] as List)
            .map((e) => StoryData.fromJson(Map<String, dynamic>.from(e)))
            .toList();

        final mine =
            allStories.where((s) => s.username == widget.username).toList();
        final others =
            allStories.where((s) => s.username != widget.username).toList();

        if (mounted) {
          setState(() {
            _myStories = mine;
            _otherStories = others;
            _loading = false;
          });
        }
        return;
      }
    } catch (e) {
      print('[STORY] Load error: $e');
    }

    if (mounted) setState(() => _loading = false);
  }

  void _onTapMy() {
    if (_myStories.isNotEmpty) {
      _openMyStoryViewer();
    } else {
      _showUploadSheet();
    }
  }

  void _showUploadSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _UploadOptionSheet(
        onPickImage: () {
          Navigator.pop(ctx);
          _pickMedia('image');
        },
        onPickVideo: () {
          Navigator.pop(ctx);
          _pickMedia('video');
        },
        onTextStory: () {
          Navigator.pop(ctx);
          _textStatus();
        },
      ),
    );
  }

  Future<void> _pickMedia(String type) async {
    try {
      final picker = ImagePicker();
      final picked = type == 'video'
          ? await picker.pickVideo(source: ImageSource.gallery)
          : await picker.pickImage(
              source: ImageSource.gallery, imageQuality: 85);

      if (picked == null) return;

      _showLoading('Mengupload...');

      final req = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/story/upload'),
      )
        ..fields['key'] = widget.sessionKey
        ..fields['username'] = widget.username
        ..fields['type'] = type
        ..files.add(await http.MultipartFile.fromPath('file', picked.path));

      final streamed = await req.send().timeout(const Duration(seconds: 60));
      final res = await http.Response.fromStream(streamed);
      final data = jsonDecode(res.body);

      if (!mounted) return;
      Navigator.pop(context);

      if (data['success'] == true) {
        _toast('Status diupload ✅', AppColors.green);
        await _load();
      } else {
        _toast(data['message'] ?? 'Gagal upload', AppColors.red);
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        _toast('Error: $e', AppColors.red);
      }
    }
  }

  void _textStatus() {
    final ctrl = TextEditingController();
    Color bg = const Color(0xFF7B1FA2);

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(20),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 180,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: TextField(
                    controller: ctrl,
                    maxLines: 5,
                    maxLength: 200,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      fontFamily: kFont,
                    ),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Tulis status kamu...',
                      hintStyle: TextStyle(
                          color: Colors.white54, fontFamily: kFont),
                      counterStyle: TextStyle(color: Colors.white54),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 38,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      const Color(0xFF7B1FA2),
                      const Color(0xFFC2185B),
                      const Color(0xFF1976D2),
                      const Color(0xFF00796B),
                      const Color(0xFFF57C00),
                      const Color(0xFFE64A19),
                      const Color(0xFF303F9F),
                      const Color(0xFF000000),
                    ].map((c) {
                      final sel = c.value == bg.value;
                      return GestureDetector(
                        onTap: () => setD(() => bg = c),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: 34, height: 34,
                          decoration: BoxDecoration(
                            color: c,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: sel ? Colors.white : Colors.white24,
                              width: sel ? 3 : 1,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(ctx),
                        child: Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          alignment: Alignment.center,
                          child: const Text('BATAL',
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: kFont,
                                fontWeight: FontWeight.w700,
                              )),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final text = ctrl.text.trim();
                          if (text.isEmpty) return;

                          Navigator.pop(ctx);
                          _showLoading('Mengupload...');

                          final hex =
                              '#${bg.value.toRadixString(16).substring(2).toUpperCase()}';

                          try {
                            final res = await http.post(
                              Uri.parse('$baseUrl/story/text'),
                              body: {
                                'key': widget.sessionKey,
                                'username': widget.username,
                                'text': text,
                                'bgColor': hex,
                              },
                            ).timeout(const Duration(seconds: 15));

                            final data = jsonDecode(res.body);
                            if (!mounted) return;
                            Navigator.pop(context);

                            if (data['success'] == true) {
                              _toast('Status diupload ✅', AppColors.green);
                              await _load();
                            } else {
                              _toast(data['message'] ?? 'Gagal',
                                  AppColors.red);
                            }
                          } catch (e) {
                            if (mounted) {
                              Navigator.pop(context);
                              _toast('Error: $e', AppColors.red);
                            }
                          }
                        },
                        child: Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          alignment: Alignment.center,
                          child: const Text('UPLOAD',
                              style: TextStyle(
                                color: Colors.black87,
                                fontFamily: kFont,
                                fontWeight: FontWeight.w700,
                              )),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showLoading(String msg) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      builder: (_) => Center(
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: AppColors.accent),
              const SizedBox(height: 12),
              Text(msg,
                  style: TextStyle(
                    color: AppColors.text,
                    fontFamily: kFont,
                    fontSize: 12,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  void _toast(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(
              color: _onAccent(),
              fontWeight: FontWeight.w600,
              fontFamily: kFont)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 2),
    ));
  }

  void _openMyStoryViewer() {
    if (_myStories.isEmpty) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _StoryViewer(
          story: _myStories.first,
          isMine: true,
          sessionKey: widget.sessionKey,
          onDeleted: _load,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const SizedBox(
        height: 100,
        child: Center(
          child: SizedBox(
            width: 20, height: 20,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
        ),
      );
    }

    return SizedBox(
      height: 108,
      child: ListView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          _buildMyStory(),
          ..._otherStories.map((s) => _buildStoryItem(s)),
        ],
      ),
    );
  }

  Widget _buildMyStory() {
    final hasImg = _myImage != null && _myImage!.isNotEmpty;
    final hasStory = _myStories.isNotEmpty;
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTap: _onTapMy,
      child: Container(
        width: 74,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  width: 66, height: 66,
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: hasStory
                        ? LinearGradient(
                            colors: [
                              AppColors.accent,
                              AppColors.accentMid,
                            ],
                          )
                        : AppColors.btnGrad,
                    border: isComic
                        ? Border.all(
                            color: AppColors.border, width: 3)
                        : null,
                    boxShadow: hasStory && !isComic
                        ? [
                            BoxShadow(
                              color: AppColors.accent.withOpacity(0.6),
                              blurRadius: 14,
                              spreadRadius: 2,
                            ),
                          ]
                        : null,
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.card,
                    ),
                    child: ClipOval(
                      child: hasImg
                          ? Image.file(File(_myImage!),
                              fit: BoxFit.cover)
                          : Container(
                              color: AppColors.card2,
                              child: Icon(Icons.person_rounded,
                                  color: AppColors.textSub, size: 28),
                            ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0, right: 0,
                  child: Container(
                    width: 22, height: 22,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: AppColors.btnGrad,
                      border: Border.all(color: AppColors.bg, width: 2),
                    ),
                    child: Icon(
                      hasStory
                          ? Icons.visibility_rounded
                          : Icons.add_rounded,
                      color: _onAccent(),
                      size: 13,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 5),
            Text(
              hasStory ? 'Statusku' : 'Buat Status',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: AppColors.text,
                fontSize: 10.5,
                fontFamily: kFont,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStoryItem(StoryData story) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => _StoryViewer(
            story: story,
            isMine: false,
            sessionKey: widget.sessionKey,
          ),
        ),
      ),
      child: Container(
        width: 74,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          children: [
            Container(
              width: 66, height: 66,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: AppColors.btnGrad,
                border: isComic
                    ? Border.all(color: AppColors.border, width: 3)
                    : null,
              ),
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.card,
                ),
                child: ClipOval(child: _thumbnail(story)),
              ),
            ),
            const SizedBox(height: 5),
            Text(story.username,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 10.5,
                  fontFamily: kFont,
                  fontWeight: FontWeight.w600,
                )),
          ],
        ),
      ),
    );
  }

  Widget _thumbnail(StoryData s) {
    if (s.type == 'text') {
      Color bg = AppColors.accent;
      if (s.bgColor != null) {
        try {
          bg = Color(
              int.parse('FF${s.bgColor!.substring(1)}', radix: 16));
        } catch (_) {}
      }
      return Container(
        color: bg,
        alignment: Alignment.center,
        padding: const EdgeInsets.all(6),
        child: Text(s.content,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 7,
              fontWeight: FontWeight.w600,
            )),
      );
    }

    if (s.type == 'image') {
      return Image.network(s.fullUrl,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Icon(Icons.image_rounded,
              color: AppColors.textHint, size: 24));
    }

    return Container(
      color: AppColors.card2,
      child: Icon(Icons.play_circle_fill_rounded,
          color: AppColors.accent, size: 28),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  UPLOAD OPTION SHEET
// ═══════════════════════════════════════════════════════════════════════
class _UploadOptionSheet extends StatelessWidget {
  final VoidCallback onPickImage;
  final VoidCallback onPickVideo;
  final VoidCallback onTextStory;

  const _UploadOptionSheet({
    required this.onPickImage,
    required this.onPickVideo,
    required this.onTextStory,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: isComic ? null : AppColors.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(isComic ? 6 : 24),
        border: Border.all(
          color: AppColors.border,
          width: AppColors.borderWidth,
        ),
        boxShadow: AppColors.glassShadow,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Buat Status',
              style: TextStyle(
                color: AppColors.text,
                fontSize: 16,
                fontWeight: FontWeight.w700,
                fontFamily: kFont,
                letterSpacing: 1,
              )),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _OptionItem(
                  icon: Icons.photo_library_rounded,
                  label: 'Galeri',
                  onTap: onPickImage,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _OptionItem(
                  icon: Icons.videocam_rounded,
                  label: 'Video',
                  onTap: onPickVideo,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: onTextStory,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF7B1FA2), Color(0xFF9C27B0)],
                ),
                borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                border: isComic
                    ? Border.all(color: AppColors.border, width: 2)
                    : null,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.text_fields_rounded,
                      color: Colors.white, size: 18),
                  SizedBox(width: 8),
                  Text('Status Text',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        fontFamily: kFont,
                        letterSpacing: 1,
                      )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OptionItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _OptionItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: AppColors.accent.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: AppColors.accent.withOpacity(0.3),
            width: AppColors.borderWidth,
          ),
        ),
        child: Column(
          children: [
            Icon(icon, color: AppColors.accent, size: 24),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 11,
                  fontFamily: kFont,
                  fontWeight: FontWeight.w600,
                )),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  STORY VIEWER — full screen + Like + Viewer + Delete
// ═══════════════════════════════════════════════════════════════════════
class _StoryViewer extends StatefulWidget {
  final StoryData story;
  final bool isMine;
  final String sessionKey;
  final VoidCallback? onDeleted;

  const _StoryViewer({
    required this.story,
    this.isMine = false,
    required this.sessionKey,
    this.onDeleted,
  });

  @override
  State<_StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<_StoryViewer> {
  VideoPlayerController? _video;

  bool _liked = false;
  int _likes = 0;
  int _viewers = 0;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _liked = widget.story.likedByMe;
    _likes = widget.story.likes;
    _viewers = widget.story.viewers;

    if (widget.story.type == 'video') {
      _initVideo();
    }

    // Kirim view kalau bukan story sendiri
    if (!widget.isMine) {
      _sendView();
    }
  }

  Future<void> _initVideo() async {
    _video = VideoPlayerController.networkUrl(Uri.parse(widget.story.fullUrl));
    await _video!.initialize();
    _video!.setLooping(true);
    _video!.play();
    if (mounted) setState(() {});
  }

  // Kirim view (nambah 1)
  Future<void> _sendView() async {
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/story/view?id=${widget.story.id}&key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 8));

      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _viewers = (data['viewers'] is int)
              ? data['viewers']
              : _viewers + 1;
        });
      }
    } catch (_) {
      // Kalau endpoint belum ada, fallback lokal
      if (mounted) setState(() => _viewers++);
    }
  }

  // Toggle like
  Future<void> _toggleLike() async {
    if (_busy) return;
    setState(() => _busy = true);

    // Optimistic
    setState(() {
      _liked = !_liked;
      _likes += _liked ? 1 : -1;
      if (_likes < 0) _likes = 0;
    });

    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/story/like?id=${widget.story.id}&key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 8));

      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        if (mounted) {
          setState(() {
            _liked = data['liked'] == true;
            _likes = (data['likes'] is int)
                ? data['likes']
                : _likes;
          });
        }
      }
    } catch (_) {
      // gagal → rollback
      if (mounted) {
        setState(() {
          _liked = !_liked;
          _likes += _liked ? 1 : -1;
          if (_likes < 0) _likes = 0;
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // Hapus story (khusus yang punya)
  Future<void> _deleteStory() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Text('Hapus Story?',
            style: TextStyle(
              color: AppColors.text,
              fontFamily: kFont,
              fontWeight: FontWeight.bold,
            )),
        content: Text(
          'Story kamu bakal dihapus permanen. Yakin?',
          style: TextStyle(color: AppColors.textSub, fontFamily: kFont),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('BATAL',
                style: TextStyle(
                    color: AppColors.textSub, fontFamily: kFont)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('HAPUS',
                style: TextStyle(
                    color: AppColors.red,
                    fontFamily: kFont,
                    fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final res = await http.post(
        Uri.parse('$baseUrl/story/delete'),
        body: {
          'key': widget.sessionKey,
          'storyId': widget.story.id,
        },
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);

      if (data['success'] == true && data['deleted'] == true) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Story dihapus ✅',
              style: TextStyle(
                  color: _onAccent(), fontFamily: kFont)),
          backgroundColor: AppColors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.all(16),
        ));
        widget.onDeleted?.call();
        Navigator.pop(context);
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(data['message']?.toString() ?? 'Gagal hapus',
              style: TextStyle(
                  color: _onAccent(), fontFamily: kFont)),
          backgroundColor: AppColors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.all(16),
        ));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: $e',
            style: TextStyle(color: _onAccent(), fontFamily: kFont)),
        backgroundColor: AppColors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ));
    }
  }

  @override
  void dispose() {
    _video?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Konten (image/video/text)
          _content(),

          // Header atas (avatar + username + close + delete)
          Positioned(
            top: 0, left: 0, right: 0,
            child: SafeArea(
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.6),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppColors.btnGrad,
                        border: widget.isMine
                            ? Border.all(
                                color: AppColors.accent, width: 2)
                            : null,
                      ),
                      child: const Icon(Icons.person_rounded,
                          color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        widget.isMine
                            ? '${widget.story.username} (Kamu)'
                            : widget.story.username,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          fontFamily: kFont,
                        ),
                      ),
                    ),

                    // Tombol hapus (kalau story sendiri)
                    if (widget.isMine)
                      IconButton(
                        onPressed: _deleteStory,
                        icon: const Icon(Icons.delete_outline_rounded,
                            color: Colors.white),
                      ),

                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close,
                          color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── KANAN BAWAH: Like + Penonton ──
          Positioned(
            right: 16,
            bottom: 32,
            child: SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  // Like button
                  GestureDetector(
                    onTap: _toggleLike,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.45),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(
                          color: _liked
                              ? AppColors.red.withOpacity(0.6)
                              : Colors.white24,
                          width: 1.5,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _liked
                                ? Icons.favorite_rounded
                                : Icons.favorite_border_rounded,
                            color: _liked
                                ? AppColors.red
                                : Colors.white,
                            size: 20,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '$_likes',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              fontFamily: kFont,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  // Penonton
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.45),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: Colors.white24,
                        width: 1.5,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.visibility_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          '$_viewers',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            fontFamily: kFont,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _content() {
    if (widget.story.type == 'image') {
      return Image.network(
        widget.story.fullUrl,
        fit: BoxFit.contain,
        loadingBuilder: (_, c, p) => p == null
            ? c
            : const Center(
                child: CircularProgressIndicator(color: Colors.white)),
        errorBuilder: (_, __, ___) => const Center(
          child: Icon(Icons.broken_image, color: Colors.white54, size: 60),
        ),
      );
    }

    if (widget.story.type == 'video') {
      if (_video == null || !_video!.value.isInitialized) {
        return const Center(
            child: CircularProgressIndicator(color: Colors.white));
      }
      return Center(
        child: AspectRatio(
          aspectRatio: _video!.value.aspectRatio,
          child: VideoPlayer(_video!),
        ),
      );
    }

    Color bg = const Color(0xFF7B1FA2);
    if (widget.story.bgColor != null) {
      try {
        bg = Color(
            int.parse('FF${widget.story.bgColor!.substring(1)}', radix: 16));
      } catch (_) {}
    }
    return Container(
      color: bg,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(40),
      child: Text(
        widget.story.content,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 28,
          fontWeight: FontWeight.w700,
          fontFamily: kFont,
          height: 1.4,
        ),
      ),
    );
  }
}