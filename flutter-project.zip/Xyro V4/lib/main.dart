// main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'theme.dart';   // ← SISTEM TEMA GLOBAL
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';

// ═════════════════════════════════════════════
//  THEME BUILDER (pakai AppColors dinamis)
// ═════════════════════════════════════════════
class _AppTheme {
  static const _font = 'ShareTechMono';

  static ThemeData build() {
    // ⚡ Ambil nilai warna SEKARANG dari AppColors (dinamis)
    final bg          = AppColors.bg;
    final surface     = AppColors.dark;
    final card        = AppColors.card;
    final border      = AppColors.border;
    final borderLit   = AppColors.borderLit;
    final primary     = AppColors.accent;
    final primaryMid  = AppColors.accentMid;
    final primaryLight= AppColors.accentLight;
    final primaryDark = AppColors.accentDark;
    final text        = AppColors.text;
    final textSub     = AppColors.textSub;
    final textDim     = AppColors.textHint;
    final green       = AppColors.green;
    final amber       = AppColors.amber;
    final red         = AppColors.red;

    final isComic = ThemeModeManager.isComic3d;
    final radiusCard = AppColors.cardRadius;
    final radiusSmall = isComic ? 4.0 : 8.0;
    final bw = AppColors.borderWidth;

    return ThemeData(
      useMaterial3: true,
      brightness: isComic ? Brightness.light : Brightness.dark,
      fontFamily: _font,
      scaffoldBackgroundColor: bg,

      colorScheme: ColorScheme(
        brightness: isComic ? Brightness.light : Brightness.dark,
        primary: primaryLight,
        onPrimary: bg,
        primaryContainer: primaryDark,
        onPrimaryContainer: text,
        secondary: primaryMid,
        onSecondary: bg,
        secondaryContainer: borderLit,
        onSecondaryContainer: text,
        tertiary: green,
        onTertiary: bg,
        error: red,
        onError: text,
        surface: surface,
        onSurface: text,
        outline: border,
        outlineVariant: borderLit,
        shadow: Colors.black,
        scrim: Colors.black87,
        inverseSurface: text,
        onInverseSurface: bg,
        inversePrimary: primaryDark,
      ),

      appBarTheme: AppBarTheme(
        backgroundColor: surface,
        foregroundColor: text,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontFamily: _font,
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: text,
          letterSpacing: 0.4,
        ),
        iconTheme: IconThemeData(color: primaryMid, size: 22),
        actionsIconTheme: IconThemeData(color: textSub, size: 20),
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: isComic ? Brightness.dark : Brightness.light,
          statusBarBrightness: isComic ? Brightness.light : Brightness.dark,
          systemNavigationBarColor: bg,
          systemNavigationBarIconBrightness: isComic ? Brightness.dark : Brightness.light,
        ),
      ),

      cardTheme: CardThemeData(
        color: card,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          side: BorderSide(color: border, width: bw),
        ),
        clipBehavior: Clip.antiAlias,
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.disabled)) return border;
            if (s.contains(WidgetState.pressed))  return primaryDark;
            return primaryLight;
          }),
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.disabled)) return textDim;
            return bg;
          }),
          overlayColor: WidgetStateProperty.all(text.withOpacity(0.1)),
          elevation: WidgetStateProperty.all(0),
          shadowColor: WidgetStateProperty.all(Colors.transparent),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusCard)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 0.8),
          ),
          animationDuration: const Duration(milliseconds: 180),
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) return text;
            return primaryMid;
          }),
          side: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) return BorderSide(color: primaryMid, width: 1.5);
            if (s.contains(WidgetState.focused)) return BorderSide(color: primaryLight, width: 1.5);
            return BorderSide(color: borderLit, width: 1);
          }),
          backgroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) return primaryLight.withOpacity(0.08);
            return Colors.transparent;
          }),
          overlayColor: WidgetStateProperty.all(primaryLight.withOpacity(0.06)),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusCard)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.6),
          ),
        ),
      ),

      textButtonTheme: TextButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) return text;
            return primaryMid;
          }),
          overlayColor: WidgetStateProperty.all(primaryLight.withOpacity(0.08)),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusSmall)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w500, letterSpacing: 0.4),
          ),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        hoverColor: card,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          borderSide: BorderSide(color: border, width: bw),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          borderSide: BorderSide(color: border, width: bw),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          borderSide: BorderSide(color: primaryLight, width: bw + 0.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          borderSide: BorderSide(color: red, width: bw),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          borderSide: BorderSide(color: red, width: bw + 0.5),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          borderSide: BorderSide(color: textDim, width: bw),
        ),
        labelStyle: TextStyle(color: textSub, fontSize: 13),
        hintStyle: TextStyle(color: textDim, fontSize: 13),
        errorStyle: TextStyle(color: red, fontSize: 11),
        prefixIconColor: textSub,
        suffixIconColor: textSub,
        floatingLabelStyle: TextStyle(color: primaryLight, fontSize: 12),
      ),

      chipTheme: ChipThemeData(
        backgroundColor: surface,
        selectedColor: primaryDark,
        disabledColor: border,
        deleteIconColor: textSub,
        labelStyle: TextStyle(color: text, fontSize: 12, fontFamily: _font),
        secondaryLabelStyle: TextStyle(color: text, fontSize: 12, fontFamily: _font),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusSmall),
          side: BorderSide(color: border),
        ),
        side: BorderSide(color: border),
        elevation: 0,
        pressElevation: 0,
        showCheckmark: false,
      ),

      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: primaryLight,
        unselectedItemColor: textDim,
        elevation: 0,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: const TextStyle(fontSize: 10, fontFamily: _font, fontWeight: FontWeight.w600),
        unselectedLabelStyle: const TextStyle(fontSize: 10, fontFamily: _font),
      ),

      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surface,
        indicatorColor: primaryDark.withOpacity(0.45),
        iconTheme: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return IconThemeData(color: primaryLight, size: 22);
          return IconThemeData(color: textDim, size: 22);
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) {
            return TextStyle(color: primaryLight, fontSize: 11, fontFamily: _font, fontWeight: FontWeight.w600);
          }
          return TextStyle(color: textDim, fontSize: 11, fontFamily: _font);
        }),
        elevation: 0,
        overlayColor: WidgetStateProperty.all(primaryLight.withOpacity(0.06)),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      ),

      drawerTheme: DrawerThemeData(
        backgroundColor: surface,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(radiusCard + 8),
            bottomRight: Radius.circular(radiusCard + 8),
          ),
        ),
      ),

      dialogTheme: DialogThemeData(
        backgroundColor: card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusCard + 4),
          side: BorderSide(color: borderLit, width: bw),
        ),
        titleTextStyle: TextStyle(
          fontFamily: _font,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: text,
          letterSpacing: 0.2,
        ),
        contentTextStyle: TextStyle(
          fontFamily: _font,
          fontSize: 14,
          color: textSub,
          height: 1.6,
        ),
      ),

      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: surface,
        modalBackgroundColor: surface,
        elevation: 0,
        modalElevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(radiusCard + 8)),
        ),
        showDragHandle: true,
        dragHandleColor: borderLit,
        dragHandleSize: const Size(40, 4),
        clipBehavior: Clip.antiAlias,
      ),

      snackBarTheme: SnackBarThemeData(
        backgroundColor: card,
        contentTextStyle: TextStyle(color: text, fontFamily: _font, fontSize: 13),
        actionTextColor: primaryLight,
        behavior: SnackBarBehavior.floating,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          side: BorderSide(color: borderLit, width: bw),
        ),
      ),

      tabBarTheme: TabBarThemeData(
        labelColor: primaryLight,
        unselectedLabelColor: textDim,
        indicatorColor: primaryLight,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: const TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w600),
        unselectedLabelStyle: const TextStyle(fontFamily: _font, fontSize: 13),
        overlayColor: WidgetStateProperty.all(primaryLight.withOpacity(0.06)),
        dividerColor: border,
      ),

      listTileTheme: ListTileThemeData(
        tileColor: Colors.transparent,
        selectedTileColor: primaryLight.withOpacity(0.1),
        iconColor: textSub,
        selectedColor: primaryLight,
        textColor: text,
        subtitleTextStyle: TextStyle(color: textSub, fontSize: 12),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusSmall),
        ),
      ),

      dividerTheme: DividerThemeData(
        color: border,
        thickness: bw,
        space: 1,
      ),

      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return primaryLight;
          return textDim;
        }),
        trackColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return primaryDark.withOpacity(0.5);
          return border;
        }),
        trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
        overlayColor: WidgetStateProperty.all(primaryLight.withOpacity(0.08)),
      ),

      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return primaryLight;
          return Colors.transparent;
        }),
        checkColor: WidgetStateProperty.all(bg),
        side: BorderSide(color: borderLit, width: 1.5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        overlayColor: WidgetStateProperty.all(primaryLight.withOpacity(0.08)),
      ),

      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return primaryLight;
          return textDim;
        }),
        overlayColor: WidgetStateProperty.all(primaryLight.withOpacity(0.08)),
      ),

      sliderTheme: SliderThemeData(
        activeTrackColor: primaryLight,
        inactiveTrackColor: border,
        thumbColor: primaryLight,
        overlayColor: primaryLight.withOpacity(0.12),
        valueIndicatorColor: primaryDark,
        valueIndicatorTextStyle: TextStyle(color: text, fontSize: 12, fontFamily: _font),
        trackHeight: 3,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
      ),

      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: primaryLight,
        linearTrackColor: border,
        circularTrackColor: border,
        linearMinHeight: 3,
      ),

      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: primaryLight,
        foregroundColor: bg,
        elevation: 0,
        focusElevation: 0,
        hoverElevation: 0,
        highlightElevation: 0,
        splashColor: text.withOpacity(0.2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusCard)),
      ),

      iconTheme: IconThemeData(color: primaryMid, size: 22),
      primaryIconTheme: IconThemeData(color: primaryLight, size: 22),

      popupMenuTheme: PopupMenuThemeData(
        color: card,
        elevation: 0,
        shadowColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusCard),
          side: BorderSide(color: borderLit, width: bw),
        ),
        textStyle: TextStyle(color: text, fontFamily: _font, fontSize: 13),
        labelTextStyle: WidgetStateProperty.all(
          TextStyle(color: text, fontFamily: _font, fontSize: 13),
        ),
        iconColor: textSub,
      ),

      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(radiusSmall),
          border: Border.all(color: borderLit),
        ),
        textStyle: TextStyle(color: text, fontSize: 11, fontFamily: _font),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      ),

      scrollbarTheme: ScrollbarThemeData(
        thumbColor: WidgetStateProperty.all(borderLit),
        trackColor: WidgetStateProperty.all(surface),
        radius: const Radius.circular(4),
        thickness: WidgetStateProperty.all(3),
        crossAxisMargin: 2,
      ),

      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: _SteelTransitionBuilder(),
          TargetPlatform.iOS:     _SteelTransitionBuilder(),
          TargetPlatform.windows: _SteelTransitionBuilder(),
          TargetPlatform.macOS:   _SteelTransitionBuilder(),
          TargetPlatform.linux:   _SteelTransitionBuilder(),
        },
      ),

      textTheme: TextTheme(
        displayLarge:   TextStyle(fontFamily: _font, fontSize: 57, fontWeight: FontWeight.w800, color: text, letterSpacing: -1.5),
        displayMedium:  TextStyle(fontFamily: _font, fontSize: 45, fontWeight: FontWeight.w700, color: text, letterSpacing: -1.0),
        displaySmall:   TextStyle(fontFamily: _font, fontSize: 36, fontWeight: FontWeight.w700, color: text, letterSpacing: -0.5),
        headlineLarge:  TextStyle(fontFamily: _font, fontSize: 32, fontWeight: FontWeight.w700, color: text, letterSpacing: -0.3),
        headlineMedium: TextStyle(fontFamily: _font, fontSize: 26, fontWeight: FontWeight.w600, color: text, letterSpacing: -0.2),
        headlineSmall:  TextStyle(fontFamily: _font, fontSize: 22, fontWeight: FontWeight.w600, color: text),
        titleLarge:     TextStyle(fontFamily: _font, fontSize: 18, fontWeight: FontWeight.w600, color: text, letterSpacing: 0.2),
        titleMedium:    TextStyle(fontFamily: _font, fontSize: 15, fontWeight: FontWeight.w500, color: text, letterSpacing: 0.1),
        titleSmall:     TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w500, color: textSub),
        bodyLarge:      TextStyle(fontFamily: _font, fontSize: 16, fontWeight: FontWeight.w400, color: text, height: 1.6),
        bodyMedium:     TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w400, color: text, height: 1.6),
        bodySmall:      TextStyle(fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w400, color: textSub, height: 1.5),
        labelLarge:     TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600, color: text, letterSpacing: 0.5),
        labelMedium:    TextStyle(fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w500, color: textSub, letterSpacing: 0.4),
        labelSmall:     TextStyle(fontFamily: _font, fontSize: 10, fontWeight: FontWeight.w500, color: textDim, letterSpacing: 0.6),
      ),
    );
  }
}

// ═════════════════════════════════════════════
//  CUSTOM PAGE TRANSITION
// ═════════════════════════════════════════════
class _SteelTransitionBuilder extends PageTransitionsBuilder {
  const _SteelTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final inCurve  = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
    final outCurve = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInCubic);

    return FadeTransition(
      opacity: inCurve,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.035),
          end: Offset.zero,
        ).animate(inCurve),
        child: FadeTransition(
          opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
          child: ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════
//  ROUTE BUILDER
// ═════════════════════════════════════════════
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  Widget page;

  switch (settings.name) {
    case '/':
      page = const LandingPage();
      break;

    case '/login':
      page = const LoginPage();
      break;

    case '/dashboard':
      page = DashboardPage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        sessionKey:  args['key']         as String,
        expiredDate: args['expiredDate'] as String,
        listBug:  List<Map<String, dynamic>>.from(args['listBug']  ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news:     List<Map<String, dynamic>>.from(args['news']     ?? []),
      );
      break;

    case '/home':
      page = HomePage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        expiredDate: args['expiredDate'] as String,
        sessionKey:  args['sessionKey']  as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
      );
      break;

    case '/seller':
      page = SellerPage(keyToken: args!['keyToken'] as String);
      break;

    case '/admin':
      page = AdminPage(sessionKey: args!['sessionKey'] as String);
      break;

    case '/owner':
      page = OwnerPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );
      break;

    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration: const Duration(milliseconds: 320),
    reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final inCurve  = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      final outCurve = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInCubic);

      return FadeTransition(
        opacity: inCurve,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.035),
            end: Offset.zero,
          ).animate(inCurve),
          child: FadeTransition(
            opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
              child: child,
            ),
          ),
        ),
      );
    },
  );
}

// ═════════════════════════════════════════════
//  404 PAGE
// ═════════════════════════════════════════════
class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  State<_NotFoundPage> createState() => _NotFoundPageState();
}

class _NotFoundPageState extends State<_NotFoundPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>   _fade;
  late final Animation<Offset>   _slide;
  late final Animation<double>   _glow;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))
      ..forward();

    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _glow  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1, curve: Curves.easeOut)));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: SlideTransition(
            position: _slide,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _glow,
                    builder: (_, child) => Container(
                      width: 88, height: 88,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.card,
                        border: Border.all(color: AppColors.borderLit, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.accentMid.withOpacity(0.18 * _glow.value),
                            blurRadius: 40,
                            spreadRadius: 6,
                          ),
                        ],
                      ),
                      child: child,
                    ),
                    child: Icon(Icons.explore_off_rounded, color: AppColors.textSub, size: 34),
                  ),

                  const SizedBox(height: 28),

                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [AppColors.textHint, AppColors.borderLit],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: const Text(
                      '404',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 72,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        height: 1,
                        letterSpacing: -3,
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    'Route not found',
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSub,
                      letterSpacing: 0.3,
                    ),
                  ),

                  const SizedBox(height: 6),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.dark,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Text(
                      '"${widget.routeName}"',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 12,
                        color: AppColors.textHint,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),

                  const SizedBox(height: 36),

                  OutlinedButton.icon(
                    onPressed: () =>
                        Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false),
                    icon: const Icon(Icons.arrow_back_rounded, size: 16),
                    label: const Text('Back to Login'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════
//  ENTRY POINT
// ═════════════════════════════════════════════
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();  // ← WAJIB untuk SharedPreferences
  await ThemeModeManager.load();              // ← LOAD TEMA TERSIMPAN

  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: ThemeModeManager.isComic3d ? Brightness.dark : Brightness.light,
    statusBarBrightness: ThemeModeManager.isComic3d ? Brightness.light : Brightness.dark,
    systemNavigationBarColor: AppColors.bg,
    systemNavigationBarDividerColor: Colors.transparent,
    systemNavigationBarIconBrightness: ThemeModeManager.isComic3d ? Brightness.dark : Brightness.light,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const _OrcaApp());
}

// ═════════════════════════════════════════════
//  ROOT APP WIDGET
// ═════════════════════════════════════════════
class _OrcaApp extends StatelessWidget {
  const _OrcaApp();

  @override
  Widget build(BuildContext context) {
    return ThemeScope(                    // ← WAJIB: auto-rebuild saat tema ganti
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'XENCODE',
        theme: _AppTheme.build(),         // ← theme rebuild tiap ganti mode
        initialRoute: '/',
        onGenerateRoute: _generateRoute,
        builder: (context, child) {
          final mq = MediaQuery.of(context);
          return MediaQuery(
            data: mq.copyWith(
              textScaler: TextScaler.linear(
                mq.textScaleFactor.clamp(0.85, 1.2),
              ),
            ),
            child: child ?? const SizedBox.shrink(),
          );
        },
      ),
    );
  }
}