// custom.dart
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'theme.dart';
import 'bug_sender.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';
const String baseUrl = "http://digital.mypanelku.web.id:2041";

// ─── PALETTE (alias ke AppColors dinamis) ──────────────────────────────
class _CP {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get card2     => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get glassBg   => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static Color get primary    => AppColors.accent;
  static Color get primaryMid => AppColors.accentMid;
  static Color get primaryLt  => AppColors.accentLight;
  static Color get primaryDk  => AppColors.accentDark;

  static Color get success => AppColors.green;
  static Color get warning => AppColors.amber;
  static Color get danger  => AppColors.red;
  static Color get accent  => AppColors.accent;

  static Color get text     => AppColors.text;
  static Color get textSub  => AppColors.textSub;
  static Color get textDim  => AppColors.textHint;

  static LinearGradient get btnGrad     => AppColors.btnGrad;
  static LinearGradient get glassGrad   => AppColors.glassGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow  => AppColors.softShadow;
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ═══════════════════════════════════════════════════════════════════════
//  CUSTOM PAYLOAD PAGE
// ═══════════════════════════════════════════════════════════════════════
class CustomPayloadPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final List<Map<String, dynamic>> listBug;

  const CustomPayloadPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.listBug,
  });

  @override
  State<CustomPayloadPage> createState() => _CustomPayloadPageState();
}

class _CustomPayloadPageState extends State<CustomPayloadPage>
    with TickerProviderStateMixin {
  final TextEditingController _targetCtrl =
      TextEditingController();
  final TextEditingController _delayCtrl =
      TextEditingController(text: "1000");
  final TextEditingController _countCtrl =
      TextEditingController(text: "1");

  // Bug terpilih (urutan di sini = urutan kirim)
  final List<Map<String, dynamic>> _selected = [];
  bool _isSending = false;
  int _progressDone = 0;
  int _progressTotal = 0;
  int _progressSuccess = 0;
  int _progressFail = 0;

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.97, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _targetCtrl.dispose();
    _delayCtrl.dispose();
    _countCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ─── Filter bug: hanya private/number ──────────────────────────────
  List<Map<String, dynamic>> get _availableBugs {
    return widget.listBug.where((bug) {
      final type = bug['type']?.toString().toLowerCase() ?? 'private';
      return type == 'private' || type == 'both';
    }).toList();
  }

  // ─── Helper format nomor ───────────────────────────────────────────
  String? _formatPhone(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleaned.isEmpty || cleaned.length < 8) return null;
    if (cleaned.startsWith('0')) return null;
    return cleaned;
  }

  // ─── Gradient per bug (visual) ─────────────────────────────────────
  List<Color> _bugGradient(int index) {
    final palettes = [
      [_CP.primary, _CP.primaryMid],
      [const Color(0xFFFF6B6B), const Color(0xFFFF8E53)],
      [const Color(0xFF8E54E9), const Color(0xFF4776E6)],
      [const Color(0xFFFFD166), const Color(0xFFFFB347)],
      [const Color(0xFF06D6A0), const Color(0xFF4CC9F0)],
    ];
    return palettes[index % palettes.length];
  }

  // ─── Cek sender aktif ──────────────────────────────────────────────
  Future<bool> _hasSender() async {
    try {
      final res = await http.get(
        Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"),
      );
      if (res.statusCode != 200) return false;
      final data = jsonDecode(res.body);
      return data["valid"] == true &&
          data["connections"] != null &&
          (data["connections"] as List).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  // ─── Kirim sequential via GET satu per satu ────────────────────────
  Future<void> _sendSequential() async {
    // 1. Validasi target
    final target = _formatPhone(_targetCtrl.text.trim());
    if (target == null) {
      _toast('Nomor tidak valid (jangan pakai 0 di depan)', _CP.warning);
      return;
    }

    // 2. Validasi bug dipilih
    if (_selected.isEmpty) {
      _toast('Pilih minimal 1 bug', _CP.warning);
      return;
    }

    // 3. Validasi delay & count
    final delay = int.tryParse(_delayCtrl.text) ?? 1000;
    final count = int.tryParse(_countCtrl.text) ?? 1;
    if (delay < 0 || delay > 60000) {
      _toast('Delay 0-60000 ms', _CP.warning);
      return;
    }
    if (count < 1 || count > 100) {
      _toast('Count 1-100', _CP.warning);
      return;
    }

    // 4. Cek sender
    final hasSender = await _hasSender();
    if (!hasSender) {
      _showDialog(
        "Sender Required",
        "Kamu belum punya sender aktif.\nTambahkan sender dulu sebelum kirim payload.",
        Icons.wifi_find_rounded,
        _CP.warning,
        actionLabel: 'TAMBAH SENDER',
        onAction: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: widget.sessionKey,
                username: widget.username,
                role: widget.role,
              ),
            ),
          );
        },
      );
      return;
    }

    // 5. Mulai
    setState(() {
      _isSending = true;
      _progressDone = 0;
      _progressSuccess = 0;
      _progressFail = 0;
      _progressTotal = count * _selected.length;
    });

    String lastError = '';

    try {
      for (int c = 0; c < count; c++) {
        for (int i = 0; i < _selected.length; i++) {
          if (!mounted) return;
          final bug = _selected[i];
          final bugId = bug['bug_id']?.toString() ?? '';

          try {
            // ✅ GET request ke /sendBug
            final url = Uri.parse(
              "$baseUrl/sendBug"
              "?key=${widget.sessionKey}"
              "&target=$target"
              "&bug=$bugId"
              "&senderMode=private",
            );

            final res = await http
                .get(url)
                .timeout(const Duration(seconds: 30));

            final data = jsonDecode(res.body);

            if (data['sended'] == true) {
              _progressSuccess++;
            } else if (data['cooldown'] == true) {
              _progressFail++;
              lastError = 'Cooldown ${data['wait'] ?? ''}s';
            } else {
              _progressFail++;
              lastError = data['message']?.toString() ?? 'Gagal';
            }
          } catch (e) {
            _progressFail++;
            lastError = 'Error: $e';
          }

          if (!mounted) return;
          setState(() => _progressDone++);

          // Delay antar payload (kecuali terakhir)
          final isLast =
              (c == count - 1) && (i == _selected.length - 1);
          if (!isLast && delay > 0) {
            await Future.delayed(Duration(milliseconds: delay));
          }
        }
      }

      // 6. Selesai
      if (!mounted) return;
      setState(() => _isSending = false);

      _showSuccessSheet(
        target: target,
        totalSent: _progressSuccess,
        totalFail: _progressFail,
        bugCount: _selected.length,
        repeatCount: count,
        delayMs: delay,
        lastError: lastError,
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSending = false);
      _toast('Error: $e', _CP.danger);
    }
  }

  // ─── Toast ─────────────────────────────────────────────────────────
  void _toast(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(
              color: _onAccent(),
              fontWeight: FontWeight.w600,
              fontFamily: kFont)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
      margin: const EdgeInsets.all(16),
    ));
  }

  // ─── Dialog ────────────────────────────────────────────────────────
  void _showDialog(
    String title,
    String message,
    IconData icon,
    Color color, {
    String actionLabel = 'OK',
    VoidCallback? onAction,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(28),
        child: Container(
          decoration: BoxDecoration(
            gradient: isComic ? null : _CP.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(isComic ? 6 : 24),
            border: Border.all(
              color: color.withOpacity(0.4),
              width: isComic ? 3 : 1.5,
            ),
            boxShadow: _CP.glassShadow,
          ),
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 72, height: 72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color.withOpacity(0.15),
                    border: Border.all(
                        color: color.withOpacity(0.4), width: 2),
                  ),
                  child: Icon(icon, color: color, size: 32),
                ),
                const SizedBox(height: 20),
                Text(title,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: _CP.text,
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        fontFamily: kFont)),
                const SizedBox(height: 12),
                Text(message,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: _CP.textSub,
                        fontSize: 13,
                        height: 1.5,
                        fontFamily: kFont)),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                      onAction?.call();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: color,
                      foregroundColor: _onAccent(),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            isComic ? 4 : 12),
                      ),
                    ),
                    child: Text(actionLabel,
                        style: TextStyle(
                            color: _onAccent(),
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFont,
                            letterSpacing: 1)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── Success sheet ─────────────────────────────────────────────────
  void _showSuccessSheet({
    required String target,
    required int totalSent,
    required int totalFail,
    required int bugCount,
    required int repeatCount,
    required int delayMs,
    required String lastError,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.fromLTRB(24, 26, 24, 22),
        decoration: BoxDecoration(
          gradient: isComic ? null : _CP.glassGrad,
          color: isComic ? AppColors.card : null,
          borderRadius: BorderRadius.circular(isComic ? 6 : 28),
          border: Border.all(
            color: _CP.success.withOpacity(0.4),
            width: isComic ? 3 : 1.5,
          ),
          boxShadow: _CP.glassShadow,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [_CP.success, _CP.primaryLt],
                ),
                border: isComic
                    ? Border.all(color: AppColors.border, width: 3)
                    : null,
              ),
              child: Icon(Icons.check_rounded,
                  color: _onAccent(), size: 36),
            ),
            const SizedBox(height: 18),
            Text('PAYLOAD SELESAI',
                style: TextStyle(
                    color: _CP.text,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFont,
                    letterSpacing: 1)),
            const SizedBox(height: 6),
            Text(
                'Berhasil: $totalSent  •  Gagal: $totalFail',
                style: TextStyle(
                    color: _CP.textSub,
                    fontSize: 13,
                    fontFamily: kFont)),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.dark,
                borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                border: Border.all(
                    color: _CP.border,
                    width: AppColors.borderWidth),
              ),
              child: Column(children: [
                _infoRow(Icons.phone_iphone_rounded, 'Target', target),
                _infoRow(
                    Icons.bug_report_rounded, 'Payload', '$bugCount bug'),
                _infoRow(Icons.repeat_rounded, 'Repeat', '${repeatCount}x'),
                _infoRow(
                    Icons.timer_outlined, 'Delay', '${delayMs}ms'),
                if (lastError.isNotEmpty)
                  _infoRow(
                    Icons.warning_amber_rounded,
                    'Info',
                    lastError.length > 30
                        ? '${lastError.substring(0, 30)}...'
                        : lastError,
                  ),
              ]),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    _selected.clear();
                    _progressDone = 0;
                    _progressTotal = 0;
                    _progressSuccess = 0;
                    _progressFail = 0;
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _CP.success,
                  foregroundColor: _onAccent(),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                        isComic ? 4 : 12),
                  ),
                ),
                child: Text('SELESAI',
                    style: TextStyle(
                        color: _onAccent(),
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        fontFamily: kFont,
                        letterSpacing: 1)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: _CP.success, size: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Text(label,
                style: TextStyle(
                    color: _CP.textSub,
                    fontSize: 12.5,
                    fontFamily: kFont)),
          ),
          Text(value,
              style: TextStyle(
                  color: _CP.text,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  fontFamily: kFont)),
        ],
      ),
    );
  }

  // ─── Bug picker sheet ──────────────────────────────────────────────
  void _openBugPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _BugPickerSheet(
        allBugs: _availableBugs,
        selectedBugs: _selected,
        bugGradient: _bugGradient,
        onToggle: (bug, index) {
          setState(() {
            final exists =
                _selected.any((s) => s['bug_id'] == bug['bug_id']);
            if (exists) {
              _selected
                  .removeWhere((s) => s['bug_id'] == bug['bug_id']);
            } else {
              _selected.add({
                'bug_id': bug['bug_id'],
                'bug_name': bug['bug_name'],
                'colorIndex': index,
              });
            }
          });
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _CP.bg,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding:
                          const EdgeInsets.fromLTRB(16, 12, 16, 24),
                      child: Column(
                        children: [
                          _buildTargetCard(),
                          const SizedBox(height: 12),
                          _buildBugQueueCard(),
                          const SizedBox(height: 12),
                          _buildConfigRow(),
                          const SizedBox(height: 16),
                          _buildSendButton(),
                          const SizedBox(height: 10),
                          _buildStatusBar(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── Header ────────────────────────────────────────────────────────
  Widget _buildHeader() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: isComic ? AppColors.card : Colors.white.withOpacity(0.04),
        border: Border(
          bottom: BorderSide(
            color: _CP.border,
            width: AppColors.borderWidth,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: _CP.primary.withOpacity(isComic ? 0.3 : 0.1),
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                border: Border.all(
                  color: _CP.primary.withOpacity(0.3),
                  width: AppColors.borderWidth,
                ),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  color: isComic
                      ? const Color(0xFF1A1A1A)
                      : _CP.primary,
                  size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CUSTOM PAYLOAD',
                    style: TextStyle(
                        color: _CP.text,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        fontFamily: kFont,
                        letterSpacing: 1)),
                Text('Multi-bug • Satu nomor',
                    style: TextStyle(
                        color: _CP.textSub,
                        fontSize: 10.5,
                        fontFamily: kFont)),
              ],
            ),
          ),
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Transform.scale(
              scale: _selected.isEmpty ? 1.0 : _pulseAnim.value,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  gradient: _CP.btnGrad,
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                  border: isComic
                      ? Border.all(color: AppColors.border, width: 2)
                      : null,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('${_selected.length}',
                        style: TextStyle(
                            color: _onAccent(),
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            fontFamily: kFont)),
                    const SizedBox(width: 4),
                    Text('BUG',
                        style: TextStyle(
                            color: _onAccent(),
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFont,
                            letterSpacing: 1)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Target input ──────────────────────────────────────────────────
  Widget _buildTargetCard() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: isComic ? null : _CP.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: _CP.primary.withOpacity(0.3),
          width: AppColors.borderWidth,
        ),
        boxShadow: _CP.glassShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: _CP.btnGrad,
              border: isComic
                  ? Border.all(color: AppColors.border, width: 2)
                  : null,
            ),
            child: Icon(Icons.phone_android_rounded,
                color: _onAccent(), size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('NOMOR TARGET',
                    style: TextStyle(
                        color: _CP.textSub,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        fontFamily: kFont,
                        letterSpacing: 1.4)),
                TextField(
                  controller: _targetCtrl,
                  keyboardType: TextInputType.phone,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                  ],
                  style: TextStyle(
                      color: _CP.text,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      fontFamily: kFont),
                  cursorColor: _CP.primary,
                  decoration: InputDecoration(
                    hintText: '62xxxxxxxxxx',
                    hintStyle: TextStyle(
                        color: _CP.textDim.withOpacity(0.5),
                        fontSize: 14,
                        fontFamily: kFont),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: const EdgeInsets.only(top: 4),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── Bug queue card ────────────────────────────────────────────────
  Widget _buildBugQueueCard() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: isComic ? null : _CP.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: _CP.border,
          width: AppColors.borderWidth,
        ),
        boxShadow: _CP.glassShadow,
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _CP.danger.withOpacity(isComic ? 0.3 : 0.15),
                  border: Border.all(
                      color: _CP.danger.withOpacity(0.4),
                      width: isComic ? 2 : 1),
                ),
                child: Icon(Icons.bug_report_rounded,
                    color: isComic
                        ? const Color(0xFF1A1A1A)
                        : _CP.danger,
                    size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text('ANTRIAN PAYLOAD',
                    style: TextStyle(
                        color: _CP.text,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        fontFamily: kFont,
                        letterSpacing: 1)),
              ),
              if (_selected.isNotEmpty)
                GestureDetector(
                  onTap: () => setState(() => _selected.clear()),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _CP.danger.withOpacity(0.15),
                      borderRadius:
                          BorderRadius.circular(isComic ? 3 : 8),
                      border: Border.all(
                          color: _CP.danger.withOpacity(0.4)),
                    ),
                    child: Text('Reset',
                        style: TextStyle(
                            color: _CP.danger,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFont)),
                  ),
                ),
            ],
          ),

          if (_selected.isNotEmpty) ...[
            const SizedBox(height: 12),
            SizedBox(
              height: 50,
              child: ReorderableListView.builder(
                scrollDirection: Axis.horizontal,
                buildDefaultDragHandles: false,
                itemCount: _selected.length,
                onReorder: (oldIdx, newIdx) {
                  setState(() {
                    if (newIdx > oldIdx) newIdx--;
                    final item = _selected.removeAt(oldIdx);
                    _selected.insert(newIdx, item);
                  });
                },
                proxyDecorator: (child, _, __) => Material(
                  color: Colors.transparent,
                  child: child,
                ),
                itemBuilder: (ctx, i) {
                  final bug = _selected[i];
                  final colors = _bugGradient(bug['colorIndex'] ?? i);
                  return ReorderableDragStartListener(
                    key: ValueKey(bug['bug_id']),
                    index: i,
                    child: Container(
                      margin: EdgeInsets.only(
                          right: i < _selected.length - 1 ? 8 : 0),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            colors[0].withOpacity(0.25),
                            colors[1].withOpacity(0.1),
                          ],
                        ),
                        borderRadius:
                            BorderRadius.circular(isComic ? 4 : 11),
                        border: Border.all(
                            color: colors[0].withOpacity(0.5),
                            width: isComic ? 2 : 1.2),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 18, height: 18,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient:
                                  LinearGradient(colors: colors),
                            ),
                            child: Center(
                              child: Text('${i + 1}',
                                  style: TextStyle(
                                      color: _onAccent(),
                                      fontSize: 9,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: kFont)),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(bug['bug_name'] ?? 'Bug',
                              style: TextStyle(
                                  color: _CP.text,
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: kFont)),
                          const SizedBox(width: 5),
                          GestureDetector(
                            onTap: () =>
                                setState(() => _selected.removeAt(i)),
                            child: Icon(Icons.close,
                                color: _CP.textSub, size: 13),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 6),
            Text('Tahan & geser untuk ubah urutan',
                style: TextStyle(
                    color: _CP.textDim,
                    fontSize: 9.5,
                    fontFamily: kFont,
                    letterSpacing: 0.3)),
          ],

          const SizedBox(height: 12),
          GestureDetector(
            onTap: _openBugPicker,
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                color: _CP.primary
                    .withOpacity(isComic ? 0.2 : 0.08),
                borderRadius: BorderRadius.circular(isComic ? 4 : 11),
                border: Border.all(
                  color: _CP.primary.withOpacity(0.3),
                  width: AppColors.borderWidth,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_circle_outline_rounded,
                      color: isComic
                          ? const Color(0xFF1A1A1A)
                          : _CP.primary,
                      size: 17),
                  const SizedBox(width: 7),
                  Text('Tambah Payload',
                      style: TextStyle(
                          color: isComic
                              ? const Color(0xFF1A1A1A)
                              : _CP.primary,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          fontFamily: kFont,
                          letterSpacing: 0.5)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Config row ────────────────────────────────────────────────────
  Widget _buildConfigRow() {
    return Row(
      children: [
        Expanded(
          child: _buildConfigTile(
            label: 'DELAY',
            sub: 'Interval (ms)',
            ctrl: _delayCtrl,
            colors: [_CP.warning, const Color(0xFFFF8E53)],
            icon: Icons.timer_outlined,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildConfigTile(
            label: 'COUNT',
            sub: 'Pengulangan',
            ctrl: _countCtrl,
            colors: [_CP.success, const Color(0xFF4CC9F0)],
            icon: Icons.repeat_rounded,
          ),
        ),
      ],
    );
  }

  Widget _buildConfigTile({
    required String label,
    required String sub,
    required TextEditingController ctrl,
    required List<Color> colors,
    required IconData icon,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: isComic
            ? null
            : LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colors[0].withOpacity(0.15),
                  colors[1].withOpacity(0.04),
                ],
              ),
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: colors[0].withOpacity(isComic ? 0.5 : 0.3),
          width: AppColors.borderWidth,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon,
                color: isComic
                    ? const Color(0xFF1A1A1A)
                    : colors[0],
                size: 15),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                    color: isComic
                        ? const Color(0xFF1A1A1A)
                        : colors[0],
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: kFont,
                    letterSpacing: 1)),
          ]),
          Text(sub,
              style: TextStyle(
                  color: _CP.textSub,
                  fontSize: 10,
                  fontFamily: kFont)),
          const SizedBox(height: 6),
          TextField(
            controller: ctrl,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            style: TextStyle(
              color: isComic ? const Color(0xFF1A1A1A) : colors[0],
              fontSize: 24,
              fontWeight: FontWeight.w800,
              fontFamily: kFont,
            ),
            cursorColor: colors[0],
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
              isDense: true,
            ),
          ),
        ],
      ),
    );
  }

  // ─── Send button ───────────────────────────────────────────────────
  Widget _buildSendButton() {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTap: _isSending ? null : _sendSequential,
      child: AnimatedBuilder(
        animation: _pulseCtrl,
        builder: (_, __) => Transform.scale(
          scale: _isSending ? 1.0 : _pulseAnim.value,
          child: Container(
            height: 56,
            decoration: BoxDecoration(
              gradient: _isSending ? null : _CP.btnGrad,
              color: _isSending ? _CP.textDim : null,
              borderRadius:
                  BorderRadius.circular(isComic ? 4 : 16),
              border: isComic
                  ? Border.all(color: AppColors.border, width: 3)
                  : null,
              boxShadow: _isSending
                  ? null
                  : (isComic
                      ? AppColors.softShadow
                      : [
                          BoxShadow(
                            color: _CP.primary.withOpacity(0.4),
                            blurRadius: 22,
                            offset: const Offset(0, 6),
                          ),
                        ]),
            ),
            child: Center(
              child: _isSending
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 18, height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: _onAccent(),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                            'MENGIRIM $_progressDone/$_progressTotal',
                            style: TextStyle(
                                color: _onAccent(),
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                fontFamily: kFont,
                                letterSpacing: 1)),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket_launch_rounded,
                            color: _onAccent(), size: 20),
                        const SizedBox(width: 12),
                        Text('KIRIM PAYLOAD',
                            style: TextStyle(
                                color: _onAccent(),
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                fontFamily: kFont,
                                letterSpacing: 1.5)),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── Status bar ────────────────────────────────────────────────────
  Widget _buildStatusBar() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: isComic
            ? AppColors.card2
            : Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(isComic ? 4 : 13),
        border: Border.all(
          color: _CP.border,
          width: AppColors.borderWidth,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 7, height: 7,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _isSending
                  ? _CP.warning
                  : (_selected.isEmpty ? _CP.textDim : _CP.success),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _isSending
                  ? 'Mengirim $_progressDone/$_progressTotal  ✓$_progressSuccess ✗$_progressFail'
                  : _selected.isEmpty
                      ? 'Belum ada bug dipilih'
                      : '${_selected.length} bug  •  ${_delayCtrl.text}ms  •  ${_countCtrl.text}x',
              style: TextStyle(
                  color: _CP.textSub,
                  fontSize: 11.5,
                  fontFamily: kFont,
                  letterSpacing: 0.3),
            ),
          ),
          if (_selected.isNotEmpty && !_isSending)
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 9, vertical: 3),
              decoration: BoxDecoration(
                color: _CP.primary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(isComic ? 3 : 7),
                border: Border.all(
                    color: _CP.primary.withOpacity(0.3)),
              ),
              child: Text('READY',
                  style: TextStyle(
                      color: isComic
                          ? const Color(0xFF1A1A1A)
                          : _CP.primary,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w800,
                      fontFamily: kFont,
                      letterSpacing: 1.2)),
            ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  BUG PICKER SHEET
// ═══════════════════════════════════════════════════════════════════════
class _BugPickerSheet extends StatelessWidget {
  final List<Map<String, dynamic>> allBugs;
  final List<Map<String, dynamic>> selectedBugs;
  final List<Color> Function(int) bugGradient;
  final void Function(Map<String, dynamic>, int) onToggle;

  const _BugPickerSheet({
    required this.allBugs,
    required this.selectedBugs,
    required this.bugGradient,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    return Container(
      constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.6),
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: isComic ? null : AppColors.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(isComic ? 6 : 28),
        border: Border.all(
          color: _CP.border,
          width: AppColors.borderWidth,
        ),
        boxShadow: AppColors.glassShadow,
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 36, height: 4,
            decoration: BoxDecoration(
              color: _CP.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
            child: Row(
              children: [
                Icon(Icons.bug_report_rounded,
                    color: _CP.primary, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text('PILIH BUG',
                      style: TextStyle(
                          color: _CP.text,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          fontFamily: kFont,
                          letterSpacing: 1)),
                ),
                Text('${selectedBugs.length} dipilih',
                    style: TextStyle(
                        color: _CP.textSub,
                        fontSize: 11,
                        fontFamily: kFont)),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close_rounded,
                      color: _CP.textSub, size: 20),
                ),
              ],
            ),
          ),
          Container(height: 1, color: _CP.border),
          Expanded(
            child: allBugs.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Text(
                        'Tidak ada bug number/private.\nBug grup tidak bisa dipakai di mode custom.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: _CP.textSub,
                            fontSize: 12.5,
                            height: 1.5,
                            fontFamily: kFont),
                      ),
                    ),
                  )
                : ListView.builder(
                    padding:
                        const EdgeInsets.fromLTRB(16, 12, 16, 20),
                    itemCount: allBugs.length,
                    itemBuilder: (ctx, i) {
                      final bug = allBugs[i];
                      final isSelected = selectedBugs
                          .any((s) => s['bug_id'] == bug['bug_id']);
                      final colors = bugGradient(i);

                      return GestureDetector(
                        onTap: () => onToggle(bug, i),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 9),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            gradient: isSelected
                                ? LinearGradient(
                                    colors: [
                                      colors[0].withOpacity(0.25),
                                      colors[1].withOpacity(0.08),
                                    ],
                                  )
                                : _CP.glassGrad,
                            borderRadius:
                                BorderRadius.circular(isComic ? 4 : 14),
                            border: Border.all(
                              color: isSelected
                                  ? colors[0].withOpacity(0.6)
                                  : _CP.border,
                              width: isSelected
                                  ? (isComic ? 3 : 1.5)
                                  : AppColors.borderWidth,
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 38, height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                      colors: colors),
                                  border: isComic
                                      ? Border.all(
                                          color: AppColors.border,
                                          width: 2)
                                      : null,
                                ),
                                child: Icon(Icons.security_rounded,
                                    color: _onAccent(), size: 16),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(bug['bug_name'] ?? 'Unknown',
                                        style: TextStyle(
                                            color: isSelected
                                                ? _CP.text
                                                : _CP.textSub,
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: kFont)),
                                    Text(
                                        'type: ${bug['type'] ?? 'private'}',
                                        style: TextStyle(
                                            color: _CP.textDim,
                                            fontSize: 10,
                                            fontFamily: kFont)),
                                  ],
                                ),
                              ),
                              Container(
                                width: 26, height: 26,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: isSelected
                                      ? LinearGradient(colors: colors)
                                      : null,
                                  color: isSelected
                                      ? null
                                      : Colors.transparent,
                                  border: isSelected
                                      ? null
                                      : Border.all(
                                          color: _CP.border,
                                          width: 1.5),
                                ),
                                child: Icon(
                                  isSelected ? Icons.check : Icons.add,
                                  color: isSelected
                                      ? _onAccent()
                                      : _CP.textSub,
                                  size: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}