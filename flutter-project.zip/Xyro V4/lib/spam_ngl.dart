import 'dart:math';
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── Palette Merah Glass ───────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A0A0F);
  static const surface   = Color(0x1AFFFFFF);
  static const card      = Color(0x0DFFFFFF);
  static const border    = Color(0x1AFFFFFF);
  static const borderLit = Color(0x33FFFFFF);

  static const primary   = Color(0xFFFF1744);
  static const primaryMid = Color(0xFFFF5252);
  static const primaryLt  = Color(0xFFFF8A80);
  static const primaryDk  = Color(0xFFB71C1C);

  static const success   = Color(0xFF00E676);
  static const amber     = Color(0xFFFFB300);
  static const red       = Color(0xFFFF1744);

  static const text      = Color(0xFFF5EEEE);
  static const textSub   = Color(0xFFE0AAAA);
  static const textDim   = Color(0xFF994444);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.06),
      Colors.white.withOpacity(0.02),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> get softShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.15),
      blurRadius: 16,
      offset: const Offset(0, 4),
    ),
  ];
}

class NglPage extends StatefulWidget {
  const NglPage({super.key});

  @override
  State<NglPage> createState() => _NglPageState();
}

class _NglPageState extends State<NglPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  bool isRunning = false;
  int counter = 0;
  int failedCount = 0;
  String statusLog = "";
  Timer? timer;

  // ─── HELPER ─────────────────────────────────────────────────────────
  String generateDeviceId(int length) {
    final random = Random.secure();
    return List.generate(length, (_) => random.nextInt(16).toRadixString(16)).join();
  }

  Future<void> sendMessage(String username, String message) async {
    final deviceId = generateDeviceId(42);
    final url = Uri.parse("https://ngl.link/api/submit");

    final headers = {
      "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
      "Accept": "*/*",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      "Referer": "https://ngl.link/$username",
      "Origin": "https://ngl.link"
    };

    final body =
        "username=$username&question=$message&deviceId=$deviceId&gameSlug=&referrer=";

    try {
      final response = await http
          .post(url, headers: headers, body: body)
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        setState(() {
          counter++;
          statusLog = "✅ [$counter] Pesan terkirim";
        });
      } else {
        setState(() {
          failedCount++;
          statusLog = "❌ Ratelimit (${response.statusCode}), tunggu 5 detik...";
        });
        await Future.delayed(const Duration(seconds: 5));
      }
    } catch (e) {
      setState(() {
        failedCount++;
        statusLog = "⚠️ Error: $e";
      });
      await Future.delayed(const Duration(seconds: 2));
    }
  }

  void startLoop() {
    final username = usernameController.text.trim();
    final message = messageController.text.trim();

    if (username.isEmpty || message.isEmpty) {
      setState(() {
        statusLog = "⚠️ Harap isi username & pesan!";
      });
      return;
    }

    setState(() {
      isRunning = true;
      counter = 0;
      failedCount = 0;
      statusLog = "▶️ Mulai mengirim...";
    });

    timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (isRunning) {
        sendMessage(username, message);
      }
    });
  }

  void stopLoop() {
    setState(() {
      isRunning = false;
      statusLog = "⏹️ Dihentikan.";
    });
    timer?.cancel();
  }

  @override
  void dispose() {
    timer?.cancel();
    usernameController.dispose();
    messageController.dispose();
    super.dispose();
  }

  // ─── STATUS COLOR ───────────────────────────────────────────────────
  Color _getStatusColor(String status) {
    if (status.contains('✅')) return _C.success;
    if (status.contains('❌')) return _C.red;
    if (status.contains('⚠️')) return _C.amber;
    if (status.contains('▶️')) return _C.success;
    if (status.contains('⏹️')) return _C.amber;
    return _C.text;
  }

  // ─── BUILD ──────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          // ✅ BACKGROUND FOTO mmk.jpg
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _C.bg),
            ),
          ),

          // ✅ Overlay gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.bg.withOpacity(0.78),
                    _C.bg.withOpacity(0.88),
                    _C.bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              child: Column(
                children: [
                  _buildInputCard(),
                  const SizedBox(height: 16),
                  _buildControlCard(),
                  const SizedBox(height: 16),
                  _buildStatusCard(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: Padding(
        padding: const EdgeInsets.all(8),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: _C.border),
            ),
            child: Icon(Icons.arrow_back_ios_new_rounded,
                color: _C.textSub, size: 16),
          ),
        ),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.primary,
              boxShadow: [
                BoxShadow(
                    color: _C.primary.withOpacity(0.6), blurRadius: 8)
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'NGL Auto Sender',
            style: TextStyle(
              fontFamily: kFont,
              fontWeight: FontWeight.bold,
              color: _C.text,
              letterSpacing: 1.2,
              fontSize: 15,
              shadows: [
                Shadow(
                    color: _C.primary.withOpacity(0.3), blurRadius: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── INPUT CARD ─────────────────────────────────────────────────────
  Widget _buildInputCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
            boxShadow: _C.softShadow,
          ),
          child: Column(
            children: [
              TextField(
                controller: usernameController,
                style: TextStyle(
                    color: _C.text, fontFamily: kFont, fontSize: 14),
                cursorColor: _C.primaryLt,
                decoration: InputDecoration(
                  labelText: "Username NGL",
                  labelStyle: TextStyle(
                      color: _C.primaryLt, fontFamily: kFont, fontSize: 13),
                  hintText: "contoh: username_ngl",
                  hintStyle: TextStyle(
                      color: _C.textDim, fontFamily: kFont, fontSize: 12),
                  prefixIcon:
                      Icon(Icons.person_rounded, color: _C.primaryLt, size: 20),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _C.border),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _C.primaryLt, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: _C.surface,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: messageController,
                style: TextStyle(
                    color: _C.text, fontFamily: kFont, fontSize: 14),
                cursorColor: _C.primaryLt,
                maxLines: 3,
                decoration: InputDecoration(
                  labelText: "Pesan",
                  labelStyle: TextStyle(
                      color: _C.primaryLt, fontFamily: kFont, fontSize: 13),
                  hintText: "Masukkan pesan...",
                  hintStyle: TextStyle(
                      color: _C.textDim, fontFamily: kFont, fontSize: 12),
                  prefixIcon:
                      Icon(Icons.message_rounded, color: _C.primaryLt, size: 20),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _C.border),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _C.primaryLt, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: _C.surface,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── CONTROL CARD ───────────────────────────────────────────────────
  Widget _buildControlCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
          ),
          child: Row(
            children: [
              Expanded(
                child: _buildControlButton(
                  label: "START",
                  icon: Icons.play_arrow_rounded,
                  enabled: !isRunning,
                  gradient: _C.btnGrad,
                  onTap: startLoop,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildControlButton(
                  label: "STOP",
                  icon: Icons.stop_rounded,
                  enabled: isRunning,
                  gradient: LinearGradient(
                    colors: [
                      _C.primaryLt,
                      _C.primary,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  onTap: stopLoop,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required String label,
    required IconData icon,
    required bool enabled,
    required LinearGradient gradient,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 52,
        decoration: BoxDecoration(
          gradient: enabled ? gradient : null,
          color: enabled ? null : _C.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: enabled ? Colors.transparent : _C.border,
          ),
          boxShadow: enabled
              ? [
                  BoxShadow(
                      color: _C.primary.withOpacity(0.3),
                      blurRadius: 12,
                      offset: const Offset(0, 4))
                ]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: enabled ? Colors.white : _C.textDim, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: enabled ? Colors.white : _C.textDim,
                fontWeight: FontWeight.bold,
                fontFamily: kFont,
                fontSize: 14,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── STATUS CARD ────────────────────────────────────────────────────
  Widget _buildStatusCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: _C.btnGrad,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.info_outline_rounded,
                            color: Colors.white, size: 14),
                        const SizedBox(width: 6),
                        Text(
                          "STATUS LOG",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: kFont,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  // Stats live
                  if (counter > 0 || failedCount > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _C.border),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: isRunning ? _C.success : _C.textDim,
                              shape: BoxShape.circle,
                              boxShadow: isRunning
                                  ? [
                                      BoxShadow(
                                          color: _C.success
                                              .withOpacity(0.5),
                                          blurRadius: 6)
                                    ]
                                  : [],
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            isRunning ? 'RUNNING' : 'IDLE',
                            style: TextStyle(
                              color: isRunning
                                  ? _C.success
                                  : _C.textDim,
                              fontFamily: kFont,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),

              // Log box
              Container(
                constraints: const BoxConstraints(minHeight: 80),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.border),
                ),
                child: Text(
                  statusLog.isEmpty
                      ? "Menunggu perintah..."
                      : statusLog,
                  style: TextStyle(
                    color: statusLog.isEmpty
                        ? _C.textDim
                        : _getStatusColor(statusLog),
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    fontFamily: kFont,
                    height: 1.5,
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Counter row
              if (counter > 0 || failedCount > 0)
                Row(
                  children: [
                    Expanded(
                      child: _buildStatBox(
                        icon: Icons.send_rounded,
                        label: "Terkirim",
                        value: "$counter",
                        color: _C.success,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildStatBox(
                        icon: Icons.error_outline_rounded,
                        label: "Gagal",
                        value: "$failedCount",
                        color: _C.red,
                      ),
                    ),
                  ],
                ),

              if (counter > 0 || failedCount > 0)
                const SizedBox(height: 12),

              // Warning
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(10),
                  border:
                      Border.all(color: _C.primary.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.warning_amber_rounded,
                        color: _C.primaryLt, size: 16),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        "Auto send setiap 2 detik. Stop manual jika sudah cukup.",
                        style: TextStyle(
                          color: _C.textSub,
                          fontSize: 11,
                          fontFamily: kFont,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatBox({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: _C.textSub,
                  fontFamily: kFont,
                  fontSize: 10,
                  letterSpacing: 0.5,
                ),
              ),
              Text(
                value,
                style: TextStyle(
                  color: color,
                  fontFamily: kFont,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}