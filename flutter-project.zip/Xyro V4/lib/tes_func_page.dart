// tes_func_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'theme.dart';

const String kFont = 'Pek';
const String baseUrl = 'http://digital.mypanelku.web.id:2041';

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class TesFuncPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const TesFuncPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<TesFuncPage> createState() => _TesFuncPageState();
}

class _TesFuncPageState extends State<TesFuncPage> {
  final TextEditingController _funcController = TextEditingController();
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _delayController =
      TextEditingController(text: "1000");
  final TextEditingController _loopsController =
      TextEditingController(text: "1");

  bool _isSending = false;
  bool _isLoadingFile = false;
  String? _selectedFileName;
  String? _fileContent;
  List<Map<String, dynamic>> _history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyJson = prefs.getString('tes_func_history');
    if (historyJson != null) {
      final List<dynamic> historyList = jsonDecode(historyJson);
      setState(() {
        _history = historyList.cast<Map<String, dynamic>>();
      });
    }
  }

  Future<void> _saveToHistory(Map<String, dynamic> data) async {
    _history.insert(0, {
      ...data,
      'timestamp': DateTime.now().toIso8601String(),
    });

    if (_history.length > 10) {
      _history = _history.sublist(0, 10);
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tes_func_history', jsonEncode(_history));
  }

  Future<void> _pickJsFile() async {
    try {
      setState(() => _isLoadingFile = true);

      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['js'],
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        final path = file.path;

        if (path != null) {
          final fileData = File(path);
          final content = await fileData.readAsString();

          setState(() {
            _selectedFileName = file.name;
            _fileContent = content;
            _funcController.text = content;
          });

          _showSuccessDialog('File Loaded', 'Berhasil memuat: ${file.name}');
        }
      }
    } on PlatformException catch (e) {
      _showErrorDialog('Error', 'Gagal memuat file: ${e.message}');
    } catch (e) {
      _showErrorDialog('Error', 'Error: $e');
    } finally {
      setState(() => _isLoadingFile = false);
    }
  }

  String? _formatPhoneNumber(String phone) {
    String cleaned = phone.replaceAll(RegExp(r'[^\d+]'), '');

    if (cleaned.startsWith('08')) {
      return '62${cleaned.substring(1)}';
    } else if (cleaned.startsWith('0')) {
      return '62${cleaned.substring(1)}';
    } else if (cleaned.startsWith('62')) {
      return cleaned;
    } else if (cleaned.startsWith('+62')) {
      return cleaned.substring(1);
    }

    return cleaned.isNotEmpty ? cleaned : null;
  }

  // ✅ Cek sender aktif
  Future<bool> _hasSender() async {
    try {
      final res = await http.get(
        Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"),
      );
      if (res.statusCode != 200) return false;
      final data = jsonDecode(res.body);
      return data["valid"] == true &&
          data["connections"] != null &&
          (data["connections"] as List).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  // ✅ Kirim function via GET (bebas limit)
  Future<void> _sendFunction() async {
    final target = _formatPhoneNumber(_targetController.text.trim());
    final func = _funcController.text.trim();
    final delay = int.tryParse(_delayController.text.trim()) ?? 1000;
    final loops = int.tryParse(_loopsController.text.trim()) ?? 1;

    if (target == null || target.isEmpty) {
      _showErrorDialog('Target Required', 'Masukkan nomor target yang valid');
      return;
    }
    if (func.isEmpty) {
      _showErrorDialog('Function Required', 'Masukkan function atau pilih file .js');
      return;
    }

    final hasSender = await _hasSender();
    if (!hasSender) {
      _showErrorDialog(
        "Sender Required",
        "Please connect your sender device before sending function.",
      );
      return;
    }

    setState(() => _isSending = true);

    try {
      await _saveToHistory({
        'target': target,
        'function': func.substring(0, min(100, func.length)) +
            (func.length > 100 ? '...' : ''),
        'delay': delay,
        'loops': loops,
        'fileName': _selectedFileName,
      });

      // ✅ GET request dengan query params (bebas limit)
      final uri = Uri.parse("$baseUrl/test-function").replace(
        queryParameters: {
          'key': widget.sessionKey,
          'username': widget.username,
          'role': widget.role,
          'target': target,
          'delay': delay.toString(),
          'loops': loops.toString(),
        },
      );

      // Kirim function body via POST (karena bisa panjang)
      final response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'function': func}),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['success'] == true) {
          _showSuccessDialog(
            'Success',
            'Function berhasil dikirim!\n'
            'Role: ${data['role']}\n'
            'Target: ${data['target'] ?? target}\n'
            'Loops: ${data['loops'] ?? loops}\n'
            'Delay: ${data['delay'] ?? delay}ms',
          );
          _targetController.clear();
        } else {
          String errorMsg = data['message'] ?? 'Gagal mengirim function';
          if (data['cooldown'] == true) {
            errorMsg += '\nCooldown: ${data['wait']} detik';
          }
          _showErrorDialog('Failed', errorMsg);
        }
      } else {
        _showErrorDialog('Server Error',
            'Status: ${response.statusCode}\n${response.body}');
      }
    } on http.ClientException catch (e) {
      _showErrorDialog('Connection Error', 'Tidak dapat konek: $e');
    } on TimeoutException catch (_) {
      _showErrorDialog('Timeout', 'Koneksi timeout 30s');
    } catch (e) {
      _showErrorDialog('Error', 'Terjadi kesalahan: $e');
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showSuccessDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => _buildDialog(
        title,
        message,
        Icons.check_circle,
        AppColors.green,
      ),
    );
  }

  void _showErrorDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => _buildDialog(
        title,
        message,
        Icons.error,
        AppColors.red,
      ),
    );
  }

  Widget _buildDialog(String title, String message, IconData icon, Color color) {
    final isComic = ThemeModeManager.isComic3d;
    return Dialog(
      backgroundColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(isComic ? 6 : 20),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: isComic ? null : AppColors.glassGrad,
          color: isComic ? AppColors.card : null,
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          border: Border.all(
            color: color.withOpacity(0.5),
            width: isComic ? 3 : 1.5,
          ),
          boxShadow: AppColors.glassShadow,
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [color, color.withOpacity(0.7)],
                ),
                border: isComic
                    ? Border.all(color: AppColors.border, width: 3)
                    : null,
              ),
              child: Icon(icon, color: _onAccent(), size: 30),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              style: TextStyle(
                color: AppColors.text,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: kFont,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 13,
                height: 1.5,
                fontFamily: kFont,
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: color,
                  foregroundColor: _onAccent(),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text('OK',
                    style: TextStyle(
                      fontFamily: kFont,
                      fontWeight: FontWeight.w700,
                    )),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _clearFields() {
    _funcController.clear();
    _targetController.clear();
    _delayController.text = "1000";
    _loopsController.text = "1";
    setState(() {
      _selectedFileName = null;
      _fileContent = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        final isComic = ThemeModeManager.isComic3d;

        return Scaffold(
          backgroundColor: AppColors.bg,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: false,
            title: Text(
              'TES FUNC',
              style: TextStyle(
                color: AppColors.text,
                fontWeight: FontWeight.bold,
                fontSize: 20,
                fontFamily: kFont,
                letterSpacing: 1.5,
              ),
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.history,
                    color: AppColors.accent),
                onPressed: _showHistoryDialog,
              ),
            ],
          ),
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(isComic),
                  const SizedBox(height: 30),

                  _buildInputField(
                    label: 'Nomor Target',
                    hint: '62xxx (contoh: 6281234567890)',
                    controller: _targetController,
                    icon: Icons.phone,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9+]')),
                    ],
                  ),

                  const SizedBox(height: 20),

                  _buildFunctionInput(isComic),

                  const SizedBox(height: 30),

                  Row(
                    children: [
                      Expanded(
                        child: _buildNumberInput(
                          label: 'Delay (ms)',
                          hint: '1000',
                          controller: _delayController,
                          icon: Icons.timer,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildNumberInput(
                          label: 'Loops',
                          hint: '1',
                          controller: _loopsController,
                          icon: Icons.repeat,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 40),

                  _buildActionButtons(isComic),

                  const SizedBox(height: 30),

                  _buildInfoPanel(isComic),

                  const SizedBox(height: 50),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader(bool isComic) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: isComic
            ? null
            : LinearGradient(
                colors: [
                  AppColors.accent.withOpacity(0.2),
                  AppColors.accentLight.withOpacity(0.1),
                ],
              ),
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: isComic ? AppColors.border : AppColors.accent.withOpacity(0.3),
          width: AppColors.borderWidth,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: AppColors.btnGrad,
              border: isComic
                  ? Border.all(color: AppColors.border, width: 3)
                  : null,
            ),
            child: Icon(Icons.code,
                color: _onAccent(), size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Test Function',
                  style: TextStyle(
                    color: AppColors.text,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: kFont,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Kirim function custom dengan delay & loops',
                  style: TextStyle(
                    color: AppColors.textSub,
                    fontSize: 11,
                    fontFamily: kFont,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFunctionInput(bool isComic) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Function / Message',
              style: TextStyle(
                color: AppColors.text,
                fontSize: 14,
                fontWeight: FontWeight.w600,
                fontFamily: kFont,
              ),
            ),
            const Spacer(),
            if (_selectedFileName != null)
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(isComic ? 3 : 12),
                  border: Border.all(
                      color: AppColors.accent.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.insert_drive_file,
                        size: 14, color: AppColors.accent),
                    const SizedBox(width: 6),
                    Text(
                      _selectedFileName!,
                      style: TextStyle(
                          color: AppColors.accent,
                          fontSize: 11,
                          fontFamily: kFont),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(
                isComic ? 4 : 12),
            border: Border.all(
              color: AppColors.border,
              width: AppColors.borderWidth,
            ),
          ),
          child: TextField(
            controller: _funcController,
            maxLines: 8,
            style: TextStyle(
                color: AppColors.text,
                fontSize: 13,
                fontFamily: kFont),
            decoration: InputDecoration(
              hintText: 'Paste function atau message di sini...',
              hintStyle: TextStyle(
                  color: AppColors.textHint,
                  fontFamily: kFont),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: _isLoadingFile ? null : _pickJsFile,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.accent.withOpacity(0.2),
                  foregroundColor: AppColors.accent,
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(isComic ? 4 : 10),
                    side: BorderSide(
                        color: AppColors.accent.withOpacity(0.3)),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                icon: _isLoadingFile
                    ? SizedBox(
                        width: 16, height: 16,
                        child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppColors.accent),
                      )
                    : const Icon(Icons.upload_file, size: 18),
                label: Text(
                  _isLoadingFile ? 'Loading...' : 'Pilih File .js',
                  style: TextStyle(fontFamily: kFont),
                ),
              ),
            ),
            const SizedBox(width: 12),
            ElevatedButton.icon(
              onPressed: () {
                _funcController.clear();
                setState(() {
                  _selectedFileName = null;
                  _fileContent = null;
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.red.withOpacity(0.15),
                foregroundColor: AppColors.red,
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(isComic ? 4 : 10),
                  side: BorderSide(
                      color: AppColors.red.withOpacity(0.3)),
                ),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              icon: const Icon(Icons.clear, size: 18),
              label: Text('Clear',
                  style: TextStyle(fontFamily: kFont)),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInputField({
    required String label,
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: AppColors.text,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: kFont,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            border: Border.all(
              color: AppColors.border,
              width: AppColors.borderWidth,
            ),
          ),
          child: TextField(
            controller: controller,
            keyboardType: keyboardType ?? TextInputType.text,
            inputFormatters: inputFormatters,
            style: TextStyle(
                color: AppColors.text,
                fontSize: 14,
                fontFamily: kFont),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                  color: AppColors.textHint,
                  fontFamily: kFont),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
              prefixIcon: Icon(icon, color: AppColors.accent),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildNumberInput({
    required String label,
    required String hint,
    required TextEditingController controller,
    required IconData icon,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: AppColors.text,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: kFont,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            border: Border.all(
              color: AppColors.border,
              width: AppColors.borderWidth,
            ),
          ),
          child: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            style: TextStyle(
                color: AppColors.text,
                fontSize: 14,
                fontFamily: kFont),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                  color: AppColors.textHint,
                  fontFamily: kFont),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
              prefixIcon: Icon(icon, color: AppColors.accent),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons(bool isComic) {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: _isSending ? null : _sendFunction,
            style: ElevatedButton.styleFrom(
              backgroundColor: _isSending
                  ? AppColors.accent.withOpacity(0.5)
                  : AppColors.accent,
              foregroundColor: _onAccent(),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                side: isComic
                    ? BorderSide(
                        color: AppColors.border, width: 3)
                    : BorderSide.none,
              ),
              padding: const EdgeInsets.symmetric(vertical: 16),
              elevation: isComic ? 0 : 5,
              shadowColor: AppColors.accent.withOpacity(0.5),
            ),
            icon: _isSending
                ? SizedBox(
                    width: 20, height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: _onAccent(),
                    ),
                  )
                : const Icon(Icons.send_rounded, size: 20),
            label: Text(
              _isSending ? 'SENDING...' : 'KIRIM FUNCTION',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 14,
                letterSpacing: 0.5,
                fontFamily: kFont,
              ),
            ),
          ),
        ),
        const SizedBox(width: 16),
        SizedBox(
          width: 60, height: 56,
          child: ElevatedButton(
            onPressed: _clearFields,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.red.withOpacity(0.15),
              foregroundColor: AppColors.red,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                side: BorderSide(
                  color: AppColors.red.withOpacity(0.3),
                  width: AppColors.borderWidth,
                ),
              ),
              padding: EdgeInsets.zero,
            ),
            child: const Icon(Icons.refresh, size: 24),
          ),
        ),
      ],
    );
  }

  Widget _buildInfoPanel(bool isComic) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: AppColors.border,
          width: AppColors.borderWidth,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline,
                  color: AppColors.accent, size: 20),
              const SizedBox(width: 10),
              Text(
                'Informasi',
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: kFont,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '• Gunakan format nomor internasional (62xxx)\n'
            '• File .js akan dibaca sebagai plain text\n'
            '• Delay dalam milidetik (ms)\n'
            '• Loops menentukan jumlah pengiriman\n'
            '• Function akan dikirim sebagai payload',
            style: TextStyle(
              color: AppColors.textSub,
              fontSize: 12,
              height: 1.6,
              fontFamily: kFont,
            ),
          ),
        ],
      ),
    );
  }

  void _showHistoryDialog() {
    final isComic = ThemeModeManager.isComic3d;
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
        ),
        child: Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.7,
          ),
          decoration: BoxDecoration(
            gradient: isComic ? null : AppColors.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(isComic ? 6 : 20),
            border: Border.all(
              color: AppColors.accent.withOpacity(0.4),
              width: isComic ? 3 : 1.5,
            ),
            boxShadow: AppColors.glassShadow,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Icon(Icons.history,
                        color: AppColors.accent, size: 24),
                    const SizedBox(width: 12),
                    Text(
                      'Riwayat Tes Func',
                      style: TextStyle(
                        color: AppColors.text,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        fontFamily: kFont,
                      ),
                    ),
                  ],
                ),
              ),
              if (_history.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(40),
                  child: Column(
                    children: [
                      Icon(Icons.history_toggle_off,
                          color: AppColors.textHint, size: 60),
                      const SizedBox(height: 20),
                      Text(
                        'Belum ada riwayat',
                        style: TextStyle(
                          color: AppColors.textSub,
                          fontSize: 14,
                          fontFamily: kFont,
                        ),
                      ),
                    ],
                  ),
                )
              else
                Expanded(
                  child: ListView.builder(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 20),
                    itemCount: _history.length,
                    itemBuilder: (context, index) {
                      final item = _history[index];
                      final timestamp =
                          DateTime.parse(item['timestamp']);

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.dark,
                          borderRadius: BorderRadius.circular(
                              isComic ? 4 : 12),
                          border: Border.all(
                            color: AppColors.border,
                            width: AppColors.borderWidth,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  item['target'],
                                  style: TextStyle(
                                    color: AppColors.text,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                    fontFamily: kFont,
                                  ),
                                ),
                                const Spacer(),
                                Text(
                                  '${item['delay']}ms',
                                  style: TextStyle(
                                    color: AppColors.accent,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: kFont,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: AppColors.accent
                                        .withOpacity(0.2),
                                    borderRadius:
                                        BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    '${item['loops']}x',
                                    style: TextStyle(
                                      color: AppColors.accent,
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: kFont,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              item['function'],
                              style: TextStyle(
                                color: AppColors.textSub,
                                fontSize: 12,
                                fontFamily: kFont,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Spacer(),
                                Text(
                                  '${timestamp.hour.toString().padLeft(2, '0')}:${timestamp.minute.toString().padLeft(2, '0')}',
                                  style: TextStyle(
                                    color: AppColors.textHint,
                                    fontSize: 11,
                                    fontFamily: kFont,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      foregroundColor: _onAccent(),
                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(isComic ? 4 : 12),
                      ),
                      padding:
                          const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text('TUTUP',
                        style: TextStyle(
                          fontFamily: kFont,
                          fontWeight: FontWeight.w700,
                        )),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}