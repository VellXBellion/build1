// home_page.dart
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

import 'theme.dart';   // ← SISTEM TEMA

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE (alias ke AppColors dinamis) ──────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;

  static Color get primary      => AppColors.accent;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark  => AppColors.accentDark;
  static Color get primaryGlow  => AppColors.accentMid;

  static Color get secondary => AppColors.accent;
  static Color get accent    => AppColors.accentLight;
  static Color get success   => AppColors.green;
  static Color get warning   => AppColors.amber;
  static Color get error     => AppColors.red;
  static Color get pink      => AppColors.pink;
  static Color get orange    => AppColors.amber;
  static Color get purple    => AppColors.purple;

  static Color get text     => AppColors.text;
  static Color get textSub  => AppColors.textSub;
  static Color get textDim  => AppColors.textHint;
  static Color get textDark => AppColors.textHint;

  static Color get white     => AppColors.text;
  static Color get whiteSoft => AppColors.textSub;
  static Color get whiteDim  => AppColors.textSub;

  static Color get black     => AppColors.bg;
  static Color get blackSoft => AppColors.dark;

  static Color get glassBg     => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static LinearGradient get btnGrad => AppColors.btnGrad;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ────────────────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ─── BASE URL ──────────────────────────────────────────────────────────
const String baseUrl = "http://digital.mypanelku.web.id:2041";

// ─── GLASS CARD (ikut tema) ────────────────────────────────────────────
BoxDecoration glassCard3D({Color? borderColor, bool active = false}) {
  final isComic = ThemeModeManager.isComic3d;

  if (isComic) {
    return BoxDecoration(
      color: AppColors.card,
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      border: Border.all(
        color: borderColor ?? AppColors.border,
        width: 3,
      ),
      boxShadow: AppColors.glassShadow,
    );
  }

  return BoxDecoration(
    color: _C.glassBg,
    borderRadius: BorderRadius.circular(AppColors.cardRadius),
    border: Border.all(
      color: active ? (borderColor ?? _C.primary.withOpacity(0.3)) : _C.glassBorder,
      width: active ? 1.5 : 0.8,
    ),
    boxShadow: [
      BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30, offset: const Offset(0, 10)),
      BoxShadow(color: Colors.white.withOpacity(0.02), blurRadius: 60, offset: const Offset(0, -4)),
    ],
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Colors.white.withOpacity(0.06),
        Colors.white.withOpacity(0.01),
        Colors.white.withOpacity(0.03),
      ],
    ),
  );
}

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final linkGroupController = TextEditingController();

  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;

  late AnimationController _buttonController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _glowController;

  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _glowAnimation;

  String selectedBugId = "";
  bool _isSending = false;
  bool _isSuccess = false;
  String? _lastTarget;
  int _activeStep = 0;

  String _targetMode = "number";
  String _senderType = "private";

  int _totalSenders = 0;
  bool _isLoadingSenders = false;

  late PageController _carouselController;
  int _currentPage = 0;

  bool get _canAccessGlobal {
    final role = widget.role.toLowerCase();
    return role == 'owner' || role == 'vip' || role == 'admin';
  }

  bool get _canUseGlobal => _canAccessGlobal && _targetMode == "number";

  List<Map<String, dynamic>> get _filteredBugs {
    if (_senderType == "global") {
      return widget.listBug.where((bug) {
        final type = bug['type']?.toString().toLowerCase() ?? '';
        return type == "global";
      }).toList();
    }
    if (_targetMode == "number") {
      return widget.listBug.where((bug) {
        final type = bug['type']?.toString().toLowerCase() ?? 'private';
        return type == "private" || type == "both";
      }).toList();
    }
    if (_targetMode == "group") {
      return widget.listBug.where((bug) {
        final type = bug['type']?.toString().toLowerCase() ?? '';
        return type == "group";
      }).toList();
    }
    return [];
  }

  @override
  void initState() {
    super.initState();
    _initializeVideo();
    _initializeAnimations();
    _startAnimations();
    _carouselController = PageController(viewportFraction: 0.82);

    final filtered = _filteredBugs;
    if (filtered.isNotEmpty) {
      selectedBugId = filtered[0]['bug_id'];
    }
    _loadTotalSenders();
  }

  void _initializeVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/1.mp4')
      ..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
          _videoController.setLooping(true);
          _videoController.setVolume(1.0);
          _videoController.play();
        });
      }).catchError((_) {
        setState(() => _isVideoInitialized = false);
      });
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(vsync: this, duration: const Duration(milliseconds: 150));
    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _slideController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000));
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.97)
        .animate(CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut));
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _fadeController, curve: Curves.easeIn));
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
    _glowAnimation = Tween<double>(begin: 0.3, end: 0.8)
        .animate(CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  Future<void> _loadTotalSenders() async {
    if (!_canAccessGlobal) return;
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/getActiveSenders?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        final senders = List<String>.from(data['senders']);
        setState(() => _totalSenders = senders.length);
      } else {
        setState(() => _totalSenders = 0);
      }
    } catch (_) {
      setState(() => _totalSenders = 0);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    if (_isSending) return;
    setState(() { _isSending = true; _activeStep = 1; });
    _buttonController.forward().then((_) => _buttonController.reverse());

    final key = widget.sessionKey;

    if (_targetMode == "number") {
      final rawInput = targetController.text.trim();
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("INVALID NUMBER", "Use international format, not 08xxx.");
        setState(() { _isSending = false; _activeStep = 0; });
        return;
      }
      await _executeSendBug(target);
    } else {
      final linkGroup = linkGroupController.text.trim();
      if (!isValidGroupLink(linkGroup) || key.isEmpty) {
        _showAlert("INVALID LINK", "Masukkan link grup WA yang valid.");
        setState(() { _isSending = false; _activeStep = 0; });
        return;
      }
      await _executeSendBug(linkGroup);
    }
  }

  Future<void> _executeSendBug(String target) async {
    if (selectedBugId.isEmpty) {
      _showAlert("NO BUG SELECTED", "Please select a bug type first.");
      setState(() { _isSending = false; _activeStep = 0; });
      return;
    }

    try {
      final url = "$baseUrl/sendBug?key=${widget.sessionKey}&target=$target&bug=$selectedBugId&senderMode=$_senderType";
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 30));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("COOLDOWN", "Wait ${data['wait'] ?? 'a few'} seconds.");
      } else if (data["valid"] == false) {
        _showAlert("INVALID SESSION", "Session key invalid. Please login again.");
      } else if (data["sended"] == false) {
        _showAlert("ERROR", "Failed to send. ${data['message'] ?? 'Try again.'}");
      } else {
        setState(() { _activeStep = 2; _isSuccess = true; _lastTarget = target; });
        _showSuccessDialog(target);
      }
    } catch (e) {
      _showAlert("ERROR", "Terjadi kesalahan: $e");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showSuccessDialog(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (context) => _SuccessDialog(
        target: target,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() { _isSuccess = false; _activeStep = 0; });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          side: BorderSide(
            color: _C.primary.withOpacity(0.3),
            width: AppColors.borderWidth,
          ),
        ),
        title: Text(title,
            style: TextStyle(color: _C.primary, fontSize: 14, fontFamily: kFont)),
        content: Text(msg,
            style: TextStyle(color: _C.textSub, fontFamily: kFont)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK",
                style: TextStyle(color: _C.primary, fontFamily: kFont)),
          )
        ],
      ),
    );
  }

  Widget _buildGlassContainer({
    required Widget child,
    bool active = false,
    Color? borderColor,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 10,
          sigmaY: isComic ? 0 : 10,
        ),
        child: Container(
          padding: padding,
          decoration: glassCard3D(borderColor: borderColor, active: active),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ⚡ AUTO REBUILD SAAT TEMA GANTI
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        final filteredBugs = _filteredBugs;
        return Scaffold(
          backgroundColor: _C.bg,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: FadeTransition(
                    opacity: _fadeAnimation,
                    child: SlideTransition(
                      position: _slideAnimation,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          _buildHeader(),
                          const SizedBox(height: 16),
                          _buildVideoBanner(),
                          const SizedBox(height: 20),
                          _buildModeSelector(),
                          const SizedBox(height: 16),
                          _buildTargetCard(),
                          const SizedBox(height: 24),
                          if (filteredBugs.isEmpty)
                            _buildEmptyBug()
                          else
                            _buildBugCarousel(),
                          const SizedBox(height: 16),
                          if (filteredBugs.length > 1) _buildPageIndicator(),
                          const SizedBox(height: 16),
                          if (_canAccessGlobal) _buildSenderType(),
                          const SizedBox(height: 24),
                          _buildActionButtons(),
                          const SizedBox(height: 16),
                          _buildFooter(),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    return _buildGlassContainer(
      active: true,
      borderColor: _C.primary.withOpacity(0.2),
      child: Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              gradient: _C.btnGrad,
              shape: BoxShape.circle,
              border: ThemeModeManager.isComic3d
                  ? Border.all(color: AppColors.border, width: 2)
                  : null,
              boxShadow: ThemeModeManager.isComic3d
                  ? null
                  : [BoxShadow(color: _C.primary.withOpacity(0.3), blurRadius: 12)],
            ),
            child: Icon(FontAwesomeIcons.userSecret,
                color: _onAccent(), size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.username,
                    style: TextStyle(
                        color: _C.text, fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: kFont, letterSpacing: 1)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _C.primary.withOpacity(
                            ThemeModeManager.isComic3d ? 0.3 : 0.15),
                        borderRadius: BorderRadius.circular(
                            ThemeModeManager.isComic3d ? 4 : 20),
                        border: Border.all(
                            color: _C.primary.withOpacity(0.5),
                            width: ThemeModeManager.isComic3d ? 2 : 1),
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: TextStyle(
                          color: ThemeModeManager.isComic3d
                              ? const Color(0xFF1A1A1A) : _C.primary,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          fontFamily: kFont,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: _C.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Icon(FontAwesomeIcons.calendarAlt,
                              color: _C.primary, size: 10),
                          const SizedBox(width: 4),
                          Text(widget.expiredDate,
                              style: TextStyle(
                                  color: _C.primary,
                                  fontSize: 9,
                                  fontFamily: kFont)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: _C.primary.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(
                color: _C.primary.withOpacity(0.3),
                width: AppColors.borderWidth,
              ),
            ),
            child: Icon(FontAwesomeIcons.shieldHalved,
                color: _C.primary, size: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoBanner() {
    return _buildGlassContainer(
      active: true,
      borderColor: _C.primary.withOpacity(0.2),
      padding: EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: Container(
          width: double.infinity,
          height: 200,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _C.primary.withOpacity(0.3),
              width: AppColors.borderWidth,
            ),
            boxShadow: ThemeModeManager.isComic3d
                ? null
                : [BoxShadow(color: _C.primary.withOpacity(0.15), blurRadius: 20)],
          ),
          child: _isVideoInitialized
              ? FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                )
              : Container(
                  color: _C.cardAlt,
                  child: Center(
                    child: CircularProgressIndicator(
                      color: _C.primary,
                      strokeWidth: 2,
                    ),
                  ),
                ),
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return _buildGlassContainer(
      active: true,
      borderColor: _C.primary.withOpacity(0.15),
      padding: const EdgeInsets.all(4),
      child: Row(
        children: [
          Expanded(
            child: _buildModeTab(
              icon: FontAwesomeIcons.phone,
              label: "NUMBER",
              isActive: _targetMode == "number",
              onTap: () {
                setState(() {
                  _targetMode = "number";
                  _senderType = "private";
                  targetController.clear();
                  linkGroupController.clear();
                  final filtered = _filteredBugs;
                  if (filtered.isNotEmpty) {
                    selectedBugId = filtered[0]['bug_id'];
                    _currentPage = 0;
                    _carouselController.jumpToPage(0);
                  }
                });
              },
            ),
          ),
          Expanded(
            child: _buildModeTab(
              icon: FontAwesomeIcons.users,
              label: "GROUP",
              isActive: _targetMode == "group",
              onTap: () {
                setState(() {
                  _targetMode = "group";
                  _senderType = "private";
                  targetController.clear();
                  linkGroupController.clear();
                  final filtered = _filteredBugs;
                  if (filtered.isNotEmpty) {
                    selectedBugId = filtered[0]['bug_id'];
                    _currentPage = 0;
                    _carouselController.jumpToPage(0);
                  }
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeTab({
    required IconData icon,
    required String label,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isActive
              ? _C.primary.withOpacity(isComic ? 0.3 : 0.15)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(isComic ? 4 : 12),
          border: Border.all(
            color: isActive ? _C.primary : Colors.transparent,
            width: isComic ? 2 : 1.5,
          ),
          boxShadow: isActive && !isComic
              ? [BoxShadow(color: _C.primary.withOpacity(0.2), blurRadius: 8)]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: isActive
                    ? (isComic ? const Color(0xFF1A1A1A) : _C.primary)
                    : _C.textDim,
                size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isActive
                    ? (isComic ? const Color(0xFF1A1A1A) : _C.primary)
                    : _C.textDim,
                fontSize: 13,
                fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                fontFamily: kFont,
                letterSpacing: 1,
              ),
            ),
            if (isActive) ...[
              const SizedBox(width: 6),
              Container(
                width: 6, height: 6,
                decoration: BoxDecoration(
                  color: _C.success,
                  shape: BoxShape.circle,
                  boxShadow: isComic
                      ? null
                      : [BoxShadow(color: _C.success.withOpacity(0.6), blurRadius: 4)],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTargetCard() {
    return _buildGlassContainer(
      active: true,
      borderColor: _C.primary.withOpacity(0.15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(
                      ThemeModeManager.isComic3d ? 4 : 12),
                ),
                child: Icon(
                  _targetMode == "number" ? Icons.my_location : Icons.group,
                  color: _C.primary,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  "TARGET SPECIFICATION",
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: kFont,
                    letterSpacing: 1,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.success.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(
                      ThemeModeManager.isComic3d ? 4 : 20),
                  border: Border.all(
                    color: _C.success.withOpacity(0.3),
                    width: AppColors.borderWidth,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6, height: 6,
                      decoration: BoxDecoration(
                        color: _C.success,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "READY",
                      style: TextStyle(
                        color: _C.success,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        fontFamily: kFont,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildInputField(),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(FontAwesomeIcons.circleInfo, color: _C.textDim, size: 10),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  _targetMode == "number"
                      ? "International format without + or 0"
                      : "WhatsApp group invite link",
                  style: TextStyle(color: _C.textDim, fontSize: 10, fontFamily: kFont),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInputField() {
    final isComic = ThemeModeManager.isComic3d;
    final r = isComic ? 6.0 : 16.0;

    if (_targetMode == "number") {
      return Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(r),
          border: Border.all(
            color: _C.primary.withOpacity(0.2),
            width: AppColors.borderWidth,
          ),
        ),
        child: TextField(
          controller: targetController,
          style: TextStyle(color: _C.text, fontSize: 16, fontFamily: kFont),
          cursorColor: _C.primary,
          keyboardType: TextInputType.phone,
          decoration: InputDecoration(
            hintText: "628123456789",
            hintStyle: TextStyle(color: _C.textDim, fontFamily: kFont),
            prefixIcon: Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _C.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(isComic ? 3 : 8),
              ),
              child: Icon(FontAwesomeIcons.phone, color: _C.primary, size: 16),
            ),
            suffixIcon: _lastTarget != null && targetController.text == _lastTarget
                ? Container(
                    margin: const EdgeInsets.all(8),
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      color: _C.success.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: _C.success.withOpacity(0.3),
                        width: AppColors.borderWidth,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle, color: _C.success, size: 14),
                        const SizedBox(width: 4),
                        Text("Verified",
                            style: TextStyle(
                                color: _C.success,
                                fontSize: 10,
                                fontFamily: kFont)),
                      ],
                    ),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
      );
    } else {
      return Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(r),
          border: Border.all(
            color: _C.primary.withOpacity(0.2),
            width: AppColors.borderWidth,
          ),
        ),
        child: TextField(
          controller: linkGroupController,
          style: TextStyle(color: _C.text, fontSize: 14, fontFamily: kFont),
          cursorColor: _C.primary,
          keyboardType: TextInputType.url,
          decoration: InputDecoration(
            hintText: "https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: _C.textDim, fontFamily: kFont),
            prefixIcon: Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _C.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(isComic ? 3 : 8),
              ),
              child: Icon(FontAwesomeIcons.link, color: _C.primary, size: 16),
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
      );
    }
  }

  Widget _buildEmptyBug() {
    return _buildGlassContainer(
      active: true,
      borderColor: _C.border,
      padding: const EdgeInsets.all(40),
      child: Column(
        children: [
          Icon(Icons.bug_report, color: _C.textDim, size: 40),
          const SizedBox(height: 12),
          Text(
            "Tidak ada bug untuk mode ${_targetMode == 'number' ? 'NOMOR' : 'GROUP'}",
            style: TextStyle(color: _C.textDim, fontSize: 14, fontFamily: kFont),
          ),
        ],
      ),
    );
  }

  Widget _buildBugCarousel() {
    final filteredBugs = _filteredBugs;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(
                      ThemeModeManager.isComic3d ? 3 : 8),
                ),
                child: Icon(Icons.view_carousel, color: _C.primary, size: 14),
              ),
              const SizedBox(width: 8),
              Text(
                "SELECT PAYLOAD",
                style: TextStyle(
                  color: _C.text,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  fontFamily: kFont,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  "${_currentPage + 1}/${filteredBugs.length}",
                  style: TextStyle(color: _C.primary, fontSize: 10, fontFamily: kFont),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: _carouselController,
            onPageChanged: (int page) {
              setState(() {
                _currentPage = page;
                if (filteredBugs.isNotEmpty && page < filteredBugs.length) {
                  selectedBugId = filteredBugs[page]['bug_id'];
                }
              });
            },
            itemCount: filteredBugs.length,
            itemBuilder: (context, index) {
              final bug = filteredBugs[index];
              final bugId = bug['bug_id'];
              final bugName = bug['bug_name'];
              final isSelected = selectedBugId == bugId;
              return _buildCarouselBugCard(bugId, bugName, isSelected, index);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCarouselBugCard(String bugId, String bugName, bool isSelected, int index) {
    final isComic = ThemeModeManager.isComic3d;
    return AnimatedBuilder(
      animation: _carouselController,
      builder: (context, child) {
        double scaleValue = 1.0;
        if (_carouselController.position.haveDimensions) {
          double pageOffset = (_carouselController.page! - index).abs();
          scaleValue = 1.0 - (pageOffset * 0.15);
          scaleValue = scaleValue.clamp(0.85, 1.0);
        }

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Transform.scale(
            scale: scaleValue,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              child: BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: isComic ? 0 : 8,
                  sigmaY: isComic ? 0 : 8,
                ),
                child: GestureDetector(
                  onTap: () {
                    setState(() => selectedBugId = bugId);
                    _carouselController.animateToPage(
                      index,
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.elasticOut,
                    );
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    curve: Curves.elasticOut,
                    decoration: BoxDecoration(
                      gradient: isComic
                          ? null
                          : LinearGradient(
                              colors: isSelected
                                  ? [_C.primary.withOpacity(0.15), _C.cardAlt]
                                  : [_C.card, _C.cardAlt],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                      color: isComic
                          ? (isSelected
                              ? _C.primary.withOpacity(0.25)
                              : _C.card)
                          : null,
                      borderRadius: BorderRadius.circular(AppColors.cardRadius),
                      border: Border.all(
                        color: isSelected ? _C.primary : _C.border,
                        width: isSelected
                            ? (isComic ? 3 : 1.5)
                            : AppColors.borderWidth,
                      ),
                      boxShadow: isComic
                          ? AppColors.softShadow
                          : (isSelected
                              ? [BoxShadow(
                                  color: _C.primary.withOpacity(0.3),
                                  blurRadius: 12)]
                              : null),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          bottom: -10, right: -10,
                          child: Icon(
                            FontAwesomeIcons.bug,
                            color: isSelected
                                ? _C.primary.withOpacity(0.2)
                                : _C.textDim.withOpacity(0.1),
                            size: 50,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: isSelected
                                          ? _C.primary.withOpacity(0.2)
                                          : _C.surface,
                                      borderRadius: BorderRadius.circular(
                                          isComic ? 3 : 10),
                                    ),
                                    child: Icon(
                                      FontAwesomeIcons.bug,
                                      color: isSelected ? _C.primary : _C.textDim,
                                      size: 18,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: isSelected
                                          ? _C.primary.withOpacity(0.15)
                                          : _C.surface,
                                      borderRadius: BorderRadius.circular(
                                          isComic ? 3 : 8),
                                    ),
                                    child: Text(
                                      "#${(index + 1).toString().padLeft(2, '0')}",
                                      style: TextStyle(
                                        color: isSelected ? _C.primary : _C.textDim,
                                        fontSize: 9,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: kFont,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Text(
                                bugName,
                                style: TextStyle(
                                  color: isSelected ? _C.primary : _C.text,
                                  fontSize: 13,
                                  fontWeight: isSelected
                                      ? FontWeight.bold
                                      : FontWeight.w500,
                                  fontFamily: kFont,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              Text("Payload",
                                  style: TextStyle(
                                      color: _C.textDim,
                                      fontSize: 9,
                                      fontFamily: kFont)),
                            ],
                          ),
                        ),
                        if (isSelected)
                          Positioned(
                            top: 8, right: 8,
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: _C.success,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(Icons.check, color: _C.bg, size: 10),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildPageIndicator() {
    final filteredBugs = _filteredBugs;
    if (filteredBugs.length <= 1) return const SizedBox.shrink();

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        filteredBugs.length,
        (index) => AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: _currentPage == index ? 24 : 6,
          height: 4,
          decoration: BoxDecoration(
            color: _currentPage == index ? _C.primary : _C.border,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),
    );
  }

  Widget _buildSenderType() {
    if (!_canAccessGlobal) return const SizedBox.shrink();
    final isComic = ThemeModeManager.isComic3d;

    return _buildGlassContainer(
      active: true,
      borderColor: _C.primary.withOpacity(0.15),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(FontAwesomeIcons.server, color: _C.primary, size: 14),
              const SizedBox(width: 8),
              Text(
                "SENDER TYPE",
                style: TextStyle(
                  color: _C.text,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  fontFamily: kFont,
                  letterSpacing: 1,
                ),
              ),
              if (_isLoadingSenders) ...[
                const Spacer(),
                SizedBox(
                  width: 16, height: 16,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: _C.primary),
                ),
              ],
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _senderType = "private";
                      _currentPage = 0;
                      _carouselController.jumpToPage(0);
                      final filtered = _filteredBugs;
                      if (filtered.isNotEmpty) {
                        selectedBugId = filtered[0]['bug_id'];
                      }
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: _senderType == "private"
                          ? _C.primary.withOpacity(isComic ? 0.3 : 0.15)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                      border: Border.all(
                        color: _senderType == "private" ? _C.primary : _C.border,
                        width: _senderType == "private"
                            ? (isComic ? 3 : 1.5)
                            : AppColors.borderWidth,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.lock_rounded,
                                color: _senderType == "private"
                                    ? _C.primary
                                    : _C.textDim,
                                size: 14),
                            const SizedBox(width: 6),
                            Text("PRIVATE",
                                style: TextStyle(
                                  color: _senderType == "private"
                                      ? _C.primary
                                      : _C.textDim,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: kFont,
                                )),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text("My Sender",
                            style: TextStyle(
                              color: _senderType == "private"
                                  ? _C.primary
                                  : _C.textDim,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              fontFamily: kFont,
                            )),
                        if (_senderType == "private") ...[
                          const SizedBox(height: 4),
                          Container(
                            width: 20, height: 3,
                            decoration: BoxDecoration(
                              color: _C.success,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GestureDetector(
                  onTap: _canUseGlobal
                      ? () {
                          setState(() {
                            _senderType = "global";
                            _currentPage = 0;
                            _carouselController.jumpToPage(0);
                            final filtered = _filteredBugs;
                            if (filtered.isNotEmpty) {
                              selectedBugId = filtered[0]['bug_id'];
                            }
                          });
                        }
                      : null,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: _senderType == "global" && _canUseGlobal
                          ? _C.primary.withOpacity(isComic ? 0.3 : 0.15)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                      border: Border.all(
                        color: _senderType == "global" && _canUseGlobal
                            ? _C.primary
                            : _C.border,
                        width: _senderType == "global" && _canUseGlobal
                            ? (isComic ? 3 : 1.5)
                            : AppColors.borderWidth,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              _canUseGlobal
                                  ? FontAwesomeIcons.globe
                                  : Icons.lock_rounded,
                              color: _senderType == "global" && _canUseGlobal
                                  ? _C.primary
                                  : _C.textDim,
                              size: 14,
                            ),
                            const SizedBox(width: 6),
                            Text("GLOBAL",
                                style: TextStyle(
                                  color: _senderType == "global" && _canUseGlobal
                                      ? _C.primary
                                      : _C.textDim,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: kFont,
                                )),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _canUseGlobal ? "$_totalSenders sender" : "Locked",
                          style: TextStyle(
                            color: _senderType == "global" && _canUseGlobal
                                ? _C.primary
                                : _C.textDim,
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            fontFamily: kFont,
                          ),
                        ),
                        if (_senderType == "global" && _canUseGlobal) ...[
                          const SizedBox(height: 4),
                          Container(
                            width: 20, height: 3,
                            decoration: BoxDecoration(
                              color: _C.success,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    final isComic = ThemeModeManager.isComic3d;

    return Column(
      children: [
        AnimatedBuilder(
          animation: _scaleAnimation,
          builder: (context, child) {
            return Transform.scale(
              scale: _scaleAnimation.value,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: isComic ? 0 : 8,
                    sigmaY: isComic ? 0 : 8,
                  ),
                  child: Container(
                    width: double.infinity, height: 60,
                    decoration: BoxDecoration(
                      gradient: _isSending ? null : _C.btnGrad,
                      color: _isSending ? _C.textDim : null,
                      borderRadius: BorderRadius.circular(30),
                      border: isComic
                          ? Border.all(color: AppColors.border, width: 3)
                          : null,
                      boxShadow: isComic
                          ? AppColors.glassShadow
                          : [
                              BoxShadow(
                                color: _C.primary.withOpacity(
                                    0.3 * _glowAnimation.value),
                                blurRadius: 15,
                              ),
                            ],
                    ),
                    child: ElevatedButton(
                      onPressed: _isSending ? null : _sendBug,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (_isSending)
                            const SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2),
                            )
                          else
                            Icon(Icons.rocket_launch,
                                color: _onAccent(), size: 22),
                          const SizedBox(width: 12),
                          Text(
                            _isSending ? "DEPLOYING..." : "LAUNCH ATTACK",
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: kFont,
                              letterSpacing: 1,
                              color: _onAccent(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
        if (_isSuccess && _lastTarget != null) ...[
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(
                sigmaX: isComic ? 0 : 8,
                sigmaY: isComic ? 0 : 8,
              ),
              child: Container(
                width: double.infinity, height: 48,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: _C.success.withOpacity(0.5),
                    width: AppColors.borderWidth,
                  ),
                  color: _C.glassBg,
                ),
                child: ElevatedButton(
                  onPressed: () {
                    if (_targetMode == "number") {
                      targetController.text = _lastTarget!;
                      targetController.selection = TextSelection(
                        baseOffset: 0,
                        extentOffset: _lastTarget!.length,
                      );
                    } else {
                      linkGroupController.text = _lastTarget!;
                      linkGroupController.selection = TextSelection(
                        baseOffset: 0,
                        extentOffset: _lastTarget!.length,
                      );
                    }
                    FocusScope.of(context).requestFocus(FocusNode());
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    foregroundColor: _C.success,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.visibility, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        "CHECK TARGET: $_lastTarget",
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          fontFamily: kFont,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(FontAwesomeIcons.shieldHalved,
              color: _C.primary.withOpacity(0.3), size: 10),
          const SizedBox(width: 8),
          Text(
            "SECURE • ANONYMOUS • TRACKLESS",
            style: TextStyle(
              color: _C.primary.withOpacity(0.3),
              fontSize: 8,
              fontFamily: kFont,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _buttonController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    _glowController.dispose();
    targetController.dispose();
    linkGroupController.dispose();
    _carouselController.dispose();
    super.dispose();
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  SUCCESS DIALOG (ikut tema)
// ═══════════════════════════════════════════════════════════════════════
class _SuccessDialog extends StatelessWidget {
  final String target;
  final VoidCallback onDismiss;

  const _SuccessDialog({
    required this.target,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(
            isComic ? 6 : 28),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: isComic ? 0 : 15,
            sigmaY: isComic ? 0 : 15,
          ),
          child: Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: _C.glassBg,
              borderRadius: BorderRadius.circular(isComic ? 6 : 28),
              border: Border.all(
                color: _C.success.withOpacity(0.5),
                width: isComic ? 3 : 1,
              ),
              boxShadow: isComic
                  ? AppColors.glassShadow
                  : [BoxShadow(color: _C.success.withOpacity(0.2), blurRadius: 30)],
              gradient: isComic
                  ? null
                  : LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.white.withOpacity(0.06),
                        Colors.white.withOpacity(0.01),
                      ],
                    ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _C.success.withOpacity(0.5),
                      width: 2,
                    ),
                    boxShadow: isComic
                        ? null
                        : [BoxShadow(
                            color: _C.success.withOpacity(0.2),
                            blurRadius: 20)],
                  ),
                  child: Icon(Icons.check_circle, color: _C.success, size: 60),
                ),
                const SizedBox(height: 20),
                Text(
                  "ATTACK SUCCESSFUL",
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: kFont,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: _C.primary.withOpacity(isComic ? 0.3 : 0.1),
                    borderRadius: BorderRadius.circular(isComic ? 4 : 30),
                    border: Border.all(
                      color: _C.primary.withOpacity(0.5),
                      width: isComic ? 2 : 1,
                    ),
                  ),
                  child: Text(
                    target,
                    style: TextStyle(
                      color: isComic ? const Color(0xFF1A1A1A) : _C.primary,
                      fontSize: 16,
                      fontFamily: kFont,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final cleanNumber = target.replaceAll(RegExp(r'[^\d]'), '');
                          final waUrl = 'https://wa.me/$cleanNumber';
                          final uri = Uri.parse(waUrl);
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(uri,
                                mode: LaunchMode.externalApplication);
                          }
                        },
                        child: Container(
                          height: 50,
                          decoration: BoxDecoration(
                            color: _C.success,
                            borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                            border: isComic
                                ? Border.all(color: AppColors.border, width: 2)
                                : null,
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(FontAwesomeIcons.whatsapp,
                                    color: _C.bg, size: 16),
                                const SizedBox(width: 8),
                                Text(
                                  "NO NYA AMPAS",
                                  style: TextStyle(
                                    color: _C.bg,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: kFont,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: onDismiss,
                        child: Container(
                          height: 50,
                          decoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                            border: Border.all(
                              color: _C.primary,
                              width: isComic ? 3 : 1,
                            ),
                          ),
                          child: Center(
                            child: Text(
                              "CLOSE",
                              style: TextStyle(
                                color: _C.primary,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                fontFamily: kFont,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}