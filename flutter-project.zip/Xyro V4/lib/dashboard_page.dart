// dashboard_page.dart
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'theme.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'pilih.dart';
import 'story_widgets.dart';
import 'chat.dart';   // ✅ IMPORT BARU

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE ───────────────────────────────────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get card2     => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get glassBg   => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static Color get primary      => AppColors.accent;
  static Color get primaryMid   => AppColors.accentMid;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark  => AppColors.accentDark;
  static Color get primaryGlow  => AppColors.accentMid;

  static Color get secondary => AppColors.accentLight;
  static Color get accent    => AppColors.accentLight;

  static Color get success => AppColors.green;
  static Color get warning => AppColors.amber;
  static Color get error   => AppColors.red;

  static Color get red    => AppColors.red;
  static Color get green  => AppColors.green;
  static Color get amber  => AppColors.amber;
  static Color get gold   => AppColors.gold;
  static Color get pink   => AppColors.pink;
  static Color get orange => AppColors.amber;
  static Color get purple => AppColors.purple;
  static Color get teal   => AppColors.teal;

  static Color get grey      => AppColors.accent;
  static Color get greyMid   => AppColors.accentMid;
  static Color get greyLight => AppColors.accentLight;
  static Color get greyDark  => AppColors.accentDark;
  static Color get greyGlow  => AppColors.accentMid;

  static Color get text      => AppColors.text;
  static Color get textSub   => AppColors.textSub;
  static Color get textHint  => AppColors.textHint;
  static Color get textDim   => AppColors.textHint;
  static Color get textDark  => AppColors.textHint;

  static Color get white     => AppColors.text;
  static Color get whiteSoft => AppColors.textSub;
  static Color get whiteDim  => AppColors.textSub;
  static Color get black     => AppColors.bg;
  static Color get blackSoft => AppColors.dark;

  static LinearGradient get btnGrad   => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;

  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow  => AppColors.softShadow;
  static List<BoxShadow> get glowShadow  => ThemeModeManager.isComic3d
      ? AppColors.softShadow
      : [
          BoxShadow(
            color: AppColors.accentMid.withOpacity(0.3),
            blurRadius: 30,
            spreadRadius: 2,
          ),
        ];
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':
      return const Color(0xFF6C47FF);
    case 'admin':
      return const Color(0xFF8B6BFF);
    case 'reseller':
      return const Color(0xFFFF2D55);
    default:
      return AppColors.textSub;
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;
  late WebSocketChannel channel;
  String androidId = 'unknown';
  int _navIndex = 0;
  Widget _body = const SizedBox();
  int onlineUsers = 0;
  int activeConns = 0;
  int globalChatCount = 0;
  String lastChatPreview = 'Tap untuk gabung obrolan global...';
  late AnimationController _bgCtrl;
  late AnimationController _pageCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _pageFade;
  late Animation<Offset> _pageSlide;
  final math.Random _random = math.Random();

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    onlineUsers = 4 + _random.nextInt(9);
    activeConns = 6 + _random.nextInt(7);
    globalChatCount = 10 + _random.nextInt(20);

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 30))
      ..repeat();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pageCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _pageFade = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(
            begin: const Offset(0, 0.03), end: Offset.zero)
        .animate(CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));

    _body = _buildHomeContent();
    _initAndroidId();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _pageCtrl.forward();
        _showWelcomeDialog();
      }
    });

    _startRandomStats();
    _fetchChatPreview();
  }

  @override
  void dispose() {
    try { channel.sink.close(status.goingAway); } catch (_) {}
    _bgCtrl.dispose();
    _pageCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  void _hapticLight() { HapticFeedback.lightImpact(); }
  void _hapticMedium() { HapticFeedback.mediumImpact(); }

  // ═══════════════════════════════════════════════════════════════════
  //  FETCH PREVIEW CHAT
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _fetchChatPreview() async {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 15));
      if (!mounted) return false;
      try {
        // Ambil 1 pesan terakhir dari chat global
        // (endpoint yang gue kasih sebelumnya: /chat/messages)
        // Di sini gue skip fetch real biar nggak error kalau server belum siap
        // Kamu bisa enable kalau server udah ready
        /*
        final res = await http.get(Uri.parse(
          'http://digital.mypanelku.web.id:2041/chat/messages?key=$sessionKey&limit=1',
        ));
        final data = jsonDecode(res.body);
        if (data['success'] == true && (data['messages'] as List).isNotEmpty) {
          final last = data['messages'].last;
          setState(() {
            lastChatPreview = '${last['from']}: ${last['content']?.toString().substring(0, 30) ?? ''}...';
            globalChatCount = data['total'] ?? 0;
          });
        }
        */
        setState(() {
          globalChatCount = 10 + _random.nextInt(30);
        });
      } catch (_) {}
      return true;
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  //  WELCOME DIALOG
  // ═══════════════════════════════════════════════════════════════════
  void _showWelcomeDialog() {
    _hapticMedium();
    final isComic = ThemeModeManager.isComic3d;
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.85),
      transitionDuration: const Duration(milliseconds: 500),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 24),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 20,
              sigmaY: isComic ? 0 : 20,
            ),
            child: Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 24),
                border: Border.all(
                  color: isComic
                      ? AppColors.border
                      : _C.primary.withOpacity(0.3),
                  width: isComic ? 3 : 1.5,
                ),
                boxShadow: isComic
                    ? AppColors.glassShadow
                    : [
                        BoxShadow(
                          color: _C.primary.withOpacity(0.2),
                          blurRadius: 60,
                          spreadRadius: 4,
                        ),
                      ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: _C.btnGrad,
                      border: isComic
                          ? Border.all(color: AppColors.border, width: 3)
                          : null,
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                color: _C.primary.withOpacity(0.5),
                                blurRadius: 30,
                                spreadRadius: 4,
                              ),
                            ],
                    ),
                    child: Icon(Icons.waving_hand_rounded,
                        color: _onAccent(), size: 40),
                  ),
                  const SizedBox(height: 24),
                  isComic
                      ? Text('Welcome Back',
                          style: TextStyle(
                            color: _C.primary,
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            fontFamily: kFont,
                            letterSpacing: -0.5,
                          ))
                      : ShaderMask(
                          shaderCallback: (b) => LinearGradient(
                            colors: [_C.white, _C.primaryLight],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ).createShader(b),
                          child: Text('Welcome Back',
                              style: TextStyle(
                                color: _C.white,
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                                fontFamily: kFont,
                                letterSpacing: -0.5,
                              )),
                        ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: _C.primary.withOpacity(isComic ? 0.3 : 0.1),
                      borderRadius: BorderRadius.circular(isComic ? 4 : 20),
                      border: Border.all(
                        color: _C.primary.withOpacity(0.5),
                        width: isComic ? 2 : 1,
                      ),
                    ),
                    child: Text('Selamat Datang di XenCode',
                        style: TextStyle(
                          color: isComic
                              ? const Color(0xFF1A1A1A)
                              : _C.primaryLight,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          fontFamily: kFont,
                          letterSpacing: 0.5,
                        )),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'XenCode dirancang untuk keamanan & OSINT tools premium',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _C.textSub,
                      fontSize: 13,
                      fontFamily: kFont,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          _C.primary.withOpacity(0.3),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.code_rounded, color: _C.textDim, size: 14),
                      const SizedBox(width: 6),
                      Text('By @ameluchuu',
                          style: TextStyle(
                            color: _C.textDim,
                            fontSize: 12,
                            fontFamily: kFont,
                            letterSpacing: 1,
                          )),
                    ],
                  ),
                  const SizedBox(height: 24),
                  GestureDetector(
                    onTap: () {
                      _hapticLight();
                      Navigator.pop(ctx);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 40, vertical: 14),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius:
                            BorderRadius.circular(isComic ? 4 : 14),
                        border: isComic
                            ? Border.all(color: AppColors.border, width: 2)
                            : null,
                        boxShadow: isComic
                            ? AppColors.softShadow
                            : [
                                BoxShadow(
                                  color: _C.primary.withOpacity(0.4),
                                  blurRadius: 20,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                      ),
                      child: Text('MULAI',
                          style: TextStyle(
                            color: _onAccent(),
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: kFont,
                            letterSpacing: 2,
                          )),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _startRandomStats() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 5));
      if (!mounted) return false;
      setState(() {
        onlineUsers = 4 + _random.nextInt(9);
        activeConns = 6 + _random.nextInt(7);
      });
      return true;
    });
  }

  Future<void> _initAndroidId() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
    } catch (_) {}
    _connectWS();
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(
          Uri.parse('https://dayzxteam.serverku.space'));
      channel.sink.add(jsonEncode({
        'type': 'validate',
        'key': sessionKey,
        'androidId': androidId,
      }));
      channel.sink.add(jsonEncode({'type': 'stats'}));

      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          _handleInvalidSession('Sesi tidak valid. Silakan login ulang.');
        }
      });
    } catch (_) {}
  }

  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (_) => false,
    );
  }

  void _navigate(Widget page) {
    _hapticLight();
    setState(() => _body = page);
    _pageCtrl.forward(from: 0);
  }

  void _onNavTap(int index) {
    _hapticMedium();
    setState(() => _navIndex = index);
    switch (index) {
      case 0:
        _navigate(_buildHomeContent());
        break;
      case 1:
        _showWhatsAppBottomSheet();
        break;
      case 2:
        _navigate(InfoPage(sessionKey: sessionKey));
        break;
      case 3:
        _navigate(ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
          username: username,
        ));
        break;
      case 4:
        _navigate(ProfilePage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        ));
        break;
    }
  }

  Future<void> _openUrl(String url) async {
    _hapticLight();
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  void _openPilihPage() {
    _navigate(PilihPage(
      sessionKey: sessionKey,
      username: username,
      role: role,
      expiredDate: expiredDate,
      password: password,
      listBug: listBug,
      listDoos: listDoos,
    ));
  }

  void _openGlobalChat() {
    _hapticMedium();
    Navigator.push(
      context,
      _slideRoute(ChatPage(
        sessionKey: sessionKey,
        username: username,
        role: role,
      )),
    );
  }

  void _showWhatsAppBottomSheet() {
    _hapticLight();
    final isComic = ThemeModeManager.isComic3d;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return ClipRRect(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(AppColors.sheetRadius),
          ),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(AppColors.sheetRadius),
                ),
                border: Border.all(
                  color: _C.border,
                  width: AppColors.borderWidth,
                ),
                boxShadow: _C.glassShadow,
              ),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40, height: 4,
                      decoration: BoxDecoration(
                        color: _C.textSub.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Container(
                        width: 4, height: 18,
                        decoration: BoxDecoration(
                          gradient: _C.btnGrad,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text('WHATSAPP TOOLS',
                          style: TextStyle(
                            color: _C.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5,
                            fontFamily: kFont,
                          )),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: _C.textSub.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text('2 menu',
                            style: TextStyle(
                                color: _C.textSub,
                                fontSize: 11,
                                fontFamily: kFont)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _ActionCard(
                    icon: Icons.chat_rounded,
                    iconColor: _C.primary,
                    title: 'WhatsApp Crash',
                    subtitle: 'Send payloads & crash codes',
                    trailing: Icon(Icons.arrow_forward_ios_rounded,
                        size: 14, color: _C.primary),
                    onTap: () {
                      Navigator.pop(ctx);
                      _openPilihPage();
                    },
                  ),
                  const SizedBox(height: 10),
                  _ActionCard(
                    icon: Icons.devices_rounded,
                    iconColor: _C.primary,
                    title: 'Manage Sender',
                    subtitle: 'Pair devices & manage sessions',
                    trailing: Icon(Icons.arrow_forward_ios_rounded,
                        size: 14, color: _C.primary),
                    onTap: () {
                      Navigator.pop(ctx);
                      _hapticLight();
                      Navigator.push(
                        context,
                        _slideRoute(BugSenderPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        )),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    _hapticMedium();
    switch (index) {
      case 1:
        _navigate(SellerPage(keyToken: sessionKey));
        break;
      case 2:
        _navigate(AdminPage(sessionKey: sessionKey));
        break;
      case 3:
        _navigate(OwnerPage(sessionKey: sessionKey, username: username));
        break;
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  HOME CONTENT
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHomeContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(0, 8, 0, 130),
      child: Column(
        children: [
          StoryBar(
            sessionKey: sessionKey,
            username: username,
          ),
          const SizedBox(height: 4),
          _buildBannerImage(),
          const SizedBox(height: 12),
          _buildInfoHeader(),
          const SizedBox(height: 12),
          _buildProfileStatsAndProjectCard(),
          const SizedBox(height: 14),
          _buildGlobalChatCard(),          // ✅ CARD BARU
          const SizedBox(height: 20),
          _buildQuickActions(),
          const SizedBox(height: 24),
          _buildTrendingRow(),
          const SizedBox(height: 24),
          _buildNewsSection(),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ✅ GLOBAL CHAT CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGlobalChatCard() {
    final isComic = ThemeModeManager.isComic3d;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: _openGlobalChat,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: isComic ? AppColors.border : _C.glassBorder,
              width: AppColors.borderWidth,
            ),
            boxShadow: _C.glassShadow,
          ),
          child: Row(
            children: [
              // ─── KIRI: Icon Global bulat ───
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      _C.primary.withOpacity(0.30),
                      _C.primary.withOpacity(0.05),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(
                    color: _C.primary.withOpacity(0.4),
                    width: 2,
                  ),
                  boxShadow: isComic
                      ? null
                      : [
                          BoxShadow(
                            color: _C.primary.withOpacity(0.3),
                            blurRadius: 14,
                            spreadRadius: 1,
                          ),
                        ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(Icons.public_rounded, color: _C.primary, size: 26),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: AnimatedBuilder(
                        animation: _pulseCtrl,
                        builder: (_, __) => Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _C.red,
                            border: Border.all(
                              color: isComic ? AppColors.card : _C.bg,
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _C.red.withOpacity(
                                    0.4 + 0.4 * _pulseCtrl.value),
                                blurRadius: 6 + 4 * _pulseCtrl.value,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),

              // ─── TENGAH: Title + preview ───
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          'Global Chat',
                          style: TextStyle(
                            color: _C.text,
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFont,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                            color: _C.green.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: _C.green.withOpacity(0.4),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              AnimatedBuilder(
                                animation: _pulseCtrl,
                                builder: (_, __) => Container(
                                  width: 5,
                                  height: 5,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: _C.green.withOpacity(
                                        0.5 + 0.5 * _pulseCtrl.value),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'LIVE',
                                style: TextStyle(
                                  color: _C.green,
                                  fontFamily: kFont,
                                  fontSize: 8,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      lastChatPreview,
                      style: TextStyle(
                        color: _C.textSub,
                        fontSize: 11,
                        fontFamily: kFont,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),

              // ─── KANAN: Badge count + arrow ───
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _C.primary.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.people_alt_rounded,
                        color: _C.primary, size: 11),
                    const SizedBox(width: 3),
                    Text(
                      '$globalChatCount',
                      style: TextStyle(
                        color: _C.primary,
                        fontFamily: kFont,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Icon(
                Icons.arrow_forward_ios_rounded,
                color: _C.textDim,
                size: 14,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBannerImage() {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: Container(
          decoration: isComic
              ? BoxDecoration(
                  borderRadius: BorderRadius.circular(AppColors.cardRadius),
                  border: Border.all(color: AppColors.border, width: 3),
                  boxShadow: AppColors.glassShadow,
                )
              : null,
          child: Image.asset(
            'assets/images/1.jpg',
            height: 180,
            width: double.infinity,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              height: 180,
              decoration: BoxDecoration(color: _C.card),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.image_rounded, color: _C.textDim, size: 40),
                  const SizedBox(height: 8),
                  Text('Gambar tidak ditemukan',
                      style: TextStyle(
                        color: _C.textDim,
                        fontSize: 12,
                        fontFamily: kFont,
                      )),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Container(
            width: 3, height: 16,
            decoration: BoxDecoration(
              gradient: _C.btnGrad,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          Text('INFORMASI AKUN',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
                fontFamily: kFont,
              )),
        ],
      ),
    );
  }

  Widget _buildProfileStatsAndProjectCard() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: isComic ? AppColors.border : _C.glassBorder,
          width: AppColors.borderWidth,
        ),
        boxShadow: _C.glassShadow,
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/akun.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: BoxDecoration(
                  gradient: isComic ? null : _C.glassGrad,
                  color: isComic ? AppColors.card : null,
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: isComic
                    ? LinearGradient(
                        colors: [
                          Colors.white.withOpacity(0.20),
                          Colors.white.withOpacity(0.10),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      )
                    : LinearGradient(
                        colors: [
                          Colors.black.withOpacity(0.35),
                          Colors.black.withOpacity(0.55),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
              ),
            ),
          ),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 52, height: 52,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: _C.btnGrad,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.3),
                          width: 2,
                        ),
                        boxShadow: _C.glowShadow,
                      ),
                      child: ClipOval(
                        child: Icon(Icons.person_rounded,
                            size: 32, color: _onAccent()),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(username,
                                    style: TextStyle(
                                      color: _C.white,
                                      fontSize: 17,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: -0.3,
                                      fontFamily: kFont,
                                      shadows: [
                                        Shadow(
                                          color: Colors.black.withOpacity(0.5),
                                          blurRadius: 4,
                                        ),
                                      ],
                                    ),
                                    overflow: TextOverflow.ellipsis),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 3),
                                decoration: BoxDecoration(
                                  gradient: _C.btnGrad,
                                  borderRadius: BorderRadius.circular(
                                      isComic ? 3 : 20),
                                  border: isComic
                                      ? Border.all(
                                          color: AppColors.border, width: 2)
                                      : null,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 6,
                                    ),
                                  ],
                                ),
                                child: Text(role.toUpperCase(),
                                    style: TextStyle(
                                      color: _onAccent(),
                                      fontSize: 8,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.5,
                                      fontFamily: kFont,
                                    )),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Icons.calendar_today_rounded,
                                  color: _C.white.withOpacity(0.7), size: 12),
                              const SizedBox(width: 4),
                              Text('Exp: $expiredDate',
                                  style: TextStyle(
                                      color: _C.white.withOpacity(0.85),
                                      fontSize: 11,
                                      fontFamily: kFont,
                                      shadows: [
                                        Shadow(
                                          color: Colors.black.withOpacity(0.5),
                                          blurRadius: 4,
                                        ),
                                      ])),
                              const SizedBox(width: 12),
                              Container(
                                width: 6, height: 6,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _C.success,
                                  boxShadow: isComic
                                      ? null
                                      : [
                                          BoxShadow(
                                            color: _C.success.withOpacity(
                                                0.4 + 0.3 * _pulseCtrl.value),
                                            blurRadius: 8,
                                          )
                                        ],
                                ),
                              ),
                              const SizedBox(width: 4),
                              Text('Online',
                                  style: TextStyle(
                                    color: _C.success,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: kFont,
                                    shadows: [
                                      Shadow(
                                        color: Colors.black.withOpacity(0.5),
                                        blurRadius: 4,
                                      ),
                                    ],
                                  )),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.35),
                    borderRadius: BorderRadius.circular(isComic ? 4 : 20),
                    border: Border.all(
                      color: _C.primary.withOpacity(0.4),
                      width: AppColors.borderWidth,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.cloud_rounded, color: _C.primary, size: 14),
                      const SizedBox(width: 6),
                      Text('XenCode Project',
                          style: TextStyle(
                            color: _C.primary,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFont,
                          )),
                      const SizedBox(width: 6),
                      Container(
                        width: 4, height: 4,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.white.withOpacity(0.5),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text('v6.0.0',
                          style: TextStyle(
                            color: _C.white.withOpacity(0.7),
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            fontFamily: kFont,
                          )),
                      const SizedBox(width: 6),
                      Container(
                        width: 4, height: 4,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.success,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text('Running',
                          style: TextStyle(
                            color: _C.success,
                            fontSize: 9,
                            fontWeight: FontWeight.w600,
                            fontFamily: kFont,
                          )),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                height: 1,
                margin: const EdgeInsets.symmetric(horizontal: 16),
                color: Colors.white.withOpacity(0.15),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildStatItem(
                      icon: Icons.people_alt_rounded,
                      label: 'Online',
                      value: '$onlineUsers',
                      color: _C.primary,
                    ),
                    _buildStatDivider(),
                    _buildStatItem(
                      icon: Icons.wifi_rounded,
                      label: 'Koneksi',
                      value: '$activeConns',
                      color: _C.accent,
                    ),
                    _buildStatDivider(),
                    _buildStatItem(
                      icon: Icons.bug_report_rounded,
                      label: 'Bug',
                      value: '${listBug.length}',
                      color: _C.secondary,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 4),
          Text(value,
              style: TextStyle(
                color: _C.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
                fontFamily: kFont,
                shadows: [
                  Shadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 4,
                  ),
                ],
              )),
          Text(label,
              style: TextStyle(
                color: _C.white.withOpacity(0.75),
                fontSize: 10,
                fontWeight: FontWeight.w500,
                fontFamily: kFont,
                shadows: [
                  Shadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 3,
                  ),
                ],
              )),
        ],
      ),
    );
  }

  Widget _buildStatDivider() {
    return Container(
      width: 1,
      height: 40,
      color: Colors.white.withOpacity(0.2),
    );
  }

  Widget _buildQuickActions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 12),
            child: Row(
              children: [
                Container(
                  width: 3, height: 14,
                  decoration: BoxDecoration(
                    gradient: _C.btnGrad,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 8),
                Text('Quick Actions',
                    style: TextStyle(
                      color: _C.textSub,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.3,
                      fontFamily: kFont,
                    )),
              ],
            ),
          ),
          Row(
            children: [
              Expanded(
                child: _ActionCard(
                  icon: Icons.telegram_rounded,
                  iconColor: _C.primary,
                  title: 'Info Channel',
                  subtitle: 'Gabung XENCODE Info',
                  onTap: () => _openUrl('https://t.me/xencodeinfo'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ActionCard(
                  icon: Icons.wifi_tethering_error_rounded,
                  iconColor: _C.primary,
                  title: 'Bug Sender',
                  subtitle: 'Kelola sender aktif',
                  onTap: () {
                    _hapticLight();
                    Navigator.push(
                      context,
                      _slideRoute(BugSenderPage(
                        sessionKey: sessionKey,
                        username: username,
                        role: role,
                      )),
                    );
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _ActionCard(
                  icon: Icons.history_rounded,
                  iconColor: _C.accent,
                  title: 'Riwayat',
                  subtitle: 'Lihat aktivitas',
                  onTap: () {
                    _hapticLight();
                    Navigator.push(
                      context,
                      _slideRoute(RiwayatPage(
                        sessionKey: sessionKey,
                        role: role,
                      )),
                    );
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ActionCard(
                  icon: Icons.tune_rounded,
                  iconColor: _C.secondary,
                  title: 'Tools',
                  subtitle: 'Menu lengkap',
                  onTap: () {
                    _hapticLight();
                    Navigator.push(
                      context,
                      _slideRoute(ToolsPage(
                        sessionKey: sessionKey,
                        userRole: role,
                        listDoos: listDoos,
                        username: username,
                      )),
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTrendingRow() {
    final trendingItems = [
      {'icon': Icons.bolt_rounded, 'label': 'DDoS', 'color': _C.primary},
      {'icon': Icons.search_rounded, 'label': 'OSINT', 'color': _C.secondary},
      {'icon': Icons.download_rounded, 'label': 'Download', 'color': _C.primary},
      {'icon': Icons.qr_code_rounded, 'label': 'QR Gen', 'color': _C.accent},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Row(
              children: [
                Container(
                  width: 3, height: 14,
                  decoration: BoxDecoration(
                    gradient: _C.btnGrad,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 8),
                Text('Trending',
                    style: TextStyle(
                      color: _C.textSub,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.3,
                      fontFamily: kFont,
                    )),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: _C.primary.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _C.primary.withOpacity(0.15),
                      width: 0.5,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.trending_up_rounded,
                          color: _C.primary, size: 10),
                      const SizedBox(width: 4),
                      Text('Hot',
                          style: TextStyle(
                            color: _C.primary,
                            fontSize: 8,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFont,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: trendingItems.map((item) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: _TrendingChip(
                    icon: item['icon'] as IconData,
                    label: item['label'] as String,
                    color: item['color'] as Color,
                    onTap: _hapticLight,
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNewsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Row(
              children: [
                Container(
                  width: 3, height: 14,
                  decoration: BoxDecoration(
                    gradient: _C.btnGrad,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 8),
                Text('News',
                    style: TextStyle(
                      color: _C.textSub,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.3,
                      fontFamily: kFont,
                    )),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: _C.textSub.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text('${newsList.length}',
                      style: TextStyle(
                          color: _C.textDim,
                          fontSize: 10,
                          fontFamily: kFont)),
                ),
              ],
            ),
          ),
          if (newsList.isNotEmpty)
            SizedBox(
              height: 180,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: newsList.length,
                itemBuilder: (context, index) {
                  final item = newsList[index];
                  return Container(
                    width: MediaQuery.of(context).size.width * 0.7,
                    margin: const EdgeInsets.only(right: 12),
                    decoration: BoxDecoration(
                      gradient: ThemeModeManager.isComic3d
                          ? null
                          : _C.glassGrad,
                      color: ThemeModeManager.isComic3d
                          ? AppColors.card
                          : null,
                      borderRadius:
                          BorderRadius.circular(AppColors.cardRadius),
                      border: Border.all(
                        color: ThemeModeManager.isComic3d
                            ? AppColors.border
                            : _C.glassBorder,
                        width: AppColors.borderWidth,
                      ),
                      boxShadow: _C.softShadow,
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        if (item['image'] != null &&
                            item['image'].toString().isNotEmpty)
                          CachedNetworkImage(
                            imageUrl: item['image'],
                            fit: BoxFit.cover,
                            placeholder: (_, __) => Container(
                              color: _C.card,
                              child: Center(
                                child: SizedBox(
                                  width: 24, height: 24,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: _C.primary,
                                  ),
                                ),
                              ),
                            ),
                            errorWidget: (_, __, ___) => Container(
                              color: _C.card,
                              child: Icon(Icons.image_rounded,
                                  color: _C.textDim, size: 32),
                            ),
                          ),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                _C.bg.withOpacity(0.75),
                                Colors.transparent,
                                Colors.transparent,
                              ],
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              stops: const [0.0, 0.4, 1.0],
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 14, left: 14, right: 14,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  gradient: _C.btnGrad,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text('NEWS',
                                    style: TextStyle(
                                      color: _onAccent(),
                                      fontSize: 7,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.5,
                                      fontFamily: kFont,
                                    )),
                              ),
                              const SizedBox(height: 4),
                              Text(item['title'] ?? 'No Title',
                                  style: TextStyle(
                                    color: _C.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2,
                                    fontFamily: kFont,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            )
          else
            Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: ThemeModeManager.isComic3d
                    ? null
                    : _C.glassGrad,
                color: ThemeModeManager.isComic3d
                    ? AppColors.card
                    : null,
                borderRadius: BorderRadius.circular(AppColors.cardRadius),
                border: Border.all(
                  color: ThemeModeManager.isComic3d
                      ? AppColors.border
                      : _C.glassBorder,
                  width: AppColors.borderWidth,
                ),
              ),
              child: Center(
                child: Column(
                  children: [
                    Icon(Icons.newspaper_rounded,
                        color: _C.textDim, size: 28),
                    const SizedBox(height: 6),
                    Text('No news yet',
                        style: TextStyle(
                            color: _C.textDim,
                            fontSize: 12,
                            fontFamily: kFont)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          extendBodyBehindAppBar: true,
          extendBody: true,
          appBar: _buildAppBar(),
          drawer: _buildDrawer(),
          body: AppBackground(
            controller: _bgCtrl,
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: FadeTransition(
                opacity: _pageFade,
                child: SlideTransition(
                  position: _pageSlide,
                  child: _body,
                ),
              ),
            ),
          ),
          bottomNavigationBar: _buildBottomNav(),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      titleSpacing: 0,
      leading: Builder(
        builder: (ctx) => _MenuBtn(onTap: () {
          _hapticLight();
          Scaffold.of(ctx).openDrawer();
        }),
      ),
      title: Text('XenCode',
          style: TextStyle(
            color: _C.text,
            fontSize: 18,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.5,
            fontFamily: kFont,
          )),
      actions: [
        _AppBarIcon(
          icon: Icons.headset_mic_outlined,
          onTap: () {
            _hapticLight();
            Navigator.push(context, _slideRoute(const ContactPage()));
          },
        ),
        _AppBarIcon(
          icon: Icons.account_circle_outlined,
          onTap: () {
            _navigate(ProfilePage(
              username: username,
              password: password,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            ));
          },
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildBottomNav() {
    final isComic = ThemeModeManager.isComic3d;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
        child: SizedBox(
          height: 78 + 30,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                left: 0, right: 0, bottom: 0,
                height: 78,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(isComic ? 6 : 30),
                    border: Border.all(
                      color: isComic ? AppColors.border : _C.glassBorder,
                      width: isComic ? 3 : 1,
                    ),
                    boxShadow: isComic
                        ? AppColors.glassShadow
                        : [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.5),
                              blurRadius: 24,
                              offset: const Offset(0, 8),
                            ),
                            BoxShadow(
                              color: _C.primary.withOpacity(0.08),
                              blurRadius: 40,
                              offset: const Offset(0, -2),
                            ),
                          ],
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: Image.asset(
                          'assets/images/nav.jpg',
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            decoration: BoxDecoration(
                              gradient: isComic ? null : _C.glassGrad,
                              color: isComic ? AppColors.card : null,
                            ),
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: Container(
                          color: isComic
                              ? Colors.white.withOpacity(0.15)
                              : Colors.black.withOpacity(0.40),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 0, right: 0, bottom: 0,
                height: 78,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _NavItemLift(
                      icon: Icons.home_rounded,
                      label: 'Home',
                      active: _navIndex == 0,
                      onTap: () => _onNavTap(0),
                    ),
                    _NavItemLift(
                      icon: Icons.chat_rounded,
                      label: 'WA',
                      active: _navIndex == 1,
                      onTap: () => _onNavTap(1),
                    ),
                    _NavItemLift(
                      icon: Icons.person_rounded,
                      label: 'Profile',
                      active: _navIndex == 4,
                      onTap: () => _onNavTap(4),
                    ),
                    _NavItemLift(
                      icon: Icons.campaign_rounded,
                      label: 'Info',
                      active: _navIndex == 2,
                      onTap: () => _onNavTap(2),
                    ),
                    _NavItemLift(
                      icon: Icons.tune_rounded,
                      label: 'Tools',
                      active: _navIndex == 3,
                      onTap: () => _onNavTap(3),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    final isComic = ThemeModeManager.isComic3d;
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.78,
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topRight: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: isComic ? 0 : 15,
            sigmaY: isComic ? 0 : 15,
          ),
          child: Container(
            decoration: BoxDecoration(
              gradient: isComic ? null : _C.glassGrad,
              color: isComic ? AppColors.card : null,
              border: Border(
                right: BorderSide(
                  color: _C.border,
                  width: AppColors.borderWidth,
                ),
              ),
              boxShadow: _C.glassShadow,
            ),
            child: Column(
              children: [
                _DrawerHeader(
                  username: username,
                  role: role,
                  expiredDate: expiredDate,
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                    children: [
                      if (role == 'reseller')
                        _DrawerItem(
                          icon: Icons.storefront_rounded,
                          label: 'Seller Page',
                          onTap: () => _onDrawerNav(1),
                        ),
                      if (role == 'admin')
                        _DrawerItem(
                          icon: Icons.admin_panel_settings_rounded,
                          label: 'Admin Page',
                          onTap: () => _onDrawerNav(2),
                        ),
                      if (role == 'owner')
                        _DrawerItem(
                          icon: Icons.workspace_premium_rounded,
                          label: 'Owner Page',
                          onTap: () => _onDrawerNav(3),
                        ),
                      _DrawerItem(
                        icon: Icons.history_rounded,
                        label: 'Riwayat Aktivitas',
                        onTap: () {
                          Navigator.pop(context);
                          _hapticLight();
                          Navigator.push(
                            context,
                            _slideRoute(RiwayatPage(
                              sessionKey: sessionKey,
                              role: role,
                            )),
                          );
                        },
                      ),
                      _DrawerItem(
                        icon: Icons.lock_outline_rounded,
                        label: 'Ganti Password',
                        onTap: () {
                          Navigator.pop(context);
                          _hapticLight();
                          Navigator.push(
                            context,
                            _slideRoute(ChangePasswordPage(
                              username: username,
                              sessionKey: sessionKey,
                            )),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  child: _DrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isDestructive: true,
                    onTap: () async {
                      _hapticMedium();
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                            builder: (_) => const LoginPage()),
                        (_) => false,
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  WIDGETS
// ═══════════════════════════════════════════════════════════════════════
class _ActionCard extends StatefulWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback onTap;
  const _ActionCard({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.trailing,
  });

  @override
  State<_ActionCard> createState() => _ActionCardState();
}

class _ActionCardState extends State<_ActionCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _pressed
                  ? widget.iconColor.withOpacity(0.5)
                  : (isComic ? AppColors.border : _C.glassBorder),
              width: AppColors.borderWidth,
            ),
            boxShadow: isComic
                ? AppColors.softShadow
                : (_pressed
                    ? [
                        BoxShadow(
                          color: widget.iconColor.withOpacity(0.05),
                          blurRadius: 15,
                        ),
                      ]
                    : _C.softShadow),
          ),
          child: Row(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isComic
                        ? [
                            widget.iconColor.withOpacity(1.0),
                            widget.iconColor.withOpacity(0.7),
                          ]
                        : [
                            widget.iconColor.withOpacity(0.1),
                            widget.iconColor.withOpacity(0.02),
                          ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(isComic ? 4 : 10),
                  border: isComic
                      ? Border.all(color: AppColors.border, width: 2)
                      : null,
                ),
                child: Icon(
                  widget.icon,
                  color: isComic
                      ? const Color(0xFF1A1A1A)
                      : widget.iconColor,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.title,
                        style: TextStyle(
                          color: _C.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          fontFamily: kFont,
                        )),
                    const SizedBox(height: 1),
                    Text(widget.subtitle,
                        style: TextStyle(
                          color: _C.textDim,
                          fontSize: 10,
                          fontFamily: kFont,
                        )),
                  ],
                ),
              ),
              if (widget.trailing != null) widget.trailing!,
            ],
          ),
        ),
      ),
    );
  }
}

class _TrendingChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _TrendingChip({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          gradient: isComic ? null : _C.glassGrad,
          color: isComic ? AppColors.card : null,
          borderRadius: BorderRadius.circular(isComic ? 4 : 12),
          border: Border.all(
            color: _C.border,
            width: AppColors.borderWidth,
          ),
          boxShadow: _C.softShadow,
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                  color: _C.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  fontFamily: kFont,
                )),
          ],
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;
  const _DrawerHeader({
    required this.username,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<_DrawerHeader> createState() => _DrawerHeaderState();
}

class _DrawerHeaderState extends State<_DrawerHeader>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _fade = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    _c.forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(widget.role);
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      height: 190,
      clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        gradient: isComic ? null : _C.glassGrad,
        color: isComic ? AppColors.card : null,
        border: Border(
          bottom: BorderSide(
            color: rColor.withOpacity(0.3),
            width: AppColors.borderWidth,
          ),
        ),
        boxShadow: _C.softShadow,
      ),
      child: Stack(
        children: [
          Positioned(
            right: -40, bottom: -40,
            child: Container(
              width: 140, height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: rColor.withOpacity(0.03),
              ),
            ),
          ),
          Positioned.fill(
            child: SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slide,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Stack(
                        children: [
                          Container(
                            width: 64, height: 64,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: rColor,
                                width: isComic ? 3 : 2,
                              ),
                              boxShadow: isComic
                                  ? null
                                  : [
                                      BoxShadow(
                                        color: rColor.withOpacity(0.15),
                                        blurRadius: 25,
                                      )
                                    ],
                            ),
                            child: ClipOval(
                              child: Icon(Icons.person_rounded,
                                  size: 32, color: _C.white),
                            ),
                          ),
                          Positioned(
                            right: 0, bottom: 0,
                            child: Container(
                              padding: const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    rColor,
                                    rColor.withOpacity(0.3)
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: _C.surface,
                                  width: 2,
                                ),
                              ),
                              child: Icon(Icons.person_rounded,
                                  size: 8, color: _onAccent()),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(widget.username,
                          style: TextStyle(
                            color: _C.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            fontFamily: kFont,
                          )),
                      const SizedBox(height: 2),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 2),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [rColor, rColor.withOpacity(0.3)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(
                              isComic ? 3 : 20),
                        ),
                        child: Text(widget.role.toUpperCase(),
                            style: TextStyle(
                              color: _onAccent(),
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1,
                              fontFamily: kFont,
                            )),
                      ),
                      const SizedBox(height: 3),
                      Text('Exp: ${widget.expiredDate}',
                          style: TextStyle(
                            color: _C.textSub,
                            fontSize: 10,
                            fontFamily: kFont,
                          )),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DrawerItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isDestructive;
  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.isDestructive = false,
  });

  @override
  State<_DrawerItem> createState() => _DrawerItemState();
}

class _DrawerItemState extends State<_DrawerItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final color = widget.isDestructive ? _C.red : _C.primary;
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          gradient: _pressed && !isComic
              ? LinearGradient(
                  colors: [color.withOpacity(0.08), Colors.transparent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: _pressed && isComic ? color.withOpacity(0.1) : null,
          borderRadius: BorderRadius.circular(isComic ? 4 : 10),
          border: Border.all(
            color: _pressed ? color.withOpacity(0.3) : _C.border,
            width: AppColors.borderWidth,
          ),
        ),
        child: Row(
          children: [
            Icon(widget.icon, color: color, size: 18),
            const SizedBox(width: 14),
            Text(widget.label,
                style: TextStyle(
                  color: widget.isDestructive ? _C.red : _C.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: kFont,
                )),
            const Spacer(),
            Icon(Icons.arrow_forward_ios_rounded,
                color: _C.textDim, size: 12),
          ],
        ),
      ),
    );
  }
}

class _NavItemLift extends StatefulWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _NavItemLift({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  State<_NavItemLift> createState() => _NavItemLiftState();
}

class _NavItemLiftState extends State<_NavItemLift>
    with TickerProviderStateMixin {
  late AnimationController _liftCtrl;
  late Animation<double> _liftAnim;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();

    _liftCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    _liftAnim = Tween<double>(begin: 0.0, end: -10.0).animate(
      CurvedAnimation(parent: _liftCtrl, curve: Curves.easeOutBack),
    );

    _scaleAnim = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _liftCtrl, curve: Curves.easeOutBack),
    );

    if (widget.active) _liftCtrl.value = 1.0;
  }

  @override
  void didUpdateWidget(_NavItemLift old) {
    super.didUpdateWidget(old);
    if (widget.active && !old.active) {
      _liftCtrl.forward();
    } else if (!widget.active && old.active) {
      _liftCtrl.reverse();
    }
  }

  @override
  void dispose() {
    _liftCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTap: widget.onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _liftCtrl,
        builder: (context, child) {
          final liftY = _liftAnim.value;
          final scale = _scaleAnim.value;

          return SizedBox(
            width: 60,
            height: 78,
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                if (widget.active)
                  Positioned(
                    top: liftY - 5,
                    child: Transform.scale(
                      scale: scale,
                      child: Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: isComic
                              ? AppColors.btnGrad
                              : LinearGradient(
                                  colors: [
                                    AppColors.accent,
                                    AppColors.accentMid,
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                          border: Border.all(
                            color: isComic
                                ? AppColors.border
                                : Colors.white.withOpacity(0.4),
                            width: isComic ? 3 : 2,
                          ),
                          boxShadow: isComic
                              ? AppColors.softShadow
                              : [
                                  BoxShadow(
                                    color: AppColors.accent
                                        .withOpacity(0.55),
                                    blurRadius: 20,
                                    spreadRadius: 2,
                                    offset: const Offset(0, 6),
                                  ),
                                  BoxShadow(
                                    color: AppColors.accent
                                        .withOpacity(0.25),
                                    blurRadius: 32,
                                    spreadRadius: 6,
                                  ),
                                ],
                        ),
                        child: Icon(
                          widget.icon,
                          size: 24,
                          color: _onAccent(),
                        ),
                      ),
                    ),
                  ),
                if (!widget.active)
                  Positioned(
                    top: 12,
                    child: Icon(
                      widget.icon,
                      size: 22,
                      color: _C.textSub,
                    ),
                  ),
                Positioned(
                  bottom: 8,
                  child: Text(
                    widget.label,
                    style: TextStyle(
                      color: widget.active
                          ? _C.primary
                          : _C.textSub,
                      fontSize: 9,
                      fontWeight: widget.active
                          ? FontWeight.w700
                          : FontWeight.w500,
                      fontFamily: kFont,
                      shadows: [
                        Shadow(
                          color: Colors.black.withOpacity(0.6),
                          blurRadius: 4,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _AppBarIcon extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _AppBarIcon({required this.icon, required this.onTap});

  @override
  State<_AppBarIcon> createState() => _AppBarIconState();
}

class _AppBarIconState extends State<_AppBarIcon> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) {
          setState(() => _down = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: 36, height: 36,
          decoration: BoxDecoration(
            gradient: _down && !ThemeModeManager.isComic3d
                ? _C.glassGrad
                : null,
            color: _down && ThemeModeManager.isComic3d
                ? AppColors.card2
                : null,
            borderRadius: BorderRadius.circular(
                ThemeModeManager.isComic3d ? 4 : 10),
            border: Border.all(
              color: _down ? _C.primary.withOpacity(0.3) : _C.border,
              width: AppColors.borderWidth,
            ),
          ),
          child: Icon(widget.icon,
              color: _down ? _C.primary : _C.textDim, size: 18),
        ),
      ),
    );
  }
}

class _MenuBtn extends StatefulWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});

  @override
  State<_MenuBtn> createState() => _MenuBtnState();
}

class _MenuBtnState extends State<_MenuBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) {
          setState(() => _down = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          decoration: BoxDecoration(
            gradient: _down && !ThemeModeManager.isComic3d
                ? _C.glassGrad
                : null,
            color: _down && ThemeModeManager.isComic3d
                ? AppColors.card2
                : null,
            borderRadius: BorderRadius.circular(
                ThemeModeManager.isComic3d ? 4 : 10),
            border: Border.all(
              color: _down ? _C.primary.withOpacity(0.3) : _C.border,
              width: AppColors.borderWidth,
            ),
          ),
          child: Icon(Icons.menu_rounded,
              color: _down ? _C.primary : _C.textDim, size: 20),
        ),
      ),
    );
  }
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );