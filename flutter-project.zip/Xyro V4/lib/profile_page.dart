// profile_page.dart
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';

import 'theme.dart';   // ← SISTEM TEMA
import 'change_password_page.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE (alias ke AppColors dinamis) ──────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get glassBg   => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static Color get primary      => AppColors.accentMid;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark  => AppColors.accentDark;
  static Color get accent       => AppColors.accentLight;
  static Color get success      => AppColors.green;
  static Color get secondary    => AppColors.accent;
  static Color get white        => AppColors.text;
  static Color get whiteDim     => AppColors.textSub;
  static Color get black        => AppColors.bg;
  static Color get text         => AppColors.text;
  static Color get textSub      => AppColors.textSub;
  static Color get textDim      => AppColors.textHint;
  static Color get textDark     => AppColors.textHint;

  static Color get green     => AppColors.green;
  static Color get amber     => AppColors.amber;
  static Color get red       => AppColors.red;
  static Color get grey      => AppColors.accent;
  static Color get greyMid   => AppColors.accentMid;
  static Color get greyLight => AppColors.accentLight;
  static Color get greyDark  => AppColors.accentDark;

  static LinearGradient get glassGrad    => AppColors.glassGrad;
  static List<BoxShadow> get softShadow  => AppColors.softShadow;
  static List<BoxShadow> get glowShadow  => ThemeModeManager.isComic3d
      ? AppColors.softShadow
      : [
          BoxShadow(
            color: AppColors.accentMid.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ];
  static LinearGradient get btnGrad      => AppColors.btnGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ────────────────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadProfileImage();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    final isComic = ThemeModeManager.isComic3d;
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => ClipRRect(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(isComic ? 6 : 20),
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: isComic ? 0 : 15,
            sigmaY: isComic ? 0 : 15,
          ),
          child: Container(
            decoration: BoxDecoration(
              gradient: isComic ? null : _C.glassGrad,
              color: isComic ? AppColors.card : null,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(isComic ? 6 : 20),
              ),
              border: Border.all(
                color: _C.glassBorder,
                width: AppColors.borderWidth,
              ),
              boxShadow: _C.glassShadow,
            ),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 40, height: 4,
                    decoration: BoxDecoration(
                      color: _C.whiteDim.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Container(
                      width: 4, height: 18,
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'PILIH GAMBAR',
                      style: TextStyle(
                        color: _C.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                        fontFamily: kFont,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _ActionItem(
                  icon: Icons.camera_alt,
                  color: _C.primary,
                  title: 'Kamera',
                  subtitle: 'Ambil foto dari kamera',
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.camera);
                  },
                ),
                const SizedBox(height: 10),
                _ActionItem(
                  icon: Icons.photo_library,
                  color: _C.secondary,
                  title: 'Galeri',
                  subtitle: 'Pilih dari galeri',
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.gallery);
                  },
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
          source: source, imageQuality: 70);
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
            'profile_image_${widget.username}', imageFile.path);
        setState(() => _profileImage = imageFile);
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    // ⚡ AUTO REBUILD SAAT TEMA GANTI
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const SizedBox(height: 40),
                  Center(
                    child: GestureDetector(
                      onTap: _showImageSourceDialog,
                      child: Stack(
                        children: [
                          Container(
                            width: 120, height: 120,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: _C.btnGrad,
                              border: ThemeModeManager.isComic3d
                                  ? Border.all(
                                      color: AppColors.border, width: 3)
                                  : null,
                              boxShadow: _C.glowShadow,
                            ),
                            child: ClipOval(
                              child: _profileImage != null
                                  ? Image.file(_profileImage!,
                                      fit: BoxFit.cover)
                                  : Icon(
                                      Icons.person_rounded,
                                      size: 50,
                                      color: _C.white.withOpacity(0.8),
                                    ),
                            ),
                          ),
                          Positioned(
                            bottom: 0, right: 0,
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                gradient: _C.btnGrad,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: _C.bg,
                                  width: 3,
                                ),
                                boxShadow: _C.softShadow,
                              ),
                              child: Icon(
                                Icons.camera_alt,
                                size: 18,
                                color: _onAccent(),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 15),

                  // USERNAME
                  ThemeModeManager.isComic3d
                      ? Text(
                          widget.username,
                          style: TextStyle(
                            color: _C.primary,
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.5,
                            fontFamily: kFont,
                          ),
                        )
                      : ShaderMask(
                          shaderCallback: (b) => LinearGradient(
                            colors: [_C.white, _C.primaryLight],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ).createShader(b),
                          child: Text(
                            widget.username,
                            style: TextStyle(
                              color: _C.white,
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.5,
                              fontFamily: kFont,
                            ),
                          ),
                        ),
                  const SizedBox(height: 4),

                  // ROLE BADGE
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 4),
                    decoration: BoxDecoration(
                      gradient: _C.btnGrad,
                      borderRadius: BorderRadius.circular(
                          ThemeModeManager.isComic3d ? 4 : 20),
                      border: ThemeModeManager.isComic3d
                          ? Border.all(color: AppColors.border, width: 2)
                          : null,
                    ),
                    child: Text(
                      widget.role.toUpperCase(),
                      style: TextStyle(
                        color: _onAccent(),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.5,
                        fontFamily: kFont,
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),

                  // INFO CARDS
                  Row(
                    children: [
                      Expanded(
                        child: _buildInfoCard(
                          icon: Icons.person_outline,
                          label: "Username",
                          value: _censorText(widget.username),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                        child: _buildInfoCard(
                          icon: Icons.lock_outline,
                          label: "Password",
                          value: _censorText(widget.password, isPassword: true),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  Row(
                    children: [
                      Expanded(
                        child: _buildInfoCard(
                          icon: Icons.verified_user_outlined,
                          label: "Role",
                          value: widget.role.toUpperCase(),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                        child: _buildInfoCard(
                          icon: Icons.calendar_today_outlined,
                          label: "Expired",
                          value: widget.expiredDate,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  _buildInfoCard(
                    icon: Icons.vpn_key,
                    label: "Session Key",
                    value: "${widget.sessionKey.substring(0, 8)}...",
                  ),
                  const SizedBox(height: 40),

                  // CHANGE PASSWORD BUTTON
                  Container(
                    width: double.infinity,
                    height: 55,
                    decoration: BoxDecoration(
                      gradient: _C.btnGrad,
                      borderRadius: BorderRadius.circular(
                          ThemeModeManager.isComic3d ? 6 : 16),
                      border: ThemeModeManager.isComic3d
                          ? Border.all(color: AppColors.border, width: 3)
                          : null,
                      boxShadow: ThemeModeManager.isComic3d
                          ? AppColors.softShadow
                          : [
                              BoxShadow(
                                color: _C.primary.withOpacity(0.3),
                                blurRadius: 20,
                                spreadRadius: 2,
                              ),
                            ],
                    ),
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.lock_reset, color: _onAccent()),
                      label: Text(
                        "CHANGE PASSWORD",
                        style: TextStyle(
                          color: _onAccent(),
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1,
                          fontFamily: kFont,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              ThemeModeManager.isComic3d ? 6 : 16),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ChangePasswordPage(
                              username: widget.username,
                              sessionKey: widget.sessionKey,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    final isComic = ThemeModeManager.isComic3d;

    if (isComic) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          border: Border.all(color: AppColors.border, width: 3),
          boxShadow: AppColors.softShadow,
        ),
        child: _infoCardContent(icon: icon, label: label, value: value),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
          decoration: BoxDecoration(
            gradient: _C.glassGrad,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(color: _C.glassBorder, width: 0.5),
            boxShadow: _C.softShadow,
          ),
          child: _infoCardContent(icon: icon, label: label, value: value),
        ),
      ),
    );
  }

  Widget _infoCardContent({
    required IconData icon,
    required String label,
    required String value,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                gradient: isComic
                    ? LinearGradient(
                        colors: [
                          _C.primary,
                          _C.primary.withOpacity(0.7),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : LinearGradient(
                        colors: [
                          _C.primary.withOpacity(0.15),
                          _C.primaryDark.withOpacity(0.05),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                borderRadius: BorderRadius.circular(isComic ? 3 : 8),
                border: isComic
                    ? Border.all(color: AppColors.border, width: 2)
                    : null,
              ),
              child: Icon(
                icon,
                color: isComic ? const Color(0xFF1A1A1A) : _C.primary,
                size: 16,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  color: _C.textDim,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                  fontFamily: kFont,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            color: _C.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            fontFamily: kFont,
          ),
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
        ),
      ],
    );
  }
}

// ─── ACTION ITEM WIDGET ────────────────────────────────────────────────
class _ActionItem extends StatefulWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  State<_ActionItem> createState() => _ActionItemState();
}

class _ActionItemState extends State<_ActionItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    if (isComic) {
      return GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) {
          setState(() => _pressed = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? 0.97 : 1.0,
          duration: const Duration(milliseconds: 130),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(color: AppColors.border, width: 3),
              boxShadow: AppColors.softShadow,
            ),
            child: _actionContent(),
          ),
        ),
      );
    }

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: _pressed
                    ? LinearGradient(
                        colors: [
                          widget.color.withOpacity(0.08),
                          Colors.transparent,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : _C.glassGrad,
                borderRadius: BorderRadius.circular(AppColors.cardRadius),
                border: Border.all(
                  color: _pressed
                      ? widget.color.withOpacity(0.2)
                      : _C.glassBorder,
                  width: 0.5,
                ),
                boxShadow: _pressed
                    ? [
                        BoxShadow(
                          color: widget.color.withOpacity(0.05),
                          blurRadius: 15,
                        ),
                      ]
                    : _C.softShadow,
              ),
              child: _actionContent(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _actionContent() {
    final isComic = ThemeModeManager.isComic3d;
    return Row(
      children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            gradient: isComic
                ? LinearGradient(
                    colors: [
                      widget.color,
                      widget.color.withOpacity(0.7),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(
                    colors: [
                      widget.color.withOpacity(0.1),
                      widget.color.withOpacity(0.02),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(isComic ? 4 : 10),
            border: isComic
                ? Border.all(color: AppColors.border, width: 2)
                : null,
          ),
          child: Icon(
            widget.icon,
            color: isComic ? const Color(0xFF1A1A1A) : widget.color,
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.title,
                style: TextStyle(
                  color: _C.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: kFont,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                widget.subtitle,
                style: TextStyle(
                  color: _C.textDim,
                  fontSize: 11,
                  fontFamily: kFont,
                ),
              ),
            ],
          ),
        ),
        Icon(
          Icons.arrow_forward_ios_rounded,
          size: 14,
          color: _C.textDim,
        ),
      ],
    );
  }
}