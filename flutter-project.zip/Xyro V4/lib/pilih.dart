// pilih.dart
import 'package:flutter/material.dart';

import 'theme.dart';
import 'custom.dart';
import 'home_page.dart';
import 'tes_func_page.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

class PilihPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final String expiredDate;
  final String password;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;

  const PilihPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.password,
    required this.listBug,
    required this.listDoos,
  });

  @override
  State<PilihPage> createState() => _PilihPageState();
}

class _PilihPageState extends State<PilihPage>
    with TickerProviderStateMixin {
  late final PageController _pageController;
  late final AnimationController _introController;
  late final AnimationController _pulseController;

  double _page = 0;
  bool _navigated = false;

  Color get bg       => AppColors.bg;
  Color get card     => AppColors.card;
  Color get border   => AppColors.border;
  Color get accent   => AppColors.accent;
  Color get text     => AppColors.text;
  Color get textSub  => AppColors.textSub;
  Color get textDim  => AppColors.textHint;

  late final List<_ModeCard> _modes = [
    // ═══════════ KARTU 1 — WhatsApp Bug ═══════════
    _ModeCard(
      badge: 'MODE 1',
      title: 'WHATSAPP BUG',
      subtitle: 'Kirim 1x bug • All Func gacor • Cepat & stabil',
      bullets: const [
        'Kirim 1x bug sekali tap',
        'Semua fungsi gacor',
        'Respons cepat tanpa delay',
      ],
      icon: Icons.chat_bubble_rounded,
      actionLabel: 'BUKA WHATSAPP BUG',
    ),

    // ═══════════ KARTU 2 — Custom Bug ═══════════
    _ModeCard(
      badge: 'MODE 2',
      title: 'CUSTOM BUG',
      subtitle: 'Pilih bug lebih dari 1 • Cepat • Gacor',
      bullets: const [
        'Multi-bug sekaligus (custom)',
        'Atur urutan sesuai keinginan',
        'Delay & repeat bisa diatur',
      ],
      icon: Icons.auto_awesome_rounded,
      actionLabel: 'BUKA CUSTOM BUG',
    ),

    // ═══════════ KARTU 3 — Test Func ═══════════
    _ModeCard(
      badge: 'MODE 3',
      title: 'TEST FUNC',
      subtitle: 'Kirim custom function • JS Support • Gacor',
      bullets: const [
        'Upload file .js',
        'Atur delay & loops',
        'Riwayat otomatis',
      ],
      icon: Icons.code_rounded,
      actionLabel: 'BUKA TEST FUNC',
    ),
  ];

  @override
  void initState() {
    super.initState();

    _pageController = PageController()
      ..addListener(() {
        setState(() => _page = _pageController.page ?? 0);
      });

    _introController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..forward();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pageController.dispose();
    _introController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  int get _currentIndex =>
      _page.round().clamp(0, _modes.length - 1);

  // ═══════════════════════════════════════════════════════════════════
  //  ✅ BUKA MODE — sekarang dipanggil dari tombol LANJUT
  // ═══════════════════════════════════════════════════════════════════
  void _openMode(int index) {
    if (_navigated) return;
    _navigated = true;

    Widget target;

    if (index == 0) {
      // ── WhatsApp Bug ──
      target = HomePage(
        username: widget.username,
        password: widget.password,
        listBug: widget.listBug,
        role: widget.role,
        expiredDate: widget.expiredDate,
        sessionKey: widget.sessionKey,
      );
    } else if (index == 1) {
      // ── Custom Bug ──
      target = CustomPayloadPage(
        sessionKey: widget.sessionKey,
        username: widget.username,
        role: widget.role,
        listBug: widget.listBug,
      );
    } else {
      // ── Test Func ──
      target = TesFuncPage(
        sessionKey: widget.sessionKey,
        username: widget.username,
        role: widget.role,
      );
    }

    Navigator.of(context).push(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 650),
        pageBuilder: (_, __, ___) => target,
        transitionsBuilder: (_, anim, __, child) {
          final curved = CurvedAnimation(
            parent: anim,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curved,
            child: ScaleTransition(
              scale: Tween(begin: 0.97, end: 1.0).animate(curved),
              child: child,
            ),
          );
        },
      ),
    ).then((_) {
      if (mounted) _navigated = false;
    });
  }

  Animation<double> _staggered(double start, double end) {
    return CurvedAnimation(
      parent: _introController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        final isComic = ThemeModeManager.isComic3d;
        final topFade    = _staggered(0.15, 0.65);
        final cardFade   = _staggered(0.30, 0.85);
        final bottomFade = _staggered(0.45, 1.0);

        return Scaffold(
          backgroundColor: bg,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ── HEADER ──
                  FadeTransition(
                    opacity: topFade,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, -0.3),
                        end: Offset.zero,
                      ).animate(topFade),
                      child: Padding(
                        padding:
                            const EdgeInsets.fromLTRB(16, 12, 16, 0),
                        child: Row(
                          children: [
                            Container(
                              width: 42, height: 42,
                              decoration: BoxDecoration(
                                gradient: AppColors.btnGrad,
                                borderRadius: BorderRadius.circular(
                                    isComic ? 4 : 14),
                                border: isComic
                                    ? Border.all(
                                        color: AppColors.border,
                                        width: 2)
                                    : null,
                              ),
                              child: Icon(
                                Icons.bolt_rounded,
                                color: isComic
                                    ? const Color(0xFF1A1A1A)
                                    : Colors.white,
                                size: 22,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              'PILIH MODE',
                              style: TextStyle(
                                color: text,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                fontFamily: kFont,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // ── KARTU MODE (PageView) ──
                  FadeTransition(
                    opacity: cardFade,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, 0.15),
                        end: Offset.zero,
                      ).animate(cardFade),
                      child: SizedBox(
                        height: 320,
                        child: PageView.builder(
                          controller: _pageController,
                          physics: const BouncingScrollPhysics(),
                          itemCount: _modes.length,
                          itemBuilder: (context, index) {
                            final distance =
                                (index - _page).abs().clamp(0.0, 1.0);
                            final scale = 1.0 - (distance * 0.08);
                            final opacity = 1.0 - (distance * 0.6);

                            return Transform.scale(
                              scale: scale,
                              child: Opacity(
                                opacity: opacity.clamp(0.0, 1.0),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  child: _buildModeCard(
                                      _modes[index], index),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ── DOTS INDICATOR ──
                  FadeTransition(
                    opacity: bottomFade,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(_modes.length, (i) {
                        final active = i == _currentIndex;
                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 350),
                          curve: Curves.easeOutCubic,
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: active ? 22 : 7,
                          height: 7,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            color: active
                                ? accent
                                : textDim.withOpacity(0.3),
                            boxShadow: active && !isComic
                                ? [
                                    BoxShadow(
                                      color: accent.withOpacity(0.5),
                                      blurRadius: 6,
                                      spreadRadius: 0.5,
                                    ),
                                  ]
                                : null,
                          ),
                        );
                      }),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ── MINI CARD INDICATOR (nama mode aktif) ──
                  FadeTransition(
                    opacity: bottomFade,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: _buildActiveModeIndicator(isComic),
                    ),
                  ),

                  const Spacer(),

                  // ── TOMBOL BUKA MODE ──
                  FadeTransition(
                    opacity: bottomFade,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                      child: GestureDetector(
                        // ✅ Buka mode yang sedang aktif
                        onTap: () => _openMode(_currentIndex),
                        child: AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            final pulse = _pulseController.value;
                            return AnimatedContainer(
                              duration:
                                  const Duration(milliseconds: 450),
                              curve: Curves.easeOutCubic,
                              width: double.infinity,
                              height: 56,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                borderRadius:
                                    BorderRadius.circular(
                                        isComic ? 4 : 16),
                                gradient: isComic ? null : AppColors.btnGrad,
                                color: isComic ? accent : null,
                                border: isComic
                                    ? Border.all(
                                        color: AppColors.border,
                                        width: 3)
                                    : null,
                                boxShadow: isComic
                                    ? AppColors.softShadow
                                    : [
                                        BoxShadow(
                                          color: accent.withOpacity(
                                              0.25 + 0.10 * pulse),
                                          blurRadius: 14 + 4 * pulse,
                                        ),
                                      ],
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    _modes[_currentIndex].icon,
                                    color: isComic
                                        ? const Color(0xFF1A1A1A)
                                        : Colors.white,
                                    size: 18,
                                  ),
                                  const SizedBox(width: 10),
                                  Text(
                                    _modes[_currentIndex].actionLabel,
                                    style: TextStyle(
                                      fontFamily: kFont,
                                      color: isComic
                                          ? const Color(0xFF1A1A1A)
                                          : Colors.white,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 1.2,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Icon(
                                    Icons.arrow_forward_rounded,
                                    color: isComic
                                        ? const Color(0xFF1A1A1A)
                                        : Colors.white,
                                    size: 18,
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  MINI CARD INDICATOR (nama mode aktif — di atas tombol)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildActiveModeIndicator(bool isComic) {
    final mode = _modes[_currentIndex];
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      transitionBuilder: (child, anim) => FadeTransition(
        opacity: anim,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.15),
            end: Offset.zero,
          ).animate(anim),
          child: child,
        ),
      ),
      child: Container(
        key: ValueKey(_currentIndex), // trigger AnimatedSwitcher tiap ganti mode
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          gradient: isComic ? null : AppColors.glassGrad,
          color: isComic ? card : null,
          borderRadius: BorderRadius.circular(isComic ? 4 : 12),
          border: Border.all(
            color: isComic ? AppColors.border : AppColors.glassBorder,
            width: AppColors.borderWidth,
          ),
          boxShadow: isComic
              ? AppColors.softShadow
              : [
                  BoxShadow(
                    color: accent.withOpacity(0.1),
                    blurRadius: 12,
                  ),
                ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icon mode aktif
            Container(
              width: 26, height: 26,
              decoration: BoxDecoration(
                gradient: isComic ? AppColors.btnGrad : null,
                color: isComic ? null : accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(isComic ? 3 : 7),
                border: Border.all(
                  color: accent.withOpacity(0.5),
                  width: isComic ? 2 : 1,
                ),
              ),
              child: Icon(
                mode.icon,
                color: isComic ? const Color(0xFF1A1A1A) : accent,
                size: 13,
              ),
            ),
            const SizedBox(width: 10),

            // Label
            Text(
              'MODE AKTIF  •  ',
              style: TextStyle(
                fontFamily: kFont,
                color: textDim,
                fontSize: 9.5,
                fontWeight: FontWeight.w600,
                letterSpacing: 1,
              ),
            ),
            Text(
              mode.title,
              style: TextStyle(
                fontFamily: kFont,
                color: isComic ? const Color(0xFF1A1A1A) : accent,
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  KARTU MODE
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildModeCard(_ModeCard mode, int index) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTap: () => _openMode(index),
      child: Container(
        padding: const EdgeInsets.fromLTRB(22, 18, 22, 20),
        decoration: BoxDecoration(
          gradient: isComic ? null : AppColors.glassGrad,
          color: isComic ? AppColors.card : null,
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          border: Border.all(
            color: isComic ? AppColors.border : AppColors.glassBorder,
            width: AppColors.borderWidth,
          ),
          boxShadow: AppColors.glassShadow,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── GARIS ATAS ──
            Container(
              width: 34, height: 3,
              decoration: BoxDecoration(
                gradient: AppColors.btnGrad,
                borderRadius: BorderRadius.circular(6),
              ),
            ),
            const SizedBox(height: 14),

            // ── ICON + BADGE ──
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    gradient: isComic ? AppColors.btnGrad : null,
                    color: isComic ? null : accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(isComic ? 4 : 10),
                    border: Border.all(
                      color: accent.withOpacity(0.5),
                      width: isComic ? 2 : 1,
                    ),
                  ),
                  child: Icon(
                    mode.icon,
                    color: isComic
                        ? const Color(0xFF1A1A1A)
                        : accent,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(isComic ? 0.3 : 0.12),
                    borderRadius: BorderRadius.circular(isComic ? 4 : 10),
                    border: Border.all(
                      color: accent.withOpacity(0.5),
                      width: isComic ? 2 : 1,
                    ),
                  ),
                  child: Text(
                    mode.badge,
                    style: TextStyle(
                      fontFamily: kFont,
                      color: isComic
                          ? const Color(0xFF1A1A1A)
                          : accent,
                      fontSize: 10,
                      letterSpacing: 1,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // ── JUDUL ──
            Text(
              mode.title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: kFont,
                color: text,
                fontSize: 20,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
                height: 1.3,
              ),
            ),
            const SizedBox(height: 6),

            // ── SUBJUDUL ──
            Text(
              mode.subtitle,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontFamily: kFont,
                color: textSub,
                fontSize: 12,
                height: 1.4,
                letterSpacing: 0.3,
              ),
            ),
            const SizedBox(height: 10),

            // ── BULLET ──
            ...mode.bullets.map(
              (b) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 5),
                      width: 5, height: 5,
                      decoration: BoxDecoration(
                        color: accent,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        b,
                        style: TextStyle(
                          fontFamily: kFont,
                          color: textSub,
                          fontSize: 11.5,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // ── INDIKATOR ──
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: textDim.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                "${index + 1} / ${_modes.length}",
                style: TextStyle(
                  fontFamily: kFont,
                  color: textSub,
                  fontSize: 10.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  MODEL MODE CARD
// ═══════════════════════════════════════════════════════════════════════
class _ModeCard {
  final String badge;
  final String title;
  final String subtitle;
  final List<String> bullets;
  final IconData icon;
  final String actionLabel; // label tombol buka mode

  const _ModeCard({
    required this.badge,
    required this.title,
    required this.subtitle,
    required this.bullets,
    required this.icon,
    required this.actionLabel,
  });
}