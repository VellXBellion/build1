// landing.dart
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import 'theme.dart';
import 'login_page.dart';
import 'buy.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE (LENGKAP + gold fix) ──────────────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;

  static Color get primary      => AppColors.accentMid;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark  => AppColors.accentDark;
  static Color get primaryGlow  => AppColors.accentMid;

  static Color get secondary => AppColors.accent;
  static Color get accent    => AppColors.accentLight;
  static Color get success   => AppColors.green;
  static Color get warning   => AppColors.amber;
  static Color get error     => AppColors.red;
  static Color get pink      => AppColors.pink;
  static Color get orange    => AppColors.amber;
  static Color get purple    => AppColors.purple;

  // ✅ WAJIB: getter gold, silver, bronze biar tidak error
  static Color get gold   => AppColors.gold;
  static Color get silver => AppColors.textSub;
  static Color get bronze => AppColors.accentDark;

  static Color get text     => AppColors.text;
  static Color get textSub  => AppColors.textSub;
  static Color get textDim  => AppColors.textHint;
  static Color get textDark => AppColors.textHint;

  static Color get white     => AppColors.text;
  static Color get whiteSoft => AppColors.textSub;
  static Color get whiteDim  => AppColors.textSub;

  static Color get black     => AppColors.bg;
  static Color get blackSoft => AppColors.dark;

  static Color get glassBg     => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static LinearGradient get btnGrad => AppColors.btnGrad;
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _floatCtrl;
  late AnimationController _textCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _featureCtrl;

  late Animation<double> _glowAnim;
  late Animation<double> _floatAnim;
  late Animation<double> _textFade;
  late Animation<Offset> _textSlide;
  late Animation<double> _btnPulse;
  late Animation<double> _featureFade;
  late Animation<Offset> _featureSlide;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness:
            ThemeModeManager.isComic3d ? Brightness.dark : Brightness.light,
        statusBarBrightness:
            ThemeModeManager.isComic3d ? Brightness.light : Brightness.dark,
      ),
    );
  }

  void _initAnimations() {
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))..repeat();
    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 0.8)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _floatCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 3000))
      ..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: -10, end: 10)
        .animate(CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut));

    _textCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _textFade = CurvedAnimation(parent: _textCtrl, curve: Curves.easeOut);
    _textSlide = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _textCtrl, curve: Curves.easeOutCubic));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600))
      ..repeat(reverse: true);
    _btnPulse = Tween<double>(begin: 1.0, end: 1.04)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));

    _particleCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 5))..repeat();

    _featureCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _featureFade = CurvedAnimation(parent: _featureCtrl, curve: Curves.easeOut);
    _featureSlide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _featureCtrl, curve: Curves.easeOutCubic));

    _textCtrl.forward();
    _featureCtrl.forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _glowCtrl.dispose();
    _floatCtrl.dispose();
    _textCtrl.dispose();
    _btnCtrl.dispose();
    _particleCtrl.dispose();
    _featureCtrl.dispose();
    super.dispose();
  }

  void _openTelegram() async {
    await launchUrl(
      Uri.parse('https://t.me/ameluchuu'),
      mode: LaunchMode.externalApplication,
    );
  }

  void _openBuyPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const BuyPage(
          sessionKey: 'guest',
          username: 'guest',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        final size = MediaQuery.of(context).size;

        return Scaffold(
          backgroundColor: _C.bg,
          body: Stack(
            children: [
              // Particle layer
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: _particleCtrl,
                  builder: (_, __) => CustomPaint(
                    painter: _LandingParticlePainter(_particleCtrl.value),
                    size: size,
                  ),
                ),
              ),

              // Grid + glow layer
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: _bgCtrl,
                  builder: (_, __) => CustomPaint(
                    painter: _LandingBgPainter(_bgCtrl.value),
                    size: size,
                  ),
                ),
              ),

              // Background image (Normal mode)
              if (ThemeModeManager.isNormal)
                Positioned.fill(
                  child: Opacity(
                    opacity: 0.25,
                    child: Image.asset(
                      'assets/images/mmk.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                    ),
                  ),
                ),

              // Overlay gelap
              if (!ThemeModeManager.isComic3d)
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          _C.bg.withOpacity(0.55),
                          _C.bg.withOpacity(0.70),
                          _C.bg.withOpacity(0.92),
                        ],
                      ),
                    ),
                  ),
                ),

              SafeArea(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    children: [
                      _buildNavBar(),
                      const SizedBox(height: 20),
                      _buildHeroSection(size),

                      // ✅ BELI AKSES SECTION
                      const SizedBox(height: 30),
                      _buildBeliAksesSection(),

                      const SizedBox(height: 30),
                      _buildStatsSection(),
                      const SizedBox(height: 30),
                      _buildTestimonialsSection(),
                      const SizedBox(height: 30),
                      _buildCTASection(),
                      const SizedBox(height: 20),
                      _buildFooter(),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildNavBar() {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              gradient: _C.btnGrad,
              borderRadius: BorderRadius.circular(isComic ? 4 : 8),
              border: isComic
                  ? Border.all(color: AppColors.border, width: 2)
                  : null,
              boxShadow: isComic
                  ? null
                  : [
                      BoxShadow(
                        color: _C.primary.withOpacity(0.3),
                        blurRadius: 16,
                      ),
                    ],
            ),
            child: Center(
              child: Text(
                'X',
                style: TextStyle(
                  color: _onAccent(),
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.5,
                  fontFamily: kFont,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          isComic
              ? Text(
                  'XENCODE',
                  style: TextStyle(
                    color: _C.primary,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                    fontFamily: kFont,
                  ),
                )
              : ShaderMask(
                  shaderCallback: (b) => LinearGradient(
                    colors: [_C.primary, _C.primaryLight],
                  ).createShader(b),
                  child: Text(
                    'XENCODE',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.3,
                      fontFamily: kFont,
                    ),
                  ),
                ),
          const Spacer(),
          _GlassButton(
            label: 'Login',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const LoginPage()),
            ),
            isPrimary: false,
          ),
        ],
      ),
    );
  }

  Widget _buildHeroSection(Size size) {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: FadeTransition(
        opacity: _textFade,
        child: SlideTransition(
          position: _textSlide,
          child: Column(
            children: [
              AnimatedBuilder(
                animation: _glowAnim,
                builder: (_, __) => Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: _C.primary.withOpacity(
                        isComic ? 1.0 : (0.2 + _glowAnim.value * 0.2),
                      ),
                      width: isComic ? 2 : 1,
                    ),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    'NEXT GENERATION SECURITY',
                    style: TextStyle(
                      color: isComic
                          ? const Color(0xFF1A1A1A)
                          : _C.primaryLight,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                      fontFamily: kFont,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              isComic
                  ? Text(
                      'Secure Your Digital\nWorld With XENCODE',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 38,
                        fontWeight: FontWeight.w900,
                        color: _C.text,
                        height: 1.1,
                        letterSpacing: -0.5,
                        fontFamily: kFont,
                      ),
                    )
                  : ShaderMask(
                      shaderCallback: (b) => LinearGradient(
                        colors: [_C.white, _C.primaryLight],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(b),
                      child: Text(
                        'Secure Your Digital\nWorld With XENCODE',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 38,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          height: 1.1,
                          letterSpacing: -0.5,
                          fontFamily: kFont,
                        ),
                      ),
                    ),
              const SizedBox(height: 16),
              Text(
                'Advanced security suite with DDoS protection,\nOSINT tools, and real-time monitoring for\nyour digital assets.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 14,
                  height: 1.6,
                  letterSpacing: 0.2,
                  fontFamily: kFont,
                ),
              ),
              const SizedBox(height: 32),
              AnimatedBuilder(
                animation: _btnPulse,
                builder: (_, __) => Transform.scale(
                  scale: _btnPulse.value,
                  child: GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                    ),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 40,
                        vertical: 16,
                      ),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(isComic ? 4 : 8),
                        border: isComic
                            ? Border.all(color: AppColors.border, width: 3)
                            : null,
                        boxShadow: isComic
                            ? AppColors.glassShadow
                            : [
                                BoxShadow(
                                  color: _C.primary.withOpacity(0.3),
                                  blurRadius: 20,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'Get Started',
                            style: TextStyle(
                              color: _onAccent(),
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                              fontFamily: kFont,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Icon(
                            Icons.arrow_forward_rounded,
                            color: _onAccent(),
                            size: 18,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              AnimatedBuilder(
                animation: _floatCtrl,
                builder: (_, __) => Transform.translate(
                  offset: Offset(0, _floatAnim.value),
                  child: _GlassCard(
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          top: 20, right: 30,
                          child: Container(
                            width: 60, height: 60,
                            decoration: BoxDecoration(
                              color: _C.primary.withOpacity(0.05),
                              border: Border.all(
                                color: _C.primary.withOpacity(0.1),
                              ),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 30, left: 20,
                          child: Container(
                            width: 80, height: 80,
                            decoration: BoxDecoration(
                              color: _C.primaryDark.withOpacity(0.05),
                              border: Border.all(
                                color: _C.primaryDark.withOpacity(0.1),
                              ),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.shield_rounded,
                              color: isComic ? _C.primary : _C.accent,
                              size: 48,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'Ready to Deploy',
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                fontFamily: kFont,
                              ),
                            ),
                            Text(
                              'Enterprise-grade security',
                              style: TextStyle(
                                color: _C.textSub,
                                fontSize: 12,
                                fontFamily: kFont,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BELI AKSES SECTION
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBeliAksesSection() {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: FadeTransition(
        opacity: _featureFade,
        child: SlideTransition(
          position: _featureSlide,
          child: _GlassCard(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 4, height: 20,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [_C.primary, _C.primaryDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'BELI AKSES',
                      style: TextStyle(
                        color: _C.primaryLight,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2,
                        fontFamily: kFont,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: _C.primary.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(isComic ? 3 : 10),
                        border: Border.all(
                          color: _C.primary.withOpacity(0.3),
                          width: AppColors.borderWidth,
                        ),
                      ),
                      child: Text(
                        'AUTO',
                        style: TextStyle(
                          color: isComic
                              ? const Color(0xFF1A1A1A)
                              : _C.primaryLight,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: kFont,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Dapatkan akses premium otomatis via QRIS.\nBayar sekali, akun langsung dibuat.',
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 12,
                    height: 1.5,
                    fontFamily: kFont,
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _buildHargaChip('Member', 'Rp2k', _C.accent),
                    _buildHargaChip('Reseller', 'Rp35k', _C.pink),
                    _buildHargaChip('VIP', 'Rp40k', _C.orange),
                    _buildHargaChip('Admin', 'Rp45k', _C.purple),
                    _buildHargaChip('Owner', 'Rp60k', _C.gold),
                  ],
                ),
                const SizedBox(height: 20),
                AnimatedBuilder(
                  animation: _btnPulse,
                  builder: (_, __) => Transform.scale(
                    scale: _btnPulse.value,
                    child: GestureDetector(
                      onTap: _openBuyPage,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 16,
                        ),
                        decoration: BoxDecoration(
                          gradient: _C.btnGrad,
                          borderRadius:
                              BorderRadius.circular(isComic ? 4 : 10),
                          border: isComic
                              ? Border.all(
                                  color: AppColors.border, width: 3)
                              : null,
                          boxShadow: isComic
                              ? AppColors.glassShadow
                              : [
                                  BoxShadow(
                                    color: _C.primary.withOpacity(0.35),
                                    blurRadius: 20,
                                    offset: const Offset(0, 6),
                                  ),
                                ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.shopping_cart_rounded,
                              color: _onAccent(),
                              size: 20,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'BELI AKSES SEKARANG',
                              style: TextStyle(
                                color: _onAccent(),
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.5,
                                fontFamily: kFont,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Icon(
                              Icons.arrow_forward_rounded,
                              color: _onAccent(),
                              size: 18,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Icon(Icons.qr_code_2_rounded,
                        color: _C.textDim, size: 14),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'Pembayaran QRIS • Akun otomatis dibuat setelah bayar',
                        style: TextStyle(
                          color: _C.textDim,
                          fontSize: 10,
                          fontFamily: kFont,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHargaChip(String label, String harga, Color color) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(isComic ? 0.3 : 0.12),
        borderRadius: BorderRadius.circular(isComic ? 3 : 8),
        border: Border.all(
          color: color.withOpacity(0.5),
          width: isComic ? 2 : 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: TextStyle(
              color: isComic ? const Color(0xFF1A1A1A) : color,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              fontFamily: kFont,
            ),
          ),
          const SizedBox(width: 6),
          Container(
            width: 3, height: 3,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isComic ? const Color(0xFF1A1A1A) : color,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            harga,
            style: TextStyle(
              color: isComic ? const Color(0xFF1A1A1A) : color,
              fontSize: 10,
              fontWeight: FontWeight.w900,
              fontFamily: kFont,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: _GlassCard(
        padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _StatItem(
              value: '99.9%',
              label: 'Uptime',
              icon: Icons.timer_rounded,
            ),
            _StatDivider(),
            _StatItem(
              value: '10K+',
              label: 'Users',
              icon: Icons.people_rounded,
            ),
            _StatDivider(),
            _StatItem(
              value: '24/7',
              label: 'Support',
              icon: Icons.support_agent_rounded,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTestimonialsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 4, height: 20,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.primary, _C.primaryDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                'TESTIMONIALS',
                style: TextStyle(
                  color: _C.primaryLight,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                  fontFamily: kFont,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: [
                _TestimonialCard(
                  quote:
                      '"XENCODE has been a game-changer for our security infrastructure."',
                  name: 'John Doe',
                  role: 'CTO, TechCorp',
                ),
                const SizedBox(width: 14),
                _TestimonialCard(
                  quote:
                      '"The DDoS protection is unmatched in the industry."',
                  name: 'Jane Smith',
                  role: 'Security Lead, CyberGuard',
                ),
                const SizedBox(width: 14),
                _TestimonialCard(
                  quote: '"Real-time monitoring gave us peace of mind."',
                  name: 'Mike Johnson',
                  role: 'DevOps, CloudNet',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCTASection() {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: _GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
        child: Column(
          children: [
            Icon(
              Icons.rocket_launch_rounded,
              color: isComic ? _C.primary : _C.accent,
              size: 36,
            ),
            const SizedBox(height: 14),
            Text(
              'Ready to Get Started?',
              style: TextStyle(
                color: _C.text,
                fontSize: 20,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.3,
                fontFamily: kFont,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Join thousands of users securing their digital assets.',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 13,
                letterSpacing: 0.2,
                fontFamily: kFont,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _GlassButton(
                  label: 'Get Started',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                  ),
                  isPrimary: true,
                ),
                const SizedBox(width: 12),
                _GlassButton(
                  label: 'Contact',
                  onTap: _openTelegram,
                  isPrimary: false,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Container(
            height: 1,
            color: _C.border.withOpacity(0.3),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '© 2026 XENCODE APPS',
                style: TextStyle(
                  color: _C.textDim,
                  fontSize: 12,
                  letterSpacing: 0.3,
                  fontFamily: kFont,
                ),
              ),
              Container(
                width: 4, height: 4,
                margin: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.primaryDark,
                ),
              ),
              GestureDetector(
                onTap: _openTelegram,
                child: Text(
                  'Contact Us',
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 12,
                    letterSpacing: 0.3,
                    fontFamily: kFont,
                  ),
                ),
              ),
              Container(
                width: 4, height: 4,
                margin: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.primaryDark,
                ),
              ),
              Text(
                'v2.0.0',
                style: TextStyle(
                  color: _C.textDim,
                  fontSize: 12,
                  letterSpacing: 0.3,
                  fontFamily: kFont,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  GLASS CARD
// ═══════════════════════════════════════════════════════════════════════
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;

  const _GlassCard({
    required this.child,
    this.padding = const EdgeInsets.all(16),
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          border: Border.all(color: AppColors.border, width: 3),
          boxShadow: AppColors.glassShadow,
        ),
        child: child,
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: _C.glassBg,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _C.glassBorder,
              width: 0.8,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 30,
                offset: const Offset(0, 8),
              ),
              BoxShadow(
                color: _C.primary.withOpacity(0.02),
                blurRadius: 60,
                offset: const Offset(0, -4),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  WIDGETS
// ═══════════════════════════════════════════════════════════════════════
class _StatItem extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;

  const _StatItem({
    required this.value,
    required this.label,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: _C.primaryLight, size: 24),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            color: _C.white,
            fontSize: 24,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.5,
            fontFamily: kFont,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: _C.textSub,
            fontSize: 12,
            fontWeight: FontWeight.w500,
            fontFamily: kFont,
          ),
        ),
      ],
    );
  }
}

class _StatDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: 50,
      color: _C.border.withOpacity(0.3),
    );
  }
}

class _TestimonialCard extends StatelessWidget {
  final String quote;
  final String name;
  final String role;

  const _TestimonialCard({
    required this.quote,
    required this.name,
    required this.role,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    if (isComic) {
      return Container(
        width: 280,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          border: Border.all(color: AppColors.border, width: 3),
          boxShadow: AppColors.glassShadow,
        ),
        child: _content(),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          width: 280,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: _C.glassBg,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _C.glassBorder,
              width: 0.8,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.12),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: _content(),
        ),
      ),
    );
  }

  Widget _content() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: List.generate(
            5,
            (i) => const Icon(
              Icons.star_rounded,
              color: Color(0xFFFFB300),
              size: 16,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          quote,
          style: TextStyle(
            color: _C.white,
            fontSize: 13,
            height: 1.5,
            fontStyle: FontStyle.italic,
            fontFamily: kFont,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.primary.withOpacity(0.3),
                border: ThemeModeManager.isComic3d
                    ? Border.all(color: AppColors.border, width: 2)
                    : null,
              ),
              child: Center(
                child: Text(
                  name[0],
                  style: TextStyle(
                    color: ThemeModeManager.isComic3d
                        ? const Color(0xFF1A1A1A)
                        : _C.primaryLight,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    fontFamily: kFont,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    color: _C.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    fontFamily: kFont,
                  ),
                ),
                Text(
                  role,
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 10,
                    fontFamily: kFont,
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }
}

class _GlassButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool isPrimary;

  const _GlassButton({
    required this.label,
    required this.onTap,
    required this.isPrimary,
  });

  @override
  State<_GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<_GlassButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            gradient: widget.isPrimary
                ? _C.btnGrad
                : (isComic
                    ? null
                    : LinearGradient(
                        colors: [
                          Colors.transparent,
                          _C.card.withOpacity(0.6),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )),
            color: !widget.isPrimary && isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(isComic ? 4 : 8),
            border: widget.isPrimary
                ? (isComic
                    ? Border.all(color: AppColors.border, width: 3)
                    : null)
                : Border.all(
                    color: isComic
                        ? AppColors.border
                        : _C.border.withOpacity(0.3),
                    width: isComic ? 3 : 0.8,
                  ),
            boxShadow: widget.isPrimary && !isComic
                ? [
                    BoxShadow(
                      color: _C.primary.withOpacity(0.3),
                      blurRadius: 16,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : (isComic ? AppColors.softShadow : null),
          ),
          child: Text(
            widget.label,
            style: TextStyle(
              color: widget.isPrimary ? _onAccent() : _C.white,
              fontSize: 13,
              fontWeight:
                  widget.isPrimary ? FontWeight.w700 : FontWeight.w600,
              letterSpacing: 0.3,
              fontFamily: kFont,
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  BACKGROUND PAINTERS
// ═══════════════════════════════════════════════════════════════════════
class _LandingParticlePainter extends CustomPainter {
  final double t;
  _LandingParticlePainter(this.t);

  static final _rand = math.Random(42);
  static final _particles = List.generate(
      40,
      (i) => _LandingParticle(
            x: _rand.nextDouble(),
            y: _rand.nextDouble(),
            size: 0.5 + _rand.nextDouble() * 1.5,
            speed: 0.02 + _rand.nextDouble() * 0.06,
            phase: _rand.nextDouble(),
            opacity: 0.1 + _rand.nextDouble() * 0.2,
          ));

  @override
  void paint(Canvas canvas, Size size) {
    if (ThemeModeManager.isComic3d) return;
    for (final p in _particles) {
      final px = p.x * size.width;
      final rawY = p.y + (t * p.speed) % 1.0;
      final py = (rawY % 1.0) * size.height;
      final drift = math.sin((t + p.phase) * math.pi * 2) * 4;
      final osc = math.sin((t * 2 + p.phase) * math.pi);
      final opacity = p.opacity * (0.5 + osc * 0.5);

      canvas.drawCircle(
        Offset(px + drift, py),
        p.size,
        Paint()..color = _C.primaryLight.withOpacity(opacity),
      );
    }
  }

  @override
  bool shouldRepaint(_LandingParticlePainter old) => old.t != t;
}

class _LandingBgPainter extends CustomPainter {
  final double t;
  _LandingBgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final isComic = ThemeModeManager.isComic3d;

    final grid = Paint()
      ..color = (isComic ? AppColors.border : _C.border)
          .withOpacity(isComic ? 0.10 : 0.06)
      ..strokeWidth = isComic ? 1 : 0.5;
    const step = 50.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    if (isComic) return;

    final glow1 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.primary.withOpacity(0.04 + math.sin(t * math.pi * 2) * 0.02),
          Colors.transparent,
        ],
        radius: 0.8,
      ).createShader(
        Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width),
      );
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow1);

    final glow2 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.primaryDark
              .withOpacity(0.03 + math.sin(t * math.pi * 2 + 1) * 0.015),
          Colors.transparent,
        ],
        radius: 0.6,
      ).createShader(
        Rect.fromCircle(
          center: Offset(size.width * 0.3, size.height),
          radius: size.width * 0.5,
        ),
      );
    canvas.drawCircle(
      Offset(size.width * 0.3, size.height),
      size.width * 0.5,
      glow2,
    );
  }

  @override
  bool shouldRepaint(_LandingBgPainter old) => old.t != t;
}

class _LandingParticle {
  final double x, y, size, speed, phase, opacity;
  const _LandingParticle({
    required this.x,
    required this.y,
    required this.size,
    required this.speed,
    required this.phase,
    required this.opacity,
  });
}