// admin_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'theme.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE (alias ke AppColors dinamis — LENGKAP) ────────────────────
class _C {
  // ── BACKGROUND ──
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get card2     => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get glassBg   => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  // ── PRIMARY ──
  static Color get primary      => AppColors.accent;
  static Color get primaryMid   => AppColors.accentMid;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark  => AppColors.accentDark;
  static Color get primaryGlow  => AppColors.accentMid;

  // ── SECONDARY / ACCENT ──
  static Color get secondary => AppColors.accentLight;
  static Color get accent    => AppColors.accentLight;

  // ── STATUS ──
  static Color get success => AppColors.green;
  static Color get warning => AppColors.amber;
  static Color get error   => AppColors.red;

  // ── COLORS ──
  static Color get red    => AppColors.red;
  static Color get green  => AppColors.green;
  static Color get amber  => AppColors.amber;
  static Color get gold   => AppColors.gold;
  static Color get pink   => AppColors.pink;
  static Color get purple => AppColors.purple;
  static Color get teal   => AppColors.teal;

  // ── GREY / LEGACY ──
  static Color get grey      => AppColors.accent;
  static Color get greyMid   => AppColors.accentMid;
  static Color get greyLight => AppColors.accentLight;
  static Color get greyDark  => AppColors.accentDark;

  // ── TEXT ──
  static Color get text     => AppColors.text;
  static Color get textSub  => AppColors.textSub;
  static Color get textDim  => AppColors.textHint;

  // ── WHITE / BLACK ──
  static Color get white => AppColors.text;
  static Color get black => AppColors.bg;

  // ── GRADIENT ──
  static LinearGradient get btnGrad   => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;

  // ── SHADOW ──
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow  => AppColors.softShadow;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ────────────────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({super.key, required this.sessionKey});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage>
    with TickerProviderStateMixin {
  int _navIndex = 0;
  late String sessionKey;

  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['reseller', 'vip', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  @override
  void dispose() {
    deleteController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  // ─── API ─────────────────────────────────────────────────────────────
  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
            'http://digital.mypanelku.web.id:2041/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert('Error', data['message'] ?? 'Tidak diizinkan.', isError: true);
      }
    } catch (_) {
      _alert('Koneksi Gagal', 'Tidak dapat menghubungi server.', isError: true);
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert('Perhatian', 'Masukkan username yang ingin dihapus.',
          isError: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          'http://digital.mypanelku.web.id:2041/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert('Berhasil', "User '${data['user']['username']}' telah dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert('Gagal', data['message'] ?? 'Gagal menghapus user.',
            isError: true);
      }
    } catch (_) {
      _alert('Error', 'Tidak dapat menghubungi server.', isError: true);
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _alert('Perhatian', 'Semua field wajib diisi.', isError: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          'http://digital.mypanelku.web.id:2041/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$newUserRole'));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert('Sukses', "Akun '${data['user']['username']}' berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() => newUserRole = 'member');
        _fetchUsers();
      } else {
        _alert('Gagal', data['message'] ?? 'Gagal membuat akun.',
            isError: true);
      }
    } catch (_) {
      _alert('Error', 'Gagal menghubungi server.', isError: true);
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final username = editUsernameController.text.trim();
    final day = editDayController.text.trim();

    if (username.isEmpty || day.isEmpty) {
      _alert('Perhatian', 'Semua field wajib diisi.', isError: true);
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          'http://digital.mypanelku.web.id:2041/editUser?key=$sessionKey&username=$username&addDays=$day'));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert('Sukses', "Durasi user '$username' berhasil diperpanjang.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert('Gagal', data['message'] ?? 'Gagal memperpanjang durasi.',
            isError: true);
      }
    } catch (_) {
      _alert('Error', 'Gagal menghubungi server.', isError: true);
    }
    setState(() => isLoading = false);
  }

  // ─── Dialog ──────────────────────────────────────────────────────────
  void _alert(String title, String message, {bool isError = false}) {
    final isComic = ThemeModeManager.isComic3d;
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 300),
      transitionBuilder: (ctx, anim, _, child) {
        return ScaleTransition(
          scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
          child: FadeTransition(opacity: anim, child: child),
        );
      },
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 360),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                  color: isError
                      ? _C.red.withOpacity(0.5)
                      : _C.primaryLight.withOpacity(0.5),
                  width: isComic ? 3 : 1.5,
                ),
                boxShadow: isComic
                    ? AppColors.glassShadow
                    : [
                        BoxShadow(
                          color: (isError ? _C.red : _C.primaryLight)
                              .withOpacity(0.15),
                          blurRadius: 40,
                        ),
                      ],
              ),
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 52, height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: (isError ? _C.red : _C.primaryLight)
                          .withOpacity(0.12),
                    ),
                    child: Icon(
                      isError
                          ? Icons.warning_amber_rounded
                          : Icons.check_circle_outline,
                      color: isError ? _C.red : _C.primaryLight,
                      size: 26,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(title,
                      style: TextStyle(
                        color: _C.text,
                        fontSize: 18,
                        fontFamily: kFont,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      )),
                  const SizedBox(height: 10),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 14,
                          height: 1.5)),
                  const SizedBox(height: 24),
                  _buildButton(
                    label: 'OK',
                    onTap: () => Navigator.pop(ctx),
                    isDestructive: false,
                    fullWidth: true,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<bool?> _confirmDelete(String username) {
    final isComic = ThemeModeManager.isComic3d;
    return showGeneralDialog<bool>(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 280),
      transitionBuilder: (ctx, anim, _, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 360),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                  color: _C.red.withOpacity(0.4),
                  width: isComic ? 3 : 1.5,
                ),
                boxShadow: isComic
                    ? AppColors.glassShadow
                    : [
                        BoxShadow(
                          color: _C.red.withOpacity(0.12),
                          blurRadius: 40,
                        ),
                      ],
              ),
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 52, height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.red.withOpacity(0.12),
                    ),
                    // ✅ HAPUS const DI SINI
                    child: Icon(Icons.delete_outline_rounded,
                        color: _C.red, size: 26),
                  ),
                  const SizedBox(height: 16),
                  Text('Hapus User',
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 18,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  Text(
                      "Yakin ingin menghapus '$username'?\nTindakan ini tidak bisa dibatalkan.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 14,
                          height: 1.5)),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: _buildButton(
                          label: 'Batal',
                          onTap: () => Navigator.pop(ctx, false),
                          isDestructive: false,
                          isOutline: true,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildButton(
                          label: 'Hapus',
                          onTap: () => Navigator.pop(ctx, true),
                          isDestructive: true,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── Components ─────────────────────────────────────────────────────
  Widget _buildButton({
    required String label,
    required VoidCallback onTap,
    bool isDestructive = false,
    bool isOutline = false,
    bool fullWidth = false,
    IconData? icon,
    bool loading = false,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    final Color baseColor = isDestructive ? _C.red : _C.primaryLight;

    return SizedBox(
      width: fullWidth ? double.infinity : null,
      height: 46,
      child: _PressableButton(
        onTap: loading ? null : onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          decoration: BoxDecoration(
            gradient: isOutline
                ? null
                : LinearGradient(
                    colors: [
                      baseColor.withOpacity(0.85),
                      baseColor.withOpacity(0.6),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            color: isOutline ? Colors.transparent : null,
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            border: isOutline
                ? Border.all(
                    color: _C.border,
                    width: isComic ? 3 : 1.5,
                  )
                : (isComic
                    ? Border.all(color: AppColors.border, width: 2)
                    : null),
            boxShadow: isOutline || isComic
                ? null
                : [
                    BoxShadow(
                      color: baseColor.withOpacity(0.25),
                      blurRadius: 16,
                      offset: const Offset(0, 4),
                    ),
                  ],
          ),
          child: loading
              ? Center(
                  child: SizedBox(
                    width: 18, height: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: _onAccent()),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, size: 16,
                          color: isOutline ? _C.textSub : _onAccent()),
                      const SizedBox(width: 8),
                    ],
                    Text(
                      label,
                      style: TextStyle(
                        color: isOutline ? _C.textSub : _onAccent(),
                        fontFamily: kFont,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    bool obscure = false,
    String hint = '',
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        obscureText: obscure,
        style: TextStyle(
            color: _C.text,
            fontFamily: kFont,
            fontSize: 14,
            fontWeight: FontWeight.w500),
        cursorColor: _C.primaryLight,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(
              color: _C.textDim, fontFamily: kFont, fontSize: 12),
          labelStyle: TextStyle(
              color: _C.textSub, fontFamily: kFont, fontSize: 13),
          floatingLabelStyle: TextStyle(
              color: _C.primaryLight, fontFamily: kFont, fontSize: 12),
          prefixIcon: Icon(icon, color: _C.textDim, size: 18),
          filled: true,
          fillColor: _C.surface,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 14),
            borderSide: BorderSide(
                color: _C.border, width: AppColors.borderWidth),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 14),
            borderSide: BorderSide(
                color: _C.border, width: AppColors.borderWidth),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 14),
            borderSide: BorderSide(
                color: _C.primaryLight,
                width: isComic ? 3 : 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String value,
    required List<String> options,
    required ValueChanged<String?> onChanged,
    String? label,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(isComic ? 4 : 14),
        border: Border.all(
            color: _C.border, width: AppColors.borderWidth),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (label != null)
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 2),
              child: Text(label,
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 11)),
            ),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              dropdownColor: AppColors.card,
              icon: Icon(Icons.expand_more, color: _C.textSub, size: 20),
              style: TextStyle(
                  color: _C.text,
                  fontFamily: kFont,
                  fontSize: 14,
                  fontWeight: FontWeight.w500),
              items: options.map((opt) {
                return DropdownMenuItem(
                  value: opt,
                  child: Text(opt.toUpperCase(),
                      style: TextStyle(
                          fontFamily: kFont,
                          letterSpacing: 0.5,
                          color: _C.text)),
                );
              }).toList(),
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
    Color? accentColor,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    final color = accentColor ?? _C.primaryLight;
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 10,
          sigmaY: isComic ? 0 : 10,
        ),
        child: Container(
          margin: const EdgeInsets.only(bottom: 20),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: isComic ? AppColors.border : _C.border,
              width: AppColors.borderWidth,
            ),
            boxShadow: isComic
                ? AppColors.glassShadow
                : [
                    BoxShadow(
                      color: color.withOpacity(0.06),
                      blurRadius: 30,
                      offset: const Offset(0, 8),
                    ),
                  ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withOpacity(isComic ? 0.3 : 0.15),
                      borderRadius: BorderRadius.circular(isComic ? 4 : 10),
                      border: Border.all(
                        color: color.withOpacity(0.5),
                        width: isComic ? 2 : 1,
                      ),
                    ),
                    child: Icon(icon,
                        color: isComic
                            ? const Color(0xFF1A1A1A)
                            : color,
                        size: 18),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: kFont,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ...children,
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user, int index) {
    final isComic = ThemeModeManager.isComic3d;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index * 50).clamp(0, 400)),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(
          offset: Offset(0, 12 * (1 - v)),
          child: child,
        ),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(isComic ? 4 : 14),
          border: Border.all(
              color: _C.border, width: AppColors.borderWidth),
        ),
        child: Row(
          children: [
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: _C.primaryDark.withOpacity(isComic ? 0.3 : 0.15),
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                border: isComic
                    ? Border.all(color: AppColors.border, width: 2)
                    : null,
              ),
              child: Center(
                child: Text(
                  (user['username'] as String)
                      .substring(0, 1)
                      .toUpperCase(),
                  style: TextStyle(
                    color: isComic
                        ? const Color(0xFF1A1A1A)
                        : _C.primaryLight,
                    fontFamily: kFont,
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user['username'],
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontWeight: FontWeight.w600,
                          fontSize: 14)),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _badge(user['role'].toUpperCase()),
                      const SizedBox(width: 8),
                      Text("Exp: ${user['expiredDate']}",
                          style: TextStyle(
                              color: _C.textSub,
                              fontFamily: kFont,
                              fontSize: 11)),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text("Parent: ${user['parent'] ?? 'SYSTEM'}",
                      style: TextStyle(
                          color: _C.textDim,
                          fontFamily: kFont,
                          fontSize: 11)),
                ],
              ),
            ),
            _IconBtn(
              icon: Icons.delete_outline_rounded,
              color: _C.red,
              onTap: () async {
                final confirm = await _confirmDelete(user['username']);
                if (confirm == true) {
                  deleteController.text = user['username'];
                  _deleteUser();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _badge(String label) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: _C.primaryDark.withOpacity(isComic ? 0.3 : 0.15),
        borderRadius: BorderRadius.circular(isComic ? 3 : 6),
        border: Border.all(
          color: _C.primaryDark.withOpacity(0.5),
          width: isComic ? 2 : 1,
        ),
      ),
      child: Text(label,
          style: TextStyle(
              color: isComic
                  ? const Color(0xFF1A1A1A)
                  : _C.primaryLight,
              fontFamily: kFont,
              fontSize: 10,
              fontWeight: FontWeight.w600)),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox();
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _PillBtn(
            icon: Icons.chevron_left,
            enabled: currentPage > 1,
            onTap: () => setState(() => currentPage--),
          ),
          const SizedBox(width: 6),
          ...List.generate(totalPages, (i) {
            final page = i + 1;
            final active = page == currentPage;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: _PillBtn(
                label: '$page',
                active: active,
                onTap: () => setState(() => currentPage = page),
              ),
            );
          }),
          const SizedBox(width: 6),
          _PillBtn(
            icon: Icons.chevron_right,
            enabled: currentPage < totalPages,
            onTap: () => setState(() => currentPage++),
          ),
        ],
      ),
    );
  }

  // ─── PAGES ───────────────────────────────────────────────────────────
  Widget _buildCreatePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "CREATE ACCOUNT",
        icon: FontAwesomeIcons.userPlus,
        children: [
          _buildInput(
            label: 'Username',
            controller: createUsernameController,
            icon: FontAwesomeIcons.user,
          ),
          _buildInput(
            label: 'Password',
            controller: createPasswordController,
            icon: FontAwesomeIcons.lock,
            obscure: true,
          ),
          _buildInput(
            label: 'Durasi (Hari)',
            controller: createDayController,
            icon: FontAwesomeIcons.calendarDay,
            type: TextInputType.number,
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 8),
                  child: Text("PILIH ROLE",
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 11,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.bold)),
                ),
                _buildDropdown(
                  value: newUserRole,
                  options: roleOptions,
                  onChanged: (v) =>
                      setState(() => newUserRole = v ?? 'member'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 15),
          _buildButton(
            label: 'CREATE ACCOUNT',
            onTap: _createAccount,
            icon: FontAwesomeIcons.userPlus,
            fullWidth: true,
            loading: isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildListPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "USER LIST",
        icon: FontAwesomeIcons.users,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildDropdown(
              value: selectedRole,
              options: roleOptions,
              onChanged: (v) {
                if (v != null) {
                  selectedRole = v;
                  _filterAndPaginate();
                }
              },
            ),
          ),
          if (isLoading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 32),
              child: Center(child: _LoadingDots()),
            )
          else if (filteredList.isEmpty)
            _buildEmptyState()
          else ...[
            ..._getCurrentPageData()
                .asMap()
                .entries
                .map((e) => _buildUserItem(e.value, e.key))
                .toList(),
            const SizedBox(height: 16),
            _buildPagination(),
          ],
        ],
      ),
    );
  }

  Widget _buildDeletePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "DELETE USER",
        icon: FontAwesomeIcons.userSlash,
        accentColor: _C.red,
        children: [
          Text(
            "Masukkan username yang ingin dihapus. Aksi ini tidak bisa dibatalkan.",
            style: TextStyle(
                color: _C.textSub,
                fontFamily: kFont,
                fontSize: 12,
                height: 1.5),
          ),
          const SizedBox(height: 16),
          _buildInput(
            label: 'Username Target',
            controller: deleteController,
            icon: FontAwesomeIcons.userEdit,
            hint: 'Username yang ingin dihapus',
          ),
          const SizedBox(height: 10),
          _buildButton(
            label: 'HAPUS USER',
            onTap: _deleteUser,
            icon: FontAwesomeIcons.trash,
            isDestructive: true,
            fullWidth: true,
            loading: isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildAddDurationPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "EXTEND DURATION",
        icon: FontAwesomeIcons.clock,
        children: [
          _buildInput(
            label: 'Username Target',
            controller: editUsernameController,
            icon: FontAwesomeIcons.userEdit,
            hint: 'Username yang ingin diperpanjang',
          ),
          _buildInput(
            label: 'Tambah Hari',
            controller: editDayController,
            icon: FontAwesomeIcons.calendarPlus,
            type: TextInputType.number,
          ),
          const SizedBox(height: 10),
          _buildButton(
            label: 'ADD DAYS',
            onTap: _editUser,
            icon: FontAwesomeIcons.calendarPlus,
            fullWidth: true,
            loading: isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          Icon(Icons.inbox_outlined, color: _C.textDim, size: 40),
          const SizedBox(height: 12),
          Text('Tidak ada data',
              style: TextStyle(
                  color: _C.textSub,
                  fontFamily: kFont,
                  fontSize: 14)),
        ],
      ),
    );
  }

  // ─── BOTTOM NAV ──────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    final isComic = ThemeModeManager.isComic3d;
    final items = [
      {'icon': Icons.add_circle_rounded, 'label': 'Create'},
      {'icon': Icons.list_alt_rounded, 'label': 'List'},
      {'icon': Icons.delete_rounded, 'label': 'Delete'},
      {'icon': Icons.calendar_month_rounded, 'label': 'Duration'},
    ];

    return Container(
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: isComic
            ? null
            : LinearGradient(
                colors: [
                  Colors.white.withOpacity(0.08),
                  Colors.white.withOpacity(0.02),
                ],
              ),
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
            color: _C.border, width: AppColors.borderWidth),
        boxShadow: isComic
            ? AppColors.glassShadow
            : [
                BoxShadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 20,
                    offset: const Offset(0, 4))
              ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: isComic ? 0 : 15,
            sigmaY: isComic ? 0 : 15,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(items.length, (i) {
                final isActive = _navIndex == i;
                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() => _navIndex = i);
                      if (i == 1) _fetchUsers();
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        gradient: isActive ? _C.btnGrad : null,
                        borderRadius: BorderRadius.circular(
                            isComic ? 4 : 12),
                        border: isComic && isActive
                            ? Border.all(
                                color: AppColors.border, width: 2)
                            : null,
                        boxShadow: isActive && !isComic
                            ? [
                                BoxShadow(
                                    color: _C.primary.withOpacity(0.3),
                                    blurRadius: 10)
                              ]
                            : [],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            items[i]['icon'] as IconData,
                            color: isActive ? _onAccent() : _C.textDim,
                            size: 20,
                          ),
                          const SizedBox(height: 3),
                          Text(
                            items[i]['label'] as String,
                            style: TextStyle(
                              color: isActive ? _onAccent() : _C.textDim,
                              fontFamily: kFont,
                              fontSize: 9,
                              fontWeight:
                                  isActive ? FontWeight.bold : FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }

  // ─── BUILD ───────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          extendBody: true,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  // HEADER
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            gradient: _C.btnGrad,
                            borderRadius: BorderRadius.circular(
                                ThemeModeManager.isComic3d ? 4 : 12),
                            border: ThemeModeManager.isComic3d
                                ? Border.all(
                                    color: AppColors.border, width: 2)
                                : null,
                          ),
                          child: Icon(Icons.admin_panel_settings_rounded,
                              color: _onAccent(), size: 18),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("ADMIN PANEL",
                                style: TextStyle(
                                    color: _C.text,
                                    fontFamily: kFont,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2)),
                            Text("System Management",
                                style: TextStyle(
                                    color: _C.textSub,
                                    fontFamily: kFont,
                                    fontSize: 11)),
                          ],
                        ),
                        const Spacer(),
                        _IconBtn(
                          icon: Icons.refresh_rounded,
                          color: _C.textDim,
                          onTap: _fetchUsers,
                        ),
                      ],
                    ),
                  ),

                  // PAGE CONTENT
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: KeyedSubtree(
                        key: ValueKey(_navIndex),
                        child: _navIndex == 0
                            ? _buildCreatePage()
                            : _navIndex == 1
                                ? _buildListPage()
                                : _navIndex == 2
                                    ? _buildDeletePage()
                                    : _buildAddDurationPage(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _buildBottomNav(),
            ),
          ),
        );
      },
    );
  }
}

// ─── Helper Widgets ──────────────────────────────────────────────────
class _IconBtn extends StatefulWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _IconBtn(
      {required this.icon, required this.color, required this.onTap});

  @override
  State<_IconBtn> createState() => _IconBtnState();
}

class _IconBtnState extends State<_IconBtn> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: 38, height: 38,
        decoration: BoxDecoration(
          color: _pressed
              ? widget.color.withOpacity(0.15)
              : _C.surface,
          borderRadius: BorderRadius.circular(isComic ? 4 : 10),
          border: Border.all(
              color: _C.border, width: AppColors.borderWidth),
        ),
        child: Icon(widget.icon, color: widget.color, size: 18),
      ),
    );
  }
}

class _PillBtn extends StatelessWidget {
  final String? label;
  final IconData? icon;
  final bool active;
  final bool enabled;
  final VoidCallback onTap;

  const _PillBtn({
    this.label,
    this.icon,
    this.active = false,
    this.enabled = true,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 36, height: 36,
        decoration: BoxDecoration(
          color: active ? _C.primaryLight : _C.surface,
          borderRadius: BorderRadius.circular(isComic ? 4 : 10),
          border: Border.all(
              color: active ? _C.primaryLight : _C.border,
              width: AppColors.borderWidth),
        ),
        child: Center(
          child: icon != null
              ? Icon(icon,
                  size: 16,
                  color: enabled ? _C.textSub : _C.border)
              : Text(
                  label ?? '',
                  style: TextStyle(
                    color: active ? _onAccent() : _C.textSub,
                    fontFamily: kFont,
                    fontSize: 13,
                    fontWeight: active ? FontWeight.w700 : FontWeight.w400,
                  ),
                ),
        ),
      ),
    );
  }
}

class _PressableButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  const _PressableButton({required this.child, this.onTap});

  @override
  State<_PressableButton> createState() => _PressableButtonState();
}

class _PressableButtonState extends State<_PressableButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap?.call();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedOpacity(
          opacity: widget.onTap == null ? 0.45 : (_down ? 0.85 : 1.0),
          duration: const Duration(milliseconds: 100),
          child: widget.child,
        ),
      ),
    );
  }
}

class _LoadingDots extends StatefulWidget {
  const _LoadingDots();

  @override
  State<_LoadingDots> createState() => _LoadingDotsState();
}

class _LoadingDotsState extends State<_LoadingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            final delay = i / 3;
            final t = ((_c.value - delay) % 1.0).clamp(0.0, 1.0);
            final scale = math.sin(t * math.pi);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Transform.scale(
                scale: 0.5 + scale * 0.5,
                child: Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.primaryLight.withOpacity(0.4 + scale * 0.6),
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}