import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE MERAH GLASS ───────────────────────────────────────────────
class _C {
  static const bg         = Color(0xFF0A0A0F);
  static const surface    = Color(0x1AFFFFFF);
  static const card       = Color(0x0DFFFFFF);
  static const cardAlt    = Color(0x14FFFFFF);
  static const border     = Color(0x1AFFFFFF);
  static const borderLit  = Color(0x33FFFFFF);
  static const glassBg    = Color(0x0DFFFFFF);
  static const glassBorder = Color(0x1AFFFFFF);

  static const primary    = Color(0xFFFF1744);
  static const primaryMid = Color(0xFFFF5252);
  static const primaryLt  = Color(0xFFFF8A80);
  static const primaryDk  = Color(0xFFB71C1C);

  // alias untuk kompatibilitas
  static const grey       = primary;
  static const greyMid    = primaryMid;
  static const greyLight  = primaryLt;
  static const greyDark   = primaryDk;

  static const text       = Color(0xFFF5EEEE);
  static const textSub    = Color(0xFFE0AAAA);
  static const textDim    = Color(0xFF994444);
  static const textDark   = Color(0xFF553030);

  static const green      = Color(0xFF22C55E);
  static const amber      = Color(0xFFF59E0B);
  static const red        = Color(0xFFFF1744);

  static const orangeDark   = primaryDk;
  static const orangeMid    = primaryMid;
  static const orangeLight  = primaryLt;
  static const orangeAccent = primary;

  static LinearGradient get btnGrad => const LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get glassGrad => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.06),
      Colors.white.withOpacity(0.02),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> get glassShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.3),
      blurRadius: 30,
      offset: const Offset(0, 8),
    ),
    BoxShadow(
      color: const Color(0x0DFF1744),
      blurRadius: 60,
      offset: const Offset(0, -4),
    ),
  ];

  static List<BoxShadow> get softShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.15),
      blurRadius: 16,
      offset: const Offset(0, 4),
    ),
  ];
}

// ─── Contact data ──────────────────────────────────────────────────────
class _Contact {
  final String label;
  final String handle;
  final IconData icon;
  final Color color;
  final Color colorDim;
  final String url;

  const _Contact({
    required this.label,
    required this.handle,
    required this.icon,
    required this.color,
    required this.colorDim,
    required this.url,
  });
}

const _contacts = [
  _Contact(
    label:    'Telegram',
    handle:   'Telegram Owner',
    icon:     FontAwesomeIcons.telegram,
    color:    Color(0xFF39A7E0),
    colorDim: Color(0xFF1A4D6E),
    url:      'https://t.me/ameluchuu',
  ),
  _Contact(
    label:    'WhatsApp',
    handle:   'Whatsapp owner',
    icon:     FontAwesomeIcons.whatsapp,
    color:    Color(0xFF25D366),
    colorDim: Color(0xFF0D4A27),
    url:      'https://wa.me/6289509466933',
  ),
  _Contact(
    label:    'TikTok',
    handle:   'Tiktok Owner',
    icon:     FontAwesomeIcons.tiktok,
    color:    Color(0xFFEE1D52),
    colorDim: Color(0xFF4A0D1F),
    url:      'https://tiktok.com/@amellovelyy07',
  ),
];

// ─── Page ──────────────────────────────────────────────────────────────
class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage>
    with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _heroCtrl;
  late AnimationController _listCtrl;
  late AnimationController _heroGlow;

  late Animation<double> _heroScale;
  late Animation<double> _heroFade;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 16),
    )..repeat();

    _heroCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    );
    _heroScale = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _heroCtrl, curve: Curves.easeOutBack),
    );
    _heroFade = CurvedAnimation(parent: _heroCtrl, curve: Curves.easeOut);
    _heroGlow = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _listCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    Future.delayed(const Duration(milliseconds: 100), () {
      _heroCtrl.forward();
    });
    Future.delayed(const Duration(milliseconds: 400), () {
      _listCtrl.forward();
    });
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _heroCtrl.dispose();
    _heroGlow.dispose();
    _listCtrl.dispose();
    super.dispose();
  }

  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Tidak dapat membuka link',
              style: TextStyle(fontFamily: kFont, color: _C.text)),
          backgroundColor: _C.card,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          // ✅ BACKGROUND FOTO mmk.jpg
          Positioned.fill(
            child: Image.asset(
              'assets/images/mmk.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _AnimatedBg(controller: _bgCtrl),
            ),
          ),

          // ✅ Overlay gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.bg.withOpacity(0.78),
                    _C.bg.withOpacity(0.88),
                    _C.bg.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildHero()),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (_, i) => _StaggerItem(
                        index: i,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: _ContactCard(
                            contact: _contacts[i],
                            onTap: () => _launch(_contacts[i].url),
                          ),
                        ),
                      ),
                      childCount: _contacts.length,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: _BackBtn(onTap: () => Navigator.pop(context)),
      title: Text(
        'Customer Service',
        style: TextStyle(
          color: _C.text,
          fontSize: 17,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.3,
          fontFamily: kFont,
        ),
      ),
      centerTitle: true,
    );
  }

  Widget _buildHero() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      child: FadeTransition(
        opacity: _heroFade,
        child: ScaleTransition(
          scale: _heroScale,
          child: Column(
            children: [
              AnimatedBuilder(
                animation: _heroGlow,
                builder: (_, __) {
                  final g = _heroGlow.value;
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 110, height: 110,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _C.primary.withOpacity(g * 0.15),
                            width: 1,
                          ),
                        ),
                      ),
                      Container(
                        width: 88, height: 88,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _C.primary.withOpacity(g * 0.25),
                            width: 1,
                          ),
                        ),
                      ),
                      Container(
                        width: 68, height: 68,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [
                              _C.primaryDk.withOpacity(0.9),
                              _C.primary,
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _C.primary.withOpacity(g * 0.3),
                              blurRadius: 28,
                              spreadRadius: 0,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.support_agent_rounded,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                    ],
                  );
                },
              ),

              const SizedBox(height: 20),

              Text(
                'Ada yang bisa kami bantu?',
                style: TextStyle(
                  color: _C.text,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                  fontFamily: kFont,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Halo pengguna apk Tramsflok ada kendala\nsilahkan hubungi akun kami di bawah ini.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 13,
                  height: 1.6,
                  fontFamily: kFont,
                ),
              ),

              const SizedBox(height: 24),

              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  gradient: _C.glassGrad,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: _C.glassBorder, width: 1),
                  boxShadow: _C.softShadow,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 7, height: 7,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.green,
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x5522C55E),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Biasanya merespons dalam beberapa menit',
                      style: TextStyle(
                        color: _C.textSub,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        fontFamily: kFont,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Contact Card ─────────────────────────────────────────────────────
class _ContactCard extends StatefulWidget {
  final _Contact contact;
  final VoidCallback onTap;

  const _ContactCard({required this.contact, required this.onTap});

  @override
  State<_ContactCard> createState() => _ContactCardState();
}

class _ContactCardState extends State<_ContactCard>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;
  late AnimationController _hoverCtrl;
  late Animation<double> _arrowSlide;

  @override
  void initState() {
    super.initState();
    _hoverCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _arrowSlide = Tween<double>(begin: 0, end: 6).animate(
      CurvedAnimation(parent: _hoverCtrl, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _hoverCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.contact;
    return GestureDetector(
      onTapDown: (_) {
        setState(() => _pressed = true);
        _hoverCtrl.forward();
      },
      onTapUp: (_) {
        setState(() => _pressed = false);
        _hoverCtrl.reverse();
        widget.onTap();
      },
      onTapCancel: () {
        setState(() => _pressed = false);
        _hoverCtrl.reverse();
      },
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
              decoration: BoxDecoration(
                gradient: _pressed
                    ? LinearGradient(
                        colors: [
                          Colors.white.withOpacity(0.08),
                          Colors.transparent,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : _C.glassGrad,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _pressed ? c.color.withOpacity(0.3) : _C.glassBorder,
                  width: 1,
                ),
                boxShadow: _pressed
                    ? [
                        BoxShadow(
                          color: c.color.withOpacity(0.08),
                          blurRadius: 20,
                          offset: const Offset(0, 4),
                        ),
                      ]
                    : _C.softShadow,
              ),
              child: Row(
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 50, height: 50,
                    decoration: BoxDecoration(
                      gradient: _pressed
                          ? LinearGradient(
                              colors: [
                                c.color.withOpacity(0.12),
                                c.color.withOpacity(0.02),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : LinearGradient(
                              colors: [
                                c.colorDim.withOpacity(0.3),
                                c.colorDim.withOpacity(0.1),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: c.color.withOpacity(_pressed ? 0.3 : 0.1),
                        width: 1,
                      ),
                    ),
                    child: Center(
                      child: FaIcon(c.icon, color: c.color, size: 22),
                    ),
                  ),

                  const SizedBox(width: 16),

                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          c.label,
                          style: TextStyle(
                            color: _C.text,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFont,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          c.handle,
                          style: TextStyle(
                            color: _C.textSub,
                            fontSize: 12,
                            fontFamily: kFont,
                          ),
                        ),
                      ],
                    ),
                  ),

                  AnimatedBuilder(
                    animation: _arrowSlide,
                    builder: (_, __) => Transform.translate(
                      offset: Offset(_arrowSlide.value, 0),
                      child: Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          gradient: _pressed
                              ? LinearGradient(
                                  colors: [
                                    c.color.withOpacity(0.1),
                                    Colors.transparent,
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                )
                              : null,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: _pressed
                                ? c.color.withOpacity(0.2)
                                : _C.glassBorder,
                            width: 1,
                          ),
                        ),
                        child: Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: _pressed ? c.color : _C.textDim,
                          size: 14,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Stagger Item ─────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;

  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 500 + index * 100),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 22 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ─── Animated Background (fallback) ──────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.border.withOpacity(0.15)
      ..strokeWidth = 0.5;
    const step = 38.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final glow = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.primaryDk
              .withOpacity(0.06 + math.sin(t * math.pi * 2) * 0.02),
          Colors.transparent,
        ],
        radius: 0.8,
      ).createShader(Rect.fromCircle(
          center: Offset(size.width / 2, size.height * 0.22),
          radius: size.width * 0.65));
    canvas.drawCircle(
        Offset(size.width / 2, size.height * 0.22), size.width * 0.65, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

// ─── AppBar Back Button ───────────────────────────────────────────────
class _BackBtn extends StatefulWidget {
  final VoidCallback onTap;
  const _BackBtn({required this.onTap});

  @override
  State<_BackBtn> createState() => _BackBtnState();
}

class _BackBtnState extends State<_BackBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) {
          setState(() => _down = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          decoration: BoxDecoration(
            gradient: _down
                ? LinearGradient(
                    colors: [
                      Colors.white.withOpacity(0.06),
                      Colors.transparent,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : null,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: _down ? _C.primary.withOpacity(0.2) : _C.glassBorder,
              width: 1,
            ),
            boxShadow: _down
                ? [
                    BoxShadow(
                      color: _C.primary.withOpacity(0.08),
                      blurRadius: 10,
                    ),
                  ]
                : null,
          ),
          child: Icon(Icons.arrow_back_ios_new_rounded,
              color: _C.textSub, size: 16),
        ),
      ),
    );
  }
}